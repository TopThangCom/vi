java -jar getLatinTag.jar kr ko "碼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "境" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "銅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닷" 1000  keyword_ko.txt
