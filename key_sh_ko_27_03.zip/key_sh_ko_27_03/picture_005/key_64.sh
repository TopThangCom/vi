java -jar getLatinTag.jar kr ko "瘤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "黃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "虔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "婆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蜜" 1000  keyword_ko.txt
