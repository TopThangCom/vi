java -jar getLatinTag.jar kr kr "出生率" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "LB" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "lb" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조성" 1000  keyword_kr.txt
