java -jar getLatinTag.jar kr kr "효과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "링크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사냥터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배치기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "경험치" 1000  keyword_kr.txt
