java -jar getLatinTag.jar kr kr "久喜市" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "事件" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "久喜市菖蒲土地" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "久喜市吉羽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "久喜屋" 1000  keyword_kr.txt
