java -jar getLatinTag.jar it it "agnelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castiglione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "peruzzi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solteiro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "balerion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "datacron" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "datacrons" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "soltando" 1000  keyword_it.txt
