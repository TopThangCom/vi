java -jar getLatinTag.jar kr ko "酒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "립" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "태" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豊" 1000  keyword_ko.txt
