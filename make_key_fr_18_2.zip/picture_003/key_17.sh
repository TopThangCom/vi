java -jar getLatinTag.jar fr  fr "utilisateurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'affaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "image" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'idée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "propriétaire" 1000  keyword_fr.txt
