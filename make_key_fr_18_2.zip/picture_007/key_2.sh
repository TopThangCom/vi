java -jar getLatinTag.jar fr  fr "attitude" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mines" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'aux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "liée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plantes" 1000  keyword_fr.txt
