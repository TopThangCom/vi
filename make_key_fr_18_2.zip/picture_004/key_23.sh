java -jar getLatinTag.jar fr  fr "IBM" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "climat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'acheter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "SICAV" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "département" 1000  keyword_fr.txt
