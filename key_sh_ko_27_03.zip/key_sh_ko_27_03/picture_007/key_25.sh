java -jar getLatinTag.jar kr ko "擔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "綴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "첸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "偕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "閱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "늬" 1000  keyword_ko.txt
