java -jar getLatinTag.jar it it "acrescento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acromegalia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fisiopatologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diagnostico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diferencial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "digitales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tratamiento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "espermatozoide" 1000  keyword_it.txt
