java -jar getLatinTag.jar fr  fr "Parlement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dépit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fichiers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "personnalité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constitué" 1000  keyword_fr.txt
