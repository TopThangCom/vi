java -jar getLatinTag.jar kr kr "확장프로그램" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "번역하는법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비번" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "없애기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "푸는법" 1000  keyword_kr.txt
