java -jar getLatinTag.jar it it "alphabiotica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alphabiotico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apparel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "datalog" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mandioca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "programmatore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "registro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "altaneramente" 1000  keyword_it.txt
