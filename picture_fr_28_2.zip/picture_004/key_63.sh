java -jar getLatinTag.jar kr kr "元山桌上型冰溫熱濾淨式飲水機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "딥" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시티" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "찾기" 1000  keyword_kr.txt
