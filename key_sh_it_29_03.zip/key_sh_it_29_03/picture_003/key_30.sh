java -jar getLatinTag.jar it it "gif" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "protocol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rabbitmq" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mqtt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amropali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amscope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "microscope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secondapensione" 1000  keyword_it.txt
