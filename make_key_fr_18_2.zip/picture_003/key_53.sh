java -jar getLatinTag.jar fr  fr "G" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "livres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "convient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fonctions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fera" 1000  keyword_fr.txt
