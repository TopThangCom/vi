java -jar getLatinTag.jar fr  fr "menu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chances" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commerciaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "printemps" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Benelux" 1000  keyword_fr.txt
