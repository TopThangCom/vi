java -jar getLatinTag.jar it it "potters" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquapanel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scaer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquapella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cipp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquaponic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquapoolstore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "isolant" 1000  keyword_it.txt
