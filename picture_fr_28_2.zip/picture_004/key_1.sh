java -jar getLatinTag.jar kr kr "네이버부동산" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버부동산경매" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "등기부등본" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무료열람" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "허위매물" 1000  keyword_kr.txt
