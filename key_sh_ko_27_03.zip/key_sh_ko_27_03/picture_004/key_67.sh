java -jar getLatinTag.jar kr ko "托" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "跑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "屏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "至" 1000  keyword_ko.txt
