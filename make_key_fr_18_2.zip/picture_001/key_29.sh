java -jar getLatinTag.jar fr  fr "qu'on" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "question" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pouvoir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "titre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "doute" 1000  keyword_fr.txt
