java -jar getLatinTag.jar fr  fr "l'indice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pris" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "laquelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "directeur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'en" 1000  keyword_fr.txt
