java -jar getLatinTag.jar fr  fr "bénéfice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "toute" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "travail" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trop" 1000  keyword_fr.txt
