java -jar getLatinTag.jar kr kr "리모컨" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가능하게" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검색이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안될때" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "내용" 1000  keyword_kr.txt
