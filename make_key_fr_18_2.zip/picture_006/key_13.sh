java -jar getLatinTag.jar fr  fr "participer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "appelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "forces" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suisse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "appareil" 1000  keyword_fr.txt
