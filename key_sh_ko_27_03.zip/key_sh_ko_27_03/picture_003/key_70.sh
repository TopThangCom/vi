java -jar getLatinTag.jar kr ko "殺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "同" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "他" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "御" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "負" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "散" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "達" 1000  keyword_ko.txt
