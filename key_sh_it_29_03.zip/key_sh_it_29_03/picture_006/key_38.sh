java -jar getLatinTag.jar it it "bossone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bossotel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lannion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "botella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fernandopolis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caetano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "argentino" 1000  keyword_it.txt
