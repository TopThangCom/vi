java -jar getLatinTag.jar fr  fr "avenir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'entrée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "grave" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commencer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'années" 1000  keyword_fr.txt
