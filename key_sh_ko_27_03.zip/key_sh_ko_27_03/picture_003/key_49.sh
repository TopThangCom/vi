java -jar getLatinTag.jar kr ko "透" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "劑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "其" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "藥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "問" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "該" 1000  keyword_ko.txt
