java -jar getLatinTag.jar kr kr "그림" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그림책" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그림자료" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그림자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그림자복도" 1000  keyword_kr.txt
