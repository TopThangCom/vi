java -jar getLatinTag.jar fr  fr "Tél" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aucune" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "hommes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "donner" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "titres" 1000  keyword_fr.txt
