java -jar getLatinTag.jar kr kr "리눅스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "위치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정보" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정확한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해외" 1000  keyword_kr.txt
