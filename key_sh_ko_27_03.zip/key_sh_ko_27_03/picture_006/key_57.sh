java -jar getLatinTag.jar kr ko "귤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "閃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "樅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "睫" 1000  keyword_ko.txt
