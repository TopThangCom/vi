java -jar getLatinTag.jar it it "sella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artesemi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fioranese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artidiag" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campeonato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artondale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coluna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rodilla" 1000  keyword_it.txt
