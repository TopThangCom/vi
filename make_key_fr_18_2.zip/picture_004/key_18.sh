java -jar getLatinTag.jar fr  fr "obligation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fruits" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "véhicule" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'égard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Conseil" 1000  keyword_fr.txt
