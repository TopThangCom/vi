java -jar getLatinTag.jar fr  fr "importance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conception" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "préférence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spectacle" 1000  keyword_fr.txt
