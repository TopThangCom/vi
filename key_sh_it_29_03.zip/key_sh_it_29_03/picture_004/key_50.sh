java -jar getLatinTag.jar it it "canvia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tecnologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dirigir" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ativa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colaborativa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "criativa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "significativa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "geologia" 1000  keyword_it.txt
