java -jar getLatinTag.jar fr  fr "Ou" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "figure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mot" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "développé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'histoire" 1000  keyword_fr.txt
