java -jar getLatinTag.jar kr kr "구매" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일요일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불친절" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "신고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "직영점" 1000  keyword_kr.txt
