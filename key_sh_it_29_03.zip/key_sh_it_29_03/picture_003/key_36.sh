java -jar getLatinTag.jar it it "renata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amantel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amantronic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cagette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gipolisi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pianta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fellini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "completo" 1000  keyword_it.txt
