java -jar getLatinTag.jar kr ko "뒕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "ú" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "," 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "풢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "<" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "픡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "Ï" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "ȱ" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "읏" 1000  keyword_ko.txt
