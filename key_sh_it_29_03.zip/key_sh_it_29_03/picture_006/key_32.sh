java -jar getLatinTag.jar it it "personalizzate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catarrhalis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caviae" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "branolind" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ruficollis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "incalzite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magnetice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ortopedice" 1000  keyword_it.txt
