java -jar getLatinTag.jar it it "titan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "editore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "edizioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporematic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporematico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporematisch" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporetic" 1000  keyword_it.txt
