java -jar getLatinTag.jar it it "piaget" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alfabetico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "studio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acomodativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distintivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diomedes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diaz" 1000  keyword_it.txt
