java -jar getLatinTag.jar it it "tropic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chanel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambconline" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambcopenaghen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "organization" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "semantica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "civ" 1000  keyword_it.txt
