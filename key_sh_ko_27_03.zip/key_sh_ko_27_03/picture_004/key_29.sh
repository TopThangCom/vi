java -jar getLatinTag.jar kr ko "땢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "톨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "졾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "붮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뒕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "풢" 1000  keyword_ko.txt
