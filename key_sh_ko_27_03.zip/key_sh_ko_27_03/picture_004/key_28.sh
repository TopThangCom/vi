java -jar getLatinTag.jar kr ko "떀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "픡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "읏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퇘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "릻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뛾" 1000  keyword_ko.txt
