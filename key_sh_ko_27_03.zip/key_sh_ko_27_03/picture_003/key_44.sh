java -jar getLatinTag.jar kr ko "謝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "矯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "処" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "濃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "黒" 1000  keyword_ko.txt
