java -jar getLatinTag.jar fr  fr "médecin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "celles-ci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "design" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "décor" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faudrait" 1000  keyword_fr.txt
