java -jar getLatinTag.jar kr kr "확인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "초과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대용량" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단체아이디" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수신" 1000  keyword_kr.txt
