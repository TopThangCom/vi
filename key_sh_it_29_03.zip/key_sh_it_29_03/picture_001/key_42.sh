java -jar getLatinTag.jar it it "perrieri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mesenterica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carcinoma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amigdalectomia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "videoendoscopia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "radiografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cronica" 1000  keyword_it.txt
