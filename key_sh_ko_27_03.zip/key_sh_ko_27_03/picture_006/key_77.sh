java -jar getLatinTag.jar kr ko "狀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "骷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卯" 1000  keyword_ko.txt
