java -jar getLatinTag.jar fr  fr "sortir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commandes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "permettant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "manager" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fiscal" 1000  keyword_fr.txt
