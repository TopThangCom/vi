java -jar getLatinTag.jar kr ko "쫓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "떠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "듣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "첼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "협" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퀘" 1000  keyword_ko.txt
