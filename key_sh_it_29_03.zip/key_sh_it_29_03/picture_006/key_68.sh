java -jar getLatinTag.jar it it "allemand" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antragsportal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bmconta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bmicalc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "criminal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chinos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sindicato" 1000  keyword_it.txt
