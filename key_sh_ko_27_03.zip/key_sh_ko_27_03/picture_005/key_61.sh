java -jar getLatinTag.jar kr ko "융" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "唔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "泊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "웰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洪" 1000  keyword_ko.txt
