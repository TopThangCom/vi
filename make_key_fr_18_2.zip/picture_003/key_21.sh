java -jar getLatinTag.jar fr  fr "actifs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "finalement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "internationale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'achat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "monétaire" 1000  keyword_fr.txt
