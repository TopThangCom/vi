java -jar getLatinTag.jar kr kr "料金" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "比較" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "高校受験" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "合格実績" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "予備校" 1000  keyword_kr.txt
