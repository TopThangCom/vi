java -jar getLatinTag.jar kr ko "蔔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "靛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "絶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挫" 1000  keyword_ko.txt
