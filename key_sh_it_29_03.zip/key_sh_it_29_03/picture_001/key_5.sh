java -jar getLatinTag.jar it it "incontrolats" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prodotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ufficiale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abolicao" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "con" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vicon" 1000  keyword_it.txt
