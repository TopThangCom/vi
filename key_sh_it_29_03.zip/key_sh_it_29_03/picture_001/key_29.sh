java -jar getLatinTag.jar it it "vicino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cavalli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lavoratori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addestratore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vecchiano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinofilo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addestratori" 1000  keyword_it.txt
