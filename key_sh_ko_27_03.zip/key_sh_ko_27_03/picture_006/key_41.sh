java -jar getLatinTag.jar kr ko "脆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "똑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "굽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蘊" 1000  keyword_ko.txt
