java -jar getLatinTag.jar it it "biopsicossocial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colluttorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dentifricio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "peribioma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "odontologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retinol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imunologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "silicio" 1000  keyword_it.txt
