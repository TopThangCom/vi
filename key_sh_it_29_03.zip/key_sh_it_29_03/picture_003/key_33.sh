java -jar getLatinTag.jar it it "tireoidiana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antipodean" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "albatross" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antibiotics" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fluoroquinolone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "penicillin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antirabica" 1000  keyword_it.txt
