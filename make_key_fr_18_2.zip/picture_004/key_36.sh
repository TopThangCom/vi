java -jar getLatinTag.jar fr  fr "rencontre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "L'entreprise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spécialistes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "brut" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mauvais" 1000  keyword_fr.txt
