java -jar getLatinTag.jar fr  fr "professionnel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "assure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "garder" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Rien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Actuellement" 1000  keyword_fr.txt
