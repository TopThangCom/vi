java -jar getLatinTag.jar kr kr "특성" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쇼군" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "명함" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "성유물" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "율자" 1000  keyword_kr.txt
