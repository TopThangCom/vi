java -jar getLatinTag.jar it it "alberca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piscinas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abduaziz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rappi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cavalcanti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "final" 1000  keyword_it.txt
