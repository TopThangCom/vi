java -jar getLatinTag.jar it it "ordinarias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coren" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aocca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotisation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "principle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pebble" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "integration" 1000  keyword_it.txt
