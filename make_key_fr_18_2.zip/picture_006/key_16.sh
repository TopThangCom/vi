java -jar getLatinTag.jar fr  fr "spécifiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Albert" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'usine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'existence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "renforcer" 1000  keyword_fr.txt
