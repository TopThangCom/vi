java -jar getLatinTag.jar kr kr "챌린지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버뉴스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버뉴스라이브러리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버뉴스속보" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정치" 1000  keyword_kr.txt
