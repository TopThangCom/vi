java -jar getLatinTag.jar kr ko "駐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "辦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "墜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "操" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "縦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鼻" 1000  keyword_ko.txt
