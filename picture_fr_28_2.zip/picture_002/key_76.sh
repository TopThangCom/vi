java -jar getLatinTag.jar kr kr "클레어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "b" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "의상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "금고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "짜증나다" 1000  keyword_kr.txt
