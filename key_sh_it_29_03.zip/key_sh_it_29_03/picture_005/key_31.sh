java -jar getLatinTag.jar it it "eletrica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fariborz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "churrascaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tipico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "eric" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sintra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "confetture" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assarmatori" 1000  keyword_it.txt
