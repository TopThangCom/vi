java -jar getLatinTag.jar kr kr "極" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "刀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "声優" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "展示" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛全病院" 1000  keyword_kr.txt
