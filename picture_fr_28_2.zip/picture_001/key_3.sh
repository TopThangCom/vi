java -jar getLatinTag.jar kr kr "크라이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "버질" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "디럭스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "차이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모드" 1000  keyword_kr.txt
