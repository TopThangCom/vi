java -jar getLatinTag.jar kr kr "메이플스토리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "월드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "월드리프" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "코디" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메타버스" 1000  keyword_kr.txt
