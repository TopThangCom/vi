java -jar getLatinTag.jar kr kr "共和電業" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "어플" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "諭吉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "萬用強力膠帶" 1000  keyword_kr.txt
