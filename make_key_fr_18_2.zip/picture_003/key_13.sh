java -jar getLatinTag.jar fr  fr "Ceci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "informatique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "investissement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "volume" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "matériel" 1000  keyword_fr.txt
