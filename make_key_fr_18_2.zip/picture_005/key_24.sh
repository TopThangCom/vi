java -jar getLatinTag.jar fr  fr "présenté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "argent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "confirme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "indépendants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'ordinateur" 1000  keyword_fr.txt
