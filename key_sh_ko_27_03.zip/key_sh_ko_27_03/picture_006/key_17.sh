java -jar getLatinTag.jar kr ko "햄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "躲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "킥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "璧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "祐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嘲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "諷" 1000  keyword_ko.txt
