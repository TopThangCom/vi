java -jar getLatinTag.jar it it "montage" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquazzura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rondon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atrata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perennial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "basilica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "investimentos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "notation" 1000  keyword_it.txt
