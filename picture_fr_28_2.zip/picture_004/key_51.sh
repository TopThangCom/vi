java -jar getLatinTag.jar kr kr "부장" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "베스트샵" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트윈스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "경기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일정" 1000  keyword_kr.txt
