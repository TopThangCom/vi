java -jar getLatinTag.jar kr kr "다운그레이드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "드라이버" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "KSA" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "국가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "hera" 1000  keyword_kr.txt
