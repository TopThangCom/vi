java -jar getLatinTag.jar kr ko "簡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "単" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뚝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "悠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "障" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "胞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茶" 1000  keyword_ko.txt
