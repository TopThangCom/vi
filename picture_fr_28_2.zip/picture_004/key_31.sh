java -jar getLatinTag.jar kr kr "関係" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "三田" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "明" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "晃" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "京都" 1000  keyword_kr.txt
