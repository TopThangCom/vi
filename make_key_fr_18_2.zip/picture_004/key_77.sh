java -jar getLatinTag.jar fr  fr "l'origine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "connaissance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "acheté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ici" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "américaines" 1000  keyword_fr.txt
