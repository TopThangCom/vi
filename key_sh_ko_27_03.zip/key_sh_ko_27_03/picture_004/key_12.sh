java -jar getLatinTag.jar kr ko "擊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "彈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "윙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "젤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멘" 1000  keyword_ko.txt
