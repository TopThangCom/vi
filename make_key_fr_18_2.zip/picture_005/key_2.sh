java -jar getLatinTag.jar fr  fr "concernant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bourses" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fallait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sentiment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bénéficier" 1000  keyword_fr.txt
