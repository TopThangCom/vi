java -jar getLatinTag.jar kr kr "이동" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "高周波焼灼電源装置" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼요" 1000  keyword_kr.txt
