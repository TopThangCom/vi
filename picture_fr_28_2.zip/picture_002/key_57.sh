java -jar getLatinTag.jar kr kr "사이퍼즈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "江夜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "林初雪" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "林雪灵小说" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "特性要因図" 1000  keyword_kr.txt
