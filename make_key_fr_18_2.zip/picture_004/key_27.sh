java -jar getLatinTag.jar fr  fr "souhaite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "internationales" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "producteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "producteurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "code" 1000  keyword_fr.txt
