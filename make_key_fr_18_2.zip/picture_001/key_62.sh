java -jar getLatinTag.jar fr  fr "Comme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mesure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "actuellement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "public" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dire" 1000  keyword_fr.txt
