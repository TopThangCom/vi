java -jar getLatinTag.jar kr kr "웹폰트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "볼드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전화번호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이메일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판매자" 1000  keyword_kr.txt
