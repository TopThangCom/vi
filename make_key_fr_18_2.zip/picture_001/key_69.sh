java -jar getLatinTag.jar fr  fr "En" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cette" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'une" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ont" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ses" 1000  keyword_fr.txt
