java -jar getLatinTag.jar kr ko "翌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "澎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "겟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뇨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貧" 1000  keyword_ko.txt
