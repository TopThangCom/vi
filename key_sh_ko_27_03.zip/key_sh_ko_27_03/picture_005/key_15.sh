java -jar getLatinTag.jar kr ko "丙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鎊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "懂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "옆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멸" 1000  keyword_ko.txt
