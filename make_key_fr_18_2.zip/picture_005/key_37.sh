java -jar getLatinTag.jar fr  fr "relation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "offrent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spectaculaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "LUF" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "produire" 1000  keyword_fr.txt
