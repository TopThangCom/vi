java -jar getLatinTag.jar it it "aneto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calebasse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "reggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tragedia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "income" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diocleziano" 1000  keyword_it.txt
