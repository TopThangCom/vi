java -jar getLatinTag.jar it it "astenoteratozoospermia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astenozoospermia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tripolis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sacca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copiar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "classifications" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "necochea" 1000  keyword_it.txt
