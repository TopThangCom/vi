java -jar getLatinTag.jar fr  fr "De" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "millions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Belgique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "BEF" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mois" 1000  keyword_fr.txt
