java -jar getLatinTag.jar fr  fr "génération" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "élément" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devenue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "touche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conseils" 1000  keyword_fr.txt
