java -jar getLatinTag.jar fr  fr "étudiants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "membre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "photos" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "positions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sud" 1000  keyword_fr.txt
