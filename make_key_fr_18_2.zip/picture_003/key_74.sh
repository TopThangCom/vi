java -jar getLatinTag.jar fr  fr "plaisir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "laisse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "importants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "privé" 1000  keyword_fr.txt
