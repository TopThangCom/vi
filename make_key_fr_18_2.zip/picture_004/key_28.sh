java -jar getLatinTag.jar fr  fr "réussi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "patrimoine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "feu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "expérience" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Anvers" 1000  keyword_fr.txt
