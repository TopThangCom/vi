java -jar getLatinTag.jar it it "dozator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gianfranco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "suppe" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ccb" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioaquanol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioaquatic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "etanol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioconsum" 1000  keyword_it.txt
