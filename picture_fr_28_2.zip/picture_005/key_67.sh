java -jar getLatinTag.jar kr kr "申請" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "下载" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "麒麟" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "芯燁" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "標籤機" 1000  keyword_kr.txt
