java -jar getLatinTag.jar fr  fr "bancaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "laisser" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bureaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "principalement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "intéressant" 1000  keyword_fr.txt
