java -jar getLatinTag.jar kr kr "商周秦汉隋唐宋元明清" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "三菱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "布団乾燥機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nds" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "추출" 1000  keyword_kr.txt
