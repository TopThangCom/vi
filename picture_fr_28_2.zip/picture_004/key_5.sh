java -jar getLatinTag.jar kr kr "유니폼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "응원가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "역대" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "외국인" 1000  keyword_kr.txt
