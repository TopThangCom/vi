java -jar getLatinTag.jar fr  fr "avril" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vont" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "call" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "donné" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "simplement" 1000  keyword_fr.txt
