java -jar getLatinTag.jar kr ko "苓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "屠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "풋" 1000  keyword_ko.txt
