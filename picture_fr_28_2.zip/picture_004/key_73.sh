java -jar getLatinTag.jar kr kr "岩田明" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "岩田明子" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "安倍晋三" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "退社" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "旦那" 1000  keyword_kr.txt
