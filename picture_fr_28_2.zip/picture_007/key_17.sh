java -jar getLatinTag.jar kr kr "승중" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "의미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "탈상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주읍" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주용" 1000  keyword_kr.txt
