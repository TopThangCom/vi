java -jar getLatinTag.jar kr ko "억" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蚊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "俳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "循" 1000  keyword_ko.txt
