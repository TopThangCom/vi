java -jar getLatinTag.jar kr kr "詐欺" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "訴訟された" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "差し押さえ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "最終意思確認" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鈴木康博" 1000  keyword_kr.txt
