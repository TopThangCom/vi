java -jar getLatinTag.jar fr  fr "qu'au" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constituent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "déchets" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sport" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "van" 1000  keyword_fr.txt
