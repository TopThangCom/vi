java -jar getLatinTag.jar fr  fr "clairement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "semblent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "biais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "futur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "neuf" 1000  keyword_fr.txt
