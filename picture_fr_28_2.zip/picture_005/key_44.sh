java -jar getLatinTag.jar kr kr "설치된" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "패키지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "디렉토리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스튜디오" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "無法連線" 1000  keyword_kr.txt
