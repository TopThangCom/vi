java -jar getLatinTag.jar it it "craneo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dolicocefalo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intersticial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intracavitaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inequality" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brascandinavia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brascola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nutricionales" 1000  keyword_it.txt
