java -jar getLatinTag.jar it it "unesco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "psicologo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monetaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "automaticas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gotico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tipicos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ciotat" 1000  keyword_it.txt
