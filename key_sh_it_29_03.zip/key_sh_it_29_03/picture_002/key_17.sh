java -jar getLatinTag.jar it it "monitoring" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "roll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aerosole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aesio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aespi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aespio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tlcan" 1000  keyword_it.txt
