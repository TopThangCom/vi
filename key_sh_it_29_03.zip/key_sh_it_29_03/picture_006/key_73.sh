java -jar getLatinTag.jar it it "cannon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "civilization" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "belicoso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "finos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cosmetici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agrupamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carattere" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bequantene" 1000  keyword_it.txt
