java -jar getLatinTag.jar kr kr "幸村屋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "菜单" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村那个打网球的紫原表弟" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村辉彦" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村诚" 1000  keyword_kr.txt
