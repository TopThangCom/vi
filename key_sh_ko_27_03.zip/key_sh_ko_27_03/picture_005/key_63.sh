java -jar getLatinTag.jar kr ko "避" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "篠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "疏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梯" 1000  keyword_ko.txt
