java -jar getLatinTag.jar kr ko "全" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "札" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "評" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "당" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "는" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "本" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "有" 1000  keyword_ko.txt
