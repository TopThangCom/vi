java -jar getLatinTag.jar it it "crevillente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monfalcone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piantedo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricolage" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abbeville" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ariccia" 1000  keyword_it.txt
