java -jar getLatinTag.jar it it "capitale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ocrico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "andrascorner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiallo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "molina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "andriano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gineceu" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "isostemone" 1000  keyword_it.txt
