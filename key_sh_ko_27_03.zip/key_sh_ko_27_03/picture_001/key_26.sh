java -jar getLatinTag.jar kr ko "클" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "래" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "식" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "해" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "커" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "톤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "주" 1000  keyword_ko.txt
