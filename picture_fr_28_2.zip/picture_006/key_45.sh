java -jar getLatinTag.jar kr kr "马油" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "防曬" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "馬油" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "여는법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파일이란" 1000  keyword_kr.txt
