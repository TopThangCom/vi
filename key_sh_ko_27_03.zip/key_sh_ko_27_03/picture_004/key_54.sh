java -jar getLatinTag.jar kr ko "핌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "힃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "긋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뒯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "훅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쟋" 1000  keyword_ko.txt
