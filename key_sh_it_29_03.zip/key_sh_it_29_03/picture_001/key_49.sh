java -jar getLatinTag.jar it it "acquaintance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquainted" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abbonamenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conselice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prezzi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acqualara" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "limone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acqualimp" 1000  keyword_it.txt
