java -jar getLatinTag.jar fr  fr "de" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "la" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "le" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "et" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "les" 1000  keyword_fr.txt
