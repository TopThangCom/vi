java -jar getLatinTag.jar it it "fisica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gilles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricomer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricomercio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "politica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricommerce" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "peralta" 1000  keyword_it.txt
