java -jar getLatinTag.jar fr  fr "prendre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plan" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "points" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "outre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pourtant" 1000  keyword_fr.txt
