java -jar getLatinTag.jar fr  fr "pourraient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Londres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "juge" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devra" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "uniquement" 1000  keyword_fr.txt
