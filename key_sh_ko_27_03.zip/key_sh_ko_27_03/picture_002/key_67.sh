java -jar getLatinTag.jar kr ko "摩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "即" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "置" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "背" 1000  keyword_ko.txt
