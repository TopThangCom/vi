java -jar getLatinTag.jar kr ko "斎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蔬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "婦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斥" 1000  keyword_ko.txt
