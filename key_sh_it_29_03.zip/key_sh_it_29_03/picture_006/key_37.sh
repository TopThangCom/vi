java -jar getLatinTag.jar it it "econodata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chocolat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caboverdetime" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cabramatta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campsite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dottore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tortona" 1000  keyword_it.txt
