java -jar getLatinTag.jar fr  fr "soit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faut" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bruxelles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quelques" 1000  keyword_fr.txt
