java -jar getLatinTag.jar kr ko "나" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "위" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "키" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "갤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "전" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "야" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "오" 1000  keyword_ko.txt
