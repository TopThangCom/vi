java -jar getLatinTag.jar it it "tensione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "impero" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "balcone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dalle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pillars" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "call" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "faturas" 1000  keyword_it.txt
