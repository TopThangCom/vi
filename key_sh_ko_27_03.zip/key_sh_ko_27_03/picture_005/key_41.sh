java -jar getLatinTag.jar kr ko "캄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "釉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "왓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "湘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "災" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "乏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꿀" 1000  keyword_ko.txt
