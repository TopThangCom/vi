java -jar getLatinTag.jar it it "medicina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "quotazioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "meccanica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "figlio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "immobiliare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pizzeria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rianzares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spinola" 1000  keyword_it.txt
