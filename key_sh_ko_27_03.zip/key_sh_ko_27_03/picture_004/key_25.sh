java -jar getLatinTag.jar kr ko "沉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "眾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "緻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "錶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "珠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "尼" 1000  keyword_ko.txt
