java -jar getLatinTag.jar it it "astrosolar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrostuffs" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pensiones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "internos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "digimon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sentimiento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atascosa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atavistic" 1000  keyword_it.txt
