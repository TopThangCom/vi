java -jar getLatinTag.jar kr kr "jar" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마인크래프트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "포지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파라미터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실행기" 1000  keyword_kr.txt
