java -jar getLatinTag.jar kr kr "배경화면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아이폰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "참여" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "및" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "tv" 1000  keyword_kr.txt
