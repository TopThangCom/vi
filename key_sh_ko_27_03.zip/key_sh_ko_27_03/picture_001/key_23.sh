java -jar getLatinTag.jar kr ko "뜻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "규" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "틸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "다" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뱀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "파" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "포" 1000  keyword_ko.txt
