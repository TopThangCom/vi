java -jar getLatinTag.jar fr  fr "R" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ouvert" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "phase" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "certainement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "télévision" 1000  keyword_fr.txt
