java -jar getLatinTag.jar fr  fr "ouverte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Hong" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "L'année" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "murs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "philosophie" 1000  keyword_fr.txt
