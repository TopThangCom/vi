java -jar getLatinTag.jar kr ko "才" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "経" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "目" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닌" 1000  keyword_ko.txt
