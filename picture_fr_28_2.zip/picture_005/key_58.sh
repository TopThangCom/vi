java -jar getLatinTag.jar kr kr "가져오기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "css" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "웹스토어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "vpn" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "원격" 1000  keyword_kr.txt
