java -jar getLatinTag.jar kr kr "하리낙스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하리낚시터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "프레스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하리나카노역" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "에스파" 1000  keyword_kr.txt
