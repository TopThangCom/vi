java -jar getLatinTag.jar kr kr "가능" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "블루스크린" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파티션" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "설치용량" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "usb" 1000  keyword_kr.txt
