java -jar getLatinTag.jar kr kr "ls전선" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피파" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피파대낙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이엔에스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해킹" 1000  keyword_kr.txt
