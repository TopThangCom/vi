java -jar getLatinTag.jar kr kr "한컴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "에어드롭" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "알" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "텔레그램" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "저장하기" 1000  keyword_kr.txt
