java -jar getLatinTag.jar kr kr "사회복지시설" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "측정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시대의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가치와" 1000  keyword_kr.txt
