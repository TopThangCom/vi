java -jar getLatinTag.jar it it "piperonila" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piperonilo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cabassette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cabassetup" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "correggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "necrologi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cabasson" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rinopolis" 1000  keyword_it.txt
