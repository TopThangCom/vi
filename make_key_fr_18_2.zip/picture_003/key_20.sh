java -jar getLatinTag.jar fr  fr "parfaitement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "viennent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "division" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réseaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "principal" 1000  keyword_fr.txt
