java -jar getLatinTag.jar fr  fr "énorme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "destinés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'avantage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "véhicules" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ressources" 1000  keyword_fr.txt
