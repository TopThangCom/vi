java -jar getLatinTag.jar fr  fr "normal" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Centre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "construire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "démarche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "emprunts" 1000  keyword_fr.txt
