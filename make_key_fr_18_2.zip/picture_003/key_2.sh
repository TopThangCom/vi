java -jar getLatinTag.jar fr  fr "réduit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Pourquoi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "particuliers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "verre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "wallon" 1000  keyword_fr.txt
