java -jar getLatinTag.jar fr  fr "sur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "se" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Le" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ce" 1000  keyword_fr.txt
