java -jar getLatinTag.jar it it "aminosteroid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aminotransferase" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amiodarone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grecotel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiara" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amlodipin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amlodipine" 1000  keyword_it.txt
