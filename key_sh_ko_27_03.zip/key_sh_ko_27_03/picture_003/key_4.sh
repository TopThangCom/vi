java -jar getLatinTag.jar kr ko "겐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "헨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "힘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鳥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "界" 1000  keyword_ko.txt
