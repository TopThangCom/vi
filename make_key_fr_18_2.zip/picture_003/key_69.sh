java -jar getLatinTag.jar fr  fr "Nord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "capitaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "options" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "consommateur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cartes" 1000  keyword_fr.txt
