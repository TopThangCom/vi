java -jar getLatinTag.jar kr ko "얻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "折" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "疊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "搖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "燈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遙" 1000  keyword_ko.txt
