java -jar getLatinTag.jar kr ko "鋼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "材" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "般" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "酸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "離" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "胡" 1000  keyword_ko.txt
