java -jar getLatinTag.jar kr ko "寓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "擘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "阜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迴" 1000  keyword_ko.txt
