java -jar getLatinTag.jar fr  fr "réalisation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "amateurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conséquent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "présenter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Celle-ci" 1000  keyword_fr.txt
