java -jar getLatinTag.jar kr ko "줕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "븿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "컽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쉌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "윔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "댒" 1000  keyword_ko.txt
