java -jar getLatinTag.jar kr kr "막힘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "大鳥機工" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鳥取" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鳥取県" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鳥取市" 1000  keyword_kr.txt
