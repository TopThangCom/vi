java -jar getLatinTag.jar kr kr "초" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고화질" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기본" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "낮에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배경사진" 1000  keyword_kr.txt
