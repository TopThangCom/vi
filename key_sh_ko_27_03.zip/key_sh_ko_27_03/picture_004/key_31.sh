java -jar getLatinTag.jar kr ko "瀚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "播" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瓣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "椒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "淡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曙" 1000  keyword_ko.txt
