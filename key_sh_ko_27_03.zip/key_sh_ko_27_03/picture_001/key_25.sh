java -jar getLatinTag.jar kr ko "뜸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "없" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "음" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "하" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "법" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "용" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "삭" 1000  keyword_ko.txt
