java -jar getLatinTag.jar fr  fr "devise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prochaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "transport" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Street" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "demander" 1000  keyword_fr.txt
