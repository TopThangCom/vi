java -jar getLatinTag.jar it it "anonimos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ansotegi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cremonensis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antconc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disciplinarios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "policiales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardioplegia" 1000  keyword_it.txt
