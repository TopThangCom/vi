java -jar getLatinTag.jar kr kr "허재" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "増岡" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "増岡製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "社長" 1000  keyword_kr.txt
