java -jar getLatinTag.jar kr ko "貿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "臣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "権" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "節" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "併" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "函" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壊" 1000  keyword_ko.txt
