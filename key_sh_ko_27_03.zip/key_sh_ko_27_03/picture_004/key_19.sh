java -jar getLatinTag.jar kr ko "民" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "享" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "岐" 1000  keyword_ko.txt
