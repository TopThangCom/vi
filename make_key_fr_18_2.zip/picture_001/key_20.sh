java -jar getLatinTag.jar fr  fr "seulement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Van" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "semble" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "clients" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Tout" 1000  keyword_fr.txt
