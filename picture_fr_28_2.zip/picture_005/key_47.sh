java -jar getLatinTag.jar kr kr "再結合" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "蛍光灯" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "見た目" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "led発煙筒" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "電池交換" 1000  keyword_kr.txt
