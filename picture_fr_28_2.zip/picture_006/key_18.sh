java -jar getLatinTag.jar kr kr "어린이날" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "돌축제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하린마트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전남친" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하리니" 1000  keyword_kr.txt
