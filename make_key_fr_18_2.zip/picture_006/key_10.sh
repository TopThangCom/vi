java -jar getLatinTag.jar fr  fr "convaincre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "notion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "visage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vouloir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ajoutée" 1000  keyword_fr.txt
