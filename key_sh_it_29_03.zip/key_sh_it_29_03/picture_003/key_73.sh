java -jar getLatinTag.jar it it "fallbloc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticamere" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticandidal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticipado" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticoncepcionais" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caleffi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "condensation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticondensfolie" 1000  keyword_it.txt
