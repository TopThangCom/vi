java -jar getLatinTag.jar kr kr "서비스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "종료" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안내서비스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "횟수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "벨소리" 1000  keyword_kr.txt
