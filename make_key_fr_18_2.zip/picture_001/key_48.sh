java -jar getLatinTag.jar fr  fr "baisse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Avec" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "résultats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Des" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "votre" 1000  keyword_fr.txt
