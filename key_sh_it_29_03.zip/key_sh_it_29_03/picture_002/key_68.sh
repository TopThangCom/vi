java -jar getLatinTag.jar it it "cabello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "marisco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "studios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampolla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pediatrica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "indicaciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alliade" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clinic" 1000  keyword_it.txt
