java -jar getLatinTag.jar it it "aequator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequatorialguinea" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequatorlinie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequitaz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequivocatio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequometer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequorin" 1000  keyword_it.txt
