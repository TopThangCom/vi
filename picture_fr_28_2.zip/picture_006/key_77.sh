java -jar getLatinTag.jar kr kr "肌力健" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力健康俱乐部" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力流失症状" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力瑜珈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "潤い" 1000  keyword_kr.txt
