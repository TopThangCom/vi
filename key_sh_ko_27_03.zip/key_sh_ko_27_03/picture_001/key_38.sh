java -jar getLatinTag.jar kr ko "과" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "링" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "냥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "험" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "마" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "릿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "편" 1000  keyword_ko.txt
