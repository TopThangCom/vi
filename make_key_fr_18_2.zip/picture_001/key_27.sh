java -jar getLatinTag.jar fr  fr "Depuis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entreprise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "me" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nouvelles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'y" 1000  keyword_fr.txt
