java -jar getLatinTag.jar kr kr "지메일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "읽음확인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전체삭제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "skiet" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "청약" 1000  keyword_kr.txt
