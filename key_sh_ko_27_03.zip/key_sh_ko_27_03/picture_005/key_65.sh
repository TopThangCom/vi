java -jar getLatinTag.jar kr ko "尤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "癌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鍵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "矮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "摘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痱" 1000  keyword_ko.txt
