java -jar getLatinTag.jar fr  fr "prestations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "publicitaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sensibles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "communauté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'émission" 1000  keyword_fr.txt
