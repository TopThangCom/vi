java -jar getLatinTag.jar fr  fr "plusieurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "certains" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'affaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "permet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "politique" 1000  keyword_fr.txt
