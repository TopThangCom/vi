java -jar getLatinTag.jar kr kr "式谷" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "式谷似之" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "名字" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "千葉県" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "東京" 1000  keyword_kr.txt
