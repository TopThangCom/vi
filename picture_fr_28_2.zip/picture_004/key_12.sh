java -jar getLatinTag.jar kr kr "링" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "블루" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나무" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "위키" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "효율표" 1000  keyword_kr.txt
