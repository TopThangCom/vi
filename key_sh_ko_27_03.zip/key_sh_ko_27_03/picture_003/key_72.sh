java -jar getLatinTag.jar kr ko "頻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "脈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "還" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "択" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舍" 1000  keyword_ko.txt
