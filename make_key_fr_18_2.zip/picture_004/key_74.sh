java -jar getLatinTag.jar fr  fr "précisément" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "couple" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "enregistré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "recul" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "offrir" 1000  keyword_fr.txt
