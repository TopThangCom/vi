java -jar getLatinTag.jar kr ko "맛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "푸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "걸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "될" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "때" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "굿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "띄" 1000  keyword_ko.txt
