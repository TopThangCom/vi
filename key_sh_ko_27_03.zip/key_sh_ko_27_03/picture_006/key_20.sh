java -jar getLatinTag.jar kr ko "峽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "爭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "狙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "땅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "疽" 1000  keyword_ko.txt
