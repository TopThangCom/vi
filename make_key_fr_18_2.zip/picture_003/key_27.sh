java -jar getLatinTag.jar fr  fr "quelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contexte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "limite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mains" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commun" 1000  keyword_fr.txt
