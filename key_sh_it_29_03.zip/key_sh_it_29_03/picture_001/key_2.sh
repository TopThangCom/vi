java -jar getLatinTag.jar it it "perra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gloria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "letras" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clinica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distrito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrapetite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrapp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "psicologia" 1000  keyword_it.txt
