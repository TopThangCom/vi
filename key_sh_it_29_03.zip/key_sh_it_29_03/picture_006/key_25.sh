java -jar getLatinTag.jar it it "alessandria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cognac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cremonese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ilaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dolomiten" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concorezzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cereghetti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clarifiant" 1000  keyword_it.txt
