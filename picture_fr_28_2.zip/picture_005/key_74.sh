java -jar getLatinTag.jar kr kr "피파인벤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선수평가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미페" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선수비교" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스쿼드" 1000  keyword_kr.txt
