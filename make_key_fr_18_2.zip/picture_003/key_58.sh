java -jar getLatinTag.jar fr  fr "régime" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'autant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "liste" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "opération" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bout" 1000  keyword_fr.txt
