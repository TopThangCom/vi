java -jar getLatinTag.jar kr ko "샨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "丑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "楠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "餌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "夭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "阱" 1000  keyword_ko.txt
