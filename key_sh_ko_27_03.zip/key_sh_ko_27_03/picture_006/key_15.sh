java -jar getLatinTag.jar kr ko "霊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "죽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鑷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "랍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꼽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "옛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "끝" 1000  keyword_ko.txt
