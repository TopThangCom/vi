java -jar getLatinTag.jar kr kr "医学" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "伝説" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "競輪" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "入金" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "時間" 1000  keyword_kr.txt
