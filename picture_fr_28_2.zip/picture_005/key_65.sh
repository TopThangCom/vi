java -jar getLatinTag.jar kr kr "dj" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "소다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비행기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "맥심" 1000  keyword_kr.txt
