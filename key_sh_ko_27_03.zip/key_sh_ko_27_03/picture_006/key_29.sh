java -jar getLatinTag.jar kr ko "橄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "橙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "葬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찜" 1000  keyword_ko.txt
