java -jar getLatinTag.jar kr kr "작동" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "활성화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "部屋作り" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "部屋数" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "換気" 1000  keyword_kr.txt
