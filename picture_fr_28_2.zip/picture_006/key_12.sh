java -jar getLatinTag.jar kr kr "構成" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "設定" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "重度修護乳膏" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "呪術" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "里香" 1000  keyword_kr.txt
