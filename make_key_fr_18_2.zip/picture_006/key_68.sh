java -jar getLatinTag.jar fr  fr "absolument" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "branche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'objectif" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ouvre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plans" 1000  keyword_fr.txt
