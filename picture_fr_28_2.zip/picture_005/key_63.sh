java -jar getLatinTag.jar kr kr "운영" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스토리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모험모드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "렉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무한로딩" 1000  keyword_kr.txt
