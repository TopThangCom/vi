java -jar getLatinTag.jar kr ko "높" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뀜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "낮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "랄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뚫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "간" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "광" 1000  keyword_ko.txt
