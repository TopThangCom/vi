java -jar getLatinTag.jar it it "oristrell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capuozzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assuntadiconcilio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assuntore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assicurativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concordato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "preventivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nel" 1000  keyword_it.txt
