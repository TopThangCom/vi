java -jar getLatinTag.jar kr kr "데스크톱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "듀얼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모니터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구글드라이브" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "軒並み" 1000  keyword_kr.txt
