java -jar getLatinTag.jar fr  fr "naissance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D'autant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Co" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'information" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "distance" 1000  keyword_fr.txt
