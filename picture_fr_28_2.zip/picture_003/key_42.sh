java -jar getLatinTag.jar kr kr "郵便番号" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "土地" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "中古住宅" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新築" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "読み方" 1000  keyword_kr.txt
