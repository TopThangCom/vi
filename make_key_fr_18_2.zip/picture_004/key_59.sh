java -jar getLatinTag.jar fr  fr "ceux-ci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "favorable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pouvoirs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "participations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "annonce" 1000  keyword_fr.txt
