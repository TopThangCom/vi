java -jar getLatinTag.jar fr  fr "leur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "peut" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ces" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "y" 1000  keyword_fr.txt
