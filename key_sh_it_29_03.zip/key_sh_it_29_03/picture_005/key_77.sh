java -jar getLatinTag.jar it it "egitto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colf" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "responsabilita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ponto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rilevanza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solito" 1000  keyword_it.txt
