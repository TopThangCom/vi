java -jar getLatinTag.jar kr kr "대사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뜻" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "코스프레" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피규어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마틸다" 1000  keyword_kr.txt
