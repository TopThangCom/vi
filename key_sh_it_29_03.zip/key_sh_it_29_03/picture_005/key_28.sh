java -jar getLatinTag.jar it it "assodanza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assodare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assodata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assodato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appartamenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "affitto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assolavoro" 1000  keyword_it.txt
