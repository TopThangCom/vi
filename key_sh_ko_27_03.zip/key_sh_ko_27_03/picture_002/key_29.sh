java -jar getLatinTag.jar kr ko "光" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "度" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "數" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "位" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "音" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "筆" 1000  keyword_ko.txt
