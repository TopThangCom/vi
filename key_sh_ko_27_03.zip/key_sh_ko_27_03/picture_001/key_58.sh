java -jar getLatinTag.jar kr ko "이" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "미" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "징" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "유" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "리" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셋" 1000  keyword_ko.txt
