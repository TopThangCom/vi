java -jar getLatinTag.jar kr ko "睿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "睡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "如" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "來" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "於" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奶" 1000  keyword_ko.txt
