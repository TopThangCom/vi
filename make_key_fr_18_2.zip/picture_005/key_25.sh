java -jar getLatinTag.jar fr  fr "couverture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "domicile" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "soins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devront" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "luxe" 1000  keyword_fr.txt
