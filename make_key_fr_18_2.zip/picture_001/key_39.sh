java -jar getLatinTag.jar fr  fr "a" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "par" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plus" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pas" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "au" 1000  keyword_fr.txt
