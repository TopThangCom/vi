java -jar getLatinTag.jar kr kr "셀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "엔딩" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "크레딧" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구성" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "노래" 1000  keyword_kr.txt
