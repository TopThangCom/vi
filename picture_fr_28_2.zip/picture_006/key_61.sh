java -jar getLatinTag.jar kr kr "ALD" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "장점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "城北化学" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "AHU" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실" 1000  keyword_kr.txt
