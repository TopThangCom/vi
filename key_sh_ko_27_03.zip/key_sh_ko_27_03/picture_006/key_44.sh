java -jar getLatinTag.jar kr ko "濱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鸚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鵡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "譁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혹" 1000  keyword_ko.txt
