java -jar getLatinTag.jar kr ko "吸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "快" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "菌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "纖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "帯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벡" 1000  keyword_ko.txt
