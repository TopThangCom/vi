java -jar getLatinTag.jar kr kr "٦×٦×٦×٦=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٦×٦+٦÷٦-١" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٦×٦×٦" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٦×٦×٦×٦" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٦×٦+٦÷٦-٦=" 1000  keyword_kr.txt
