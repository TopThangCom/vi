java -jar getLatinTag.jar fr  fr "progressé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "signe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "passée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "approche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "p" 1000  keyword_fr.txt
