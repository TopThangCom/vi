java -jar getLatinTag.jar kr ko "魔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "軽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "燒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "檯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瓦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斯" 1000  keyword_ko.txt
