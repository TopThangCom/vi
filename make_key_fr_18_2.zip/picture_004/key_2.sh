java -jar getLatinTag.jar fr  fr "Société" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "communes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dizaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faute" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sélection" 1000  keyword_fr.txt
