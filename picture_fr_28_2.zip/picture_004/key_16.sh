java -jar getLatinTag.jar kr kr "환기용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "유닛" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공기필터유닛(ks" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국산업표준(ks" 1000  keyword_kr.txt
