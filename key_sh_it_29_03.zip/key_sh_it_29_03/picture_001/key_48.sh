java -jar getLatinTag.jar it it "inca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scala" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "core" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecg" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "definicion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castellano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petroli" 1000  keyword_it.txt
