java -jar getLatinTag.jar it it "retella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoaccessori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bonelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caponata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caporusso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "simona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantiere" 1000  keyword_it.txt
