java -jar getLatinTag.jar kr ko "須" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蛙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "措" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "킷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "둔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "댑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "힌" 1000  keyword_ko.txt
