java -jar getLatinTag.jar it it "mezio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mirella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cossato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "quaglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allegro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bancogiro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rialto" 1000  keyword_it.txt
