java -jar getLatinTag.jar kr ko "勇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瓜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "틀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퇴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "増" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "激" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勵" 1000  keyword_ko.txt
