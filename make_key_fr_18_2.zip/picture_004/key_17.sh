java -jar getLatinTag.jar fr  fr "délai" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trouvent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "classiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commencé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réalisée" 1000  keyword_fr.txt
