java -jar getLatinTag.jar it it "inferiore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecommoy" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brossell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardot" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fresata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rilegato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perfetta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartonato" 1000  keyword_it.txt
