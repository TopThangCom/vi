java -jar getLatinTag.jar it it "parcari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "edi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tatimore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comerciala" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "financiara" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prezidentiala" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "strazilor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiscale" 1000  keyword_it.txt
