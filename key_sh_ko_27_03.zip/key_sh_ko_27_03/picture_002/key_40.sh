java -jar getLatinTag.jar kr ko "彰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "解" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "逃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "論" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "身" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "岩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "退" 1000  keyword_ko.txt
