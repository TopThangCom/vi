java -jar getLatinTag.jar kr kr "달이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뜨는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다람쥐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다람쥐의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "꼭두각시" 1000  keyword_kr.txt
