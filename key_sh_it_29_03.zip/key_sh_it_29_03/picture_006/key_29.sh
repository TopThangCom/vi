java -jar getLatinTag.jar it it "biocorp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "confetti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "silicon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioessencial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioexcellence" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioexcellent" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ritter" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biomedical" 1000  keyword_it.txt
