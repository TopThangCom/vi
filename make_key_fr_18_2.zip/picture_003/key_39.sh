java -jar getLatinTag.jar fr  fr "prime" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Flandre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "crédit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "monnaie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "précise" 1000  keyword_fr.txt
