java -jar getLatinTag.jar it it "alcoholic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cetona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nomenclatura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coopn" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broccolini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "degli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fumetto" 1000  keyword_it.txt
