java -jar getLatinTag.jar it it "acquamare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquamarina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquamarine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquamundi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ristoranti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquaportal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquapura" 1000  keyword_it.txt
