java -jar getLatinTag.jar fr  fr "rappeler" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "utilisés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suivante" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'année" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "représentant" 1000  keyword_fr.txt
