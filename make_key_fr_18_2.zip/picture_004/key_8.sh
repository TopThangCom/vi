java -jar getLatinTag.jar fr  fr "objectifs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "récente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "saison" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'art" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "industriels" 1000  keyword_fr.txt
