java -jar getLatinTag.jar it it "biandronno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocasion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocastello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocastillo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "click" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "delphi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocomotti" 1000  keyword_it.txt
