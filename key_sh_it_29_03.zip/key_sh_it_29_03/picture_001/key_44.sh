java -jar getLatinTag.jar it it "acqualina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acqualinda" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acqualive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bellona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catania" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montelupo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "triflisco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquamania" 1000  keyword_it.txt
