java -jar getLatinTag.jar it it "fragranza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspiration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspirational" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspirativan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspiratrice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "occasion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "opportunities" 1000  keyword_it.txt
