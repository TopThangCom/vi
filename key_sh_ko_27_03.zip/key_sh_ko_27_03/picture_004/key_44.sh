java -jar getLatinTag.jar kr ko "菊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "儲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鉄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "錦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "糸" 1000  keyword_ko.txt
