java -jar getLatinTag.jar kr kr "愛染明王" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染明王真言" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染明王心咒功效" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染明王心咒功德" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "真言" 1000  keyword_kr.txt
