java -jar getLatinTag.jar it it "adaicollege" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chicago" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adalvenon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pitaco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camper" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "idioma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "crotone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aminatou" 1000  keyword_it.txt
