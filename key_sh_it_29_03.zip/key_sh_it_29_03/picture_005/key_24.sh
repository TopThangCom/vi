java -jar getLatinTag.jar it it "tatoma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inclination" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoquadrifoglio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autorabit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "radiator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoradiatoren" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoradio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoredaelli" 1000  keyword_it.txt
