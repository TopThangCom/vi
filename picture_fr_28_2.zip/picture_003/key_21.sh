java -jar getLatinTag.jar kr kr "竹田恒泰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "妻" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "兄弟" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "本" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "弟" 1000  keyword_kr.txt
