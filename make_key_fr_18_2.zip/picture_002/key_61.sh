java -jar getLatinTag.jar fr  fr "l'Europe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nombreuses" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "différentes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moyens" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "formation" 1000  keyword_fr.txt
