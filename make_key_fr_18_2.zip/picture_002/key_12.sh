java -jar getLatinTag.jar fr  fr "connu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "principe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tendance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "court" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n" 1000  keyword_fr.txt
