java -jar getLatinTag.jar kr kr "舞" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "彩" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "高校" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田塾" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "不祥事" 1000  keyword_kr.txt
