java -jar getLatinTag.jar kr ko "萊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "夕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "征" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "總" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "魏" 1000  keyword_ko.txt
