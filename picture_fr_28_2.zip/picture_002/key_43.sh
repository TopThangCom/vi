java -jar getLatinTag.jar kr kr "渔舟唱晚" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "直流耐電圧試験器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제네시스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "矢崎化工" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "分光蛍光光度計" 1000  keyword_kr.txt
