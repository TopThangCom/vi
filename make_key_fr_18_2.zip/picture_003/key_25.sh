java -jar getLatinTag.jar fr  fr "institutions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "seuls" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "arrive" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constate" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marques" 1000  keyword_fr.txt
