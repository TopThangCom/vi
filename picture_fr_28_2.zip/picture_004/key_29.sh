java -jar getLatinTag.jar kr kr "dvd" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "特典" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "알리코제약" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "綿" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "車検" 1000  keyword_kr.txt
