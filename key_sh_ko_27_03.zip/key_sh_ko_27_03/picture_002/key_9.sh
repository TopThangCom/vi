java -jar getLatinTag.jar kr ko "續" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "墨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "題" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "跋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霸" 1000  keyword_ko.txt
