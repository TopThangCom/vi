java -jar getLatinTag.jar kr kr "은호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "밤에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아래" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "따뜻한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "물" 1000  keyword_kr.txt
