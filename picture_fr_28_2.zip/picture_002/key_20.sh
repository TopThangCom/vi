java -jar getLatinTag.jar kr kr "전환" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "연봉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배송비" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지마켓산스" 1000  keyword_kr.txt
