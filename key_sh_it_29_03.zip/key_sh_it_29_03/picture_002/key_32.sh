java -jar getLatinTag.jar it it "pian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monticelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gioielli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cellset" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adomelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "decomposition" 1000  keyword_it.txt
