java -jar getLatinTag.jar kr kr "중소기업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정부" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미국" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "점수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리스크" 1000  keyword_kr.txt
