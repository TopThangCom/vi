java -jar getLatinTag.jar fr  fr "tandis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "coup" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "existe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "propre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "carte" 1000  keyword_fr.txt
