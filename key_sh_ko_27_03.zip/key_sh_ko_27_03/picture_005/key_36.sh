java -jar getLatinTag.jar kr ko "杭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "樽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뽀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鳳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "圏" 1000  keyword_ko.txt
