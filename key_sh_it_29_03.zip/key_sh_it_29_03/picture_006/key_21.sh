java -jar getLatinTag.jar it it "feigl" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "noticia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "necrologicas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secret" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "braianator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brachetto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giacomo" 1000  keyword_it.txt
