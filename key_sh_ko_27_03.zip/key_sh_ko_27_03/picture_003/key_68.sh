java -jar getLatinTag.jar kr ko "替" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "否" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "齢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "契" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "譲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陽" 1000  keyword_ko.txt
