java -jar getLatinTag.jar kr ko "環" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "充" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "込" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "細" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "適" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "応" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兒" 1000  keyword_ko.txt
