java -jar getLatinTag.jar it it "cometa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appiccicarsi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piastrelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assessore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piattaforma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aderiscono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riscossione" 1000  keyword_it.txt
