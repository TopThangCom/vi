java -jar getLatinTag.jar fr  fr "devenu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rouge" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mémoire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partenaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rapide" 1000  keyword_fr.txt
