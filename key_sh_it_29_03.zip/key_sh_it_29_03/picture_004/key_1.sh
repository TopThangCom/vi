java -jar getLatinTag.jar it it "contemplativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascidian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ciona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tunicates" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coloniales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascidiate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascidie" 1000  keyword_it.txt
