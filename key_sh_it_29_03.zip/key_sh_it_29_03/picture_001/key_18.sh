java -jar getLatinTag.jar it it "collaborativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spontaneo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agenzia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ec" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "full" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "generator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pretoria" 1000  keyword_it.txt
