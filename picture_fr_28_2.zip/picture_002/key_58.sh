java -jar getLatinTag.jar kr kr "속도제한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "올리기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "느림" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "요금제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "확인방법" 1000  keyword_kr.txt
