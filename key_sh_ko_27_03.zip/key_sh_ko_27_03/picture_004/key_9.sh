java -jar getLatinTag.jar kr ko "玩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "偶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "떡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "볶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뿍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룸" 1000  keyword_ko.txt
