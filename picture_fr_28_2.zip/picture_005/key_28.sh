java -jar getLatinTag.jar kr kr "비상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "천재" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "동아" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지학사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스탠드" 1000  keyword_kr.txt
