java -jar getLatinTag.jar kr ko "鬼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "顧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "満" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "苑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "闘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혇" 1000  keyword_ko.txt
