java -jar getLatinTag.jar it it "accessible" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accommodate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accommodation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accommodative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accoras" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accord" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accordion" 1000  keyword_it.txt
