java -jar getLatinTag.jar kr ko "범" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "円" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "乗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "획" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "련" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "헌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "럼" 1000  keyword_ko.txt
