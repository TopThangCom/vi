java -jar getLatinTag.jar fr  fr "correctement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pub" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Dominique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Tant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "accessible" 1000  keyword_fr.txt
