java -jar getLatinTag.jar kr kr "구태언" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "上杉隼人" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "翻訳" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "上杉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "隼人" 1000  keyword_kr.txt
