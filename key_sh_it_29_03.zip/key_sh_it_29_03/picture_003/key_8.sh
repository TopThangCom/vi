java -jar getLatinTag.jar it it "eritrocitarias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "leucocitarias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ccp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "seco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anoro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anoscope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anoscopy" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anosim" 1000  keyword_it.txt
