java -jar getLatinTag.jar it it "occitanie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "operat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cliente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "associates" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atletico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "il" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiscali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "successivi" 1000  keyword_it.txt
