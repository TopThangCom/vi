java -jar getLatinTag.jar it it "edina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avimportsoficial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonoro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biscoito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartoon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dip" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avvicinandoci" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cominciammo" 1000  keyword_it.txt
