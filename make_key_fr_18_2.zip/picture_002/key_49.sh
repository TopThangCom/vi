java -jar getLatinTag.jar fr  fr "vos" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jeu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "J'" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "petites" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marketing" 1000  keyword_fr.txt
