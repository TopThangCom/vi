java -jar getLatinTag.jar kr kr "허웅" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "허훈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "花王" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cm曲" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "歴代" 1000  keyword_kr.txt
