java -jar getLatinTag.jar kr ko "략" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "틱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "노" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "행" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "면" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "참" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "및" 1000  keyword_ko.txt
