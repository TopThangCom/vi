java -jar getLatinTag.jar kr kr "예상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "추측" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "원작" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "극장판" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "데빌" 1000  keyword_kr.txt
