java -jar getLatinTag.jar it it "gallio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distretto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camponotus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campooz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camporaghena" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camporgiano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "finestrat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imperia" 1000  keyword_it.txt
