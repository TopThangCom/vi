java -jar getLatinTag.jar kr kr "시급" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메뉴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오므라이스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이드래곤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "토르" 1000  keyword_kr.txt
