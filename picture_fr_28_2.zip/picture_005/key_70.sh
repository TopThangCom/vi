java -jar getLatinTag.jar kr kr "밝기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조절" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "mzk" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "xp" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "버전" 1000  keyword_kr.txt
