java -jar getLatinTag.jar fr  fr "table" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nettement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "questions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'avoir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "permettre" 1000  keyword_fr.txt
