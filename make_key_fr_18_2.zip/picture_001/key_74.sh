java -jar getLatinTag.jar fr  fr "Paris" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sorte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "décembre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Son" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suite" 1000  keyword_fr.txt
