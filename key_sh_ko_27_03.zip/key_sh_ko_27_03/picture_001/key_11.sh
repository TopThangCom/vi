java -jar getLatinTag.jar kr ko "율" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "작" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "헤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "랩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "소" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "디" 1000  keyword_ko.txt
