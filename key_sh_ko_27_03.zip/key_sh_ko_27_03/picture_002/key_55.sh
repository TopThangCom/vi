java -jar getLatinTag.jar kr ko "隣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "台" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "出" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "액" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "김" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "산" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "점" 1000  keyword_ko.txt
