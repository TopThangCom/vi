java -jar getLatinTag.jar it it "assecont" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assedic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assefaz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assegond" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assegonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalanes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "qualitat" 1000  keyword_it.txt
