java -jar getLatinTag.jar fr  fr "réalise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "FRF" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "évolution" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Cour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "automobile" 1000  keyword_fr.txt
