java -jar getLatinTag.jar it it "collaert" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adrianne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "celentano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giannini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pappalardo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pintor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gibsonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pinto" 1000  keyword_it.txt
