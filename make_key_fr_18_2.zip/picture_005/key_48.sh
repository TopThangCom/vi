java -jar getLatinTag.jar fr  fr "cote" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Plusieurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "beauté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "exclusivement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lettre" 1000  keyword_fr.txt
