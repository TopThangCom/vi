java -jar getLatinTag.jar kr ko "反" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "굵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "建" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "手" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "峻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "選" 1000  keyword_ko.txt
