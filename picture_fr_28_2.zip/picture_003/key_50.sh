java -jar getLatinTag.jar kr kr "父" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "教科書" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "本名" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "韓国" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "楽天" 1000  keyword_kr.txt
