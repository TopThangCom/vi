java -jar getLatinTag.jar it it "antiodorante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascellare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorbico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "potente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tireoideana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticorpos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "superior" 1000  keyword_it.txt
