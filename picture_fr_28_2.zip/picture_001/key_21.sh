java -jar getLatinTag.jar kr kr "삭제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비우기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변경" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "설정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "늘리기" 1000  keyword_kr.txt
