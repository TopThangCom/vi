java -jar getLatinTag.jar fr  fr "est-elle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gagne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mari" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "préparer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "purement" 1000  keyword_fr.txt
