java -jar getLatinTag.jar kr ko "郁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鬱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "侯" 1000  keyword_ko.txt
