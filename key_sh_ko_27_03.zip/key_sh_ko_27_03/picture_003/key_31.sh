java -jar getLatinTag.jar kr ko "曬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "든" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "살" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쭈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "덱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쪽" 1000  keyword_ko.txt
