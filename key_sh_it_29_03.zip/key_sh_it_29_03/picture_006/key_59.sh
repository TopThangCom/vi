java -jar getLatinTag.jar it it "brescellum" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bresciatoday" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cuoco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fall" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brianorenata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "briantel" 1000  keyword_it.txt
