java -jar getLatinTag.jar kr ko "餐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "提" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "分" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "槽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "髮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "絲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紋" 1000  keyword_ko.txt
