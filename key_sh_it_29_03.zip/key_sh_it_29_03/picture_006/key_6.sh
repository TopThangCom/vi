java -jar getLatinTag.jar it it "coleta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arboricola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capitaine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassavola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "notting" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassestolar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gireoudiana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassicales" 1000  keyword_it.txt
