java -jar getLatinTag.jar kr ko "氨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蒙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "萍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薦" 1000  keyword_ko.txt
