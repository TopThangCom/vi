java -jar getLatinTag.jar kr ko "涌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "封" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "珍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "跳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盆" 1000  keyword_ko.txt
