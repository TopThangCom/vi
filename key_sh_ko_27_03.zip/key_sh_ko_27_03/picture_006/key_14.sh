java -jar getLatinTag.jar kr ko "崙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "攝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "荔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瀛" 1000  keyword_ko.txt
