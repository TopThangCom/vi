java -jar getLatinTag.jar kr kr "인벤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리본" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "돼지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "폴라로이드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "족보" 1000  keyword_kr.txt
