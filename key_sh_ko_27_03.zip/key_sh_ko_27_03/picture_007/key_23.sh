java -jar getLatinTag.jar kr ko "籃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "묻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "齡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "饅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "堅" 1000  keyword_ko.txt
