java -jar getLatinTag.jar it it "esempio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vazio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apollo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apollonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rabattcode" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "eletrico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iscap" 1000  keyword_it.txt
