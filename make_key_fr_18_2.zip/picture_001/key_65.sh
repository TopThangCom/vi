java -jar getLatinTag.jar fr  fr "nouvelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Elle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'on" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "terme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avait" 1000  keyword_fr.txt
