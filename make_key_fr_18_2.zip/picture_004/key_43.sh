java -jar getLatinTag.jar fr  fr "parc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Delhaize" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "the" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Lors" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "limitée" 1000  keyword_fr.txt
