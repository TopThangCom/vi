java -jar getLatinTag.jar it it "branchial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartoons" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brancolano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cabillaud" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petroio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artefatos" 1000  keyword_it.txt
