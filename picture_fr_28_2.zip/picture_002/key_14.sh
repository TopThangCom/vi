java -jar getLatinTag.jar kr kr "실전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레지던트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이블" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "출연진" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리메이크" 1000  keyword_kr.txt
