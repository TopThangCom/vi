java -jar getLatinTag.jar fr  fr "européenne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moyenne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "loi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "petite" 1000  keyword_fr.txt
