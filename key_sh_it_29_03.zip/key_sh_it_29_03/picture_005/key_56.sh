java -jar getLatinTag.jar it it "divierto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "suco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chilena" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aviamentos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avianca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aviator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avicidal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inmunologia" 1000  keyword_it.txt
