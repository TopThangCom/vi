java -jar getLatinTag.jar kr ko "팥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "堵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嗚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "倫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歇" 1000  keyword_ko.txt
