java -jar getLatinTag.jar it it "bronzina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brocoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "romanesco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broscating" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brosella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sec" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pictogramme" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "picchi" 1000  keyword_it.txt
