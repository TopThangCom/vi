java -jar getLatinTag.jar fr  fr "gestionnaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bénéficie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "procédé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vaste" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "crois" 1000  keyword_fr.txt
