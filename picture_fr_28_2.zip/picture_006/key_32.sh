java -jar getLatinTag.jar kr kr "창문" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사무실" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ktm모바일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쉐어링" 1000  keyword_kr.txt
