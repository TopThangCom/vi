java -jar getLatinTag.jar it it "simone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "simaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinecartaz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amorelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoremall" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoreodio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoresecco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corato" 1000  keyword_it.txt
