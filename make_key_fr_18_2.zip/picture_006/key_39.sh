java -jar getLatinTag.jar fr  fr "gestionnaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "né" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "profession" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qualités" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conscience" 1000  keyword_fr.txt
