java -jar getLatinTag.jar kr kr "윤고딕" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "深圳嘉华利电子有限公司" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "台積電" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ks" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시험편" 1000  keyword_kr.txt
