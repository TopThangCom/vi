java -jar getLatinTag.jar kr kr "템플릿" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전략" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "도출" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마케팅" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스타벅스" 1000  keyword_kr.txt
