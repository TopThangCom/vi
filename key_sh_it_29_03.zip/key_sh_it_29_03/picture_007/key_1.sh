java -jar getLatinTag.jar it it "aquatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "midifile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cascharia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coleccionismo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gonzalo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caseggiato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caseggini" 1000  keyword_it.txt
