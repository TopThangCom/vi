java -jar getLatinTag.jar kr ko "熟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "緊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "철" 1000  keyword_ko.txt
