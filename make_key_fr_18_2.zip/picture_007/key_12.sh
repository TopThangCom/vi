java -jar getLatinTag.jar fr  fr "relevé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tenté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Est-ce" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Musée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "W" 1000  keyword_fr.txt
