java -jar getLatinTag.jar fr  fr "d'Etat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "allemand" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "effets" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Chine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "meilleurs" 1000  keyword_fr.txt
