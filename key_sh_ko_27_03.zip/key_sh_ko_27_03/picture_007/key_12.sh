java -jar getLatinTag.jar kr ko "橫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "駁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "樣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "篤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "였" 1000  keyword_ko.txt
