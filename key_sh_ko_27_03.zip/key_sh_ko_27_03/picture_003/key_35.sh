java -jar getLatinTag.jar kr ko "찰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "똥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "긴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "균" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "히" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "값" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찧" 1000  keyword_ko.txt
