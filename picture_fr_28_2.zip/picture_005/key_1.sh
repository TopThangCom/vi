java -jar getLatinTag.jar kr kr "不動産" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "人数" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "th" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발음" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "테스트" 1000  keyword_kr.txt
