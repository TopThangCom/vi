java -jar getLatinTag.jar it it "bromopentane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromopentanol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ipratropio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "otilonio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dimeticona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sodio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncalt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncatox" 1000  keyword_it.txt
