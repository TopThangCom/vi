java -jar getLatinTag.jar fr  fr "régional" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faites" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "italien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "restera" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "usine" 1000  keyword_fr.txt
