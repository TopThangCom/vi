java -jar getLatinTag.jar it it "adecca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ubb" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adecco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rochelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assessoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medicon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ressonancia" 1000  keyword_it.txt
