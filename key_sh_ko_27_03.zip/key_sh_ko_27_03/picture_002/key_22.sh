java -jar getLatinTag.jar kr ko "檢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "單" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "字" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "던" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "난" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "里" 1000  keyword_ko.txt
