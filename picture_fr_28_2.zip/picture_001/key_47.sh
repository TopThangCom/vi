java -jar getLatinTag.jar kr kr "ai" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "역량" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "후기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이플" 1000  keyword_kr.txt
