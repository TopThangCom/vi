java -jar getLatinTag.jar fr  fr "possibilité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "presse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "affaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "longue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "travers" 1000  keyword_fr.txt
