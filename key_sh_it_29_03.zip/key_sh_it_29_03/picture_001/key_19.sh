java -jar getLatinTag.jar it it "icd" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diallo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diop" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diouf" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diarra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guenaelle" 1000  keyword_it.txt
