java -jar getLatinTag.jar kr kr "안하고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "없이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "출장" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전자" 1000  keyword_kr.txt
