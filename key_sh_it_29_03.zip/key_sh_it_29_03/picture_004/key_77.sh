java -jar getLatinTag.jar it it "codice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "elettrico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "elettronico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nfc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "primera" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solicitud" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricoles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "edition" 1000  keyword_it.txt
