java -jar getLatinTag.jar fr  fr "puis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Vous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aucun" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'un" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'en" 1000  keyword_fr.txt
