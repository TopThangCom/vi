java -jar getLatinTag.jar kr kr "明豊" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "上杉勇人" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "香川" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "勇人" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "隼人瓜苗" 1000  keyword_kr.txt
