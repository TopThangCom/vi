java -jar getLatinTag.jar kr kr "오븐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스마트진단" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배당금" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우선주" 1000  keyword_kr.txt
