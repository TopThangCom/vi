java -jar getLatinTag.jar it it "alimentos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concreto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collagen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adivalor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adivare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unipessoal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infantis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "musica" 1000  keyword_it.txt
