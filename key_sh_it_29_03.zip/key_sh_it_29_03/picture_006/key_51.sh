java -jar getLatinTag.jar it it "trifil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "condensazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pellet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "elettrica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fucecchio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "consigliato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caldav" 1000  keyword_it.txt
