java -jar getLatinTag.jar kr ko "伸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "埋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "審" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "輕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "螺" 1000  keyword_ko.txt
