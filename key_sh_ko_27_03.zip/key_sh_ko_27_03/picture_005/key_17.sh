java -jar getLatinTag.jar kr ko "뮨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "흡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蟹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쳐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伍" 1000  keyword_ko.txt
