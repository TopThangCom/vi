java -jar getLatinTag.jar fr  fr "Non" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "soir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Prix" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "machine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "penser" 1000  keyword_fr.txt
