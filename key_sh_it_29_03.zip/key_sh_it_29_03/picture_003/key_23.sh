java -jar getLatinTag.jar it it "vollard" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vinca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambrosetti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discord" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legnano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "delle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambrosianische" 1000  keyword_it.txt
