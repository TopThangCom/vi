java -jar getLatinTag.jar kr ko "본" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "돼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "지" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "족" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "장" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "실" 1000  keyword_ko.txt
