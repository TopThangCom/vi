java -jar getLatinTag.jar it it "abortant" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medication" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "radiologie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rosca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tipo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cifra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gratuitos" 1000  keyword_it.txt
