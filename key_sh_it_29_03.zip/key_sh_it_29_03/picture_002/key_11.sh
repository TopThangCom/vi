java -jar getLatinTag.jar it it "companion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aicomp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scientific" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "familiale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "naturelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "principale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "familial" 1000  keyword_it.txt
