java -jar getLatinTag.jar kr kr "半自動溶接" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "電流" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무스너클" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "패딩" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일진" 1000  keyword_kr.txt
