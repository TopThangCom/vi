java -jar getLatinTag.jar kr ko "漢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "條" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "답" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "只" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "녹" 1000  keyword_ko.txt
