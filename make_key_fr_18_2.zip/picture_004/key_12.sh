java -jar getLatinTag.jar fr  fr "suivant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "efficace" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "assurer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "images" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "agences" 1000  keyword_fr.txt
