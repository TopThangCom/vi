java -jar getLatinTag.jar kr kr "ksb" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "송풍기시험" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검사방법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "vi" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단축키" 1000  keyword_kr.txt
