java -jar getLatinTag.jar kr kr "무엇이든" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "물어보살" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바람" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하린이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하린이네" 1000  keyword_kr.txt
