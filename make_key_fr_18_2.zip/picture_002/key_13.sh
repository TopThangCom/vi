java -jar getLatinTag.jar fr  fr "décidé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mouvement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conseil" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nécessaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "meilleur" 1000  keyword_fr.txt
