java -jar getLatinTag.jar it it "corazones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "net" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sci" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "senior" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "panzer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "digital" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sirignano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "eletronica" 1000  keyword_it.txt
