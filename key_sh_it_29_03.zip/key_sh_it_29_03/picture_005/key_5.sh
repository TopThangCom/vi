java -jar getLatinTag.jar it it "automociones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catoira" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "involutivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autonat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autonomadi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoportal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoproclamata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "repubblica" 1000  keyword_it.txt
