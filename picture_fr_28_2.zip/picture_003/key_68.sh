java -jar getLatinTag.jar kr kr "디자인을" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "저장할" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안전선" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공모전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "분쟁" 1000  keyword_kr.txt
