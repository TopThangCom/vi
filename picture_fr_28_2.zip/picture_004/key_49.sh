java -jar getLatinTag.jar kr kr "alc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "블럭" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시공" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "규격" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무게" 1000  keyword_kr.txt
