java -jar getLatinTag.jar fr  fr "plats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vingtaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'expérience" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "virus" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Faut-il" 1000  keyword_fr.txt
