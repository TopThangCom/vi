java -jar getLatinTag.jar kr kr "윈도우" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "mmf" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변환" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "唐揚げ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英語で説明" 1000  keyword_kr.txt
