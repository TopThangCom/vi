java -jar getLatinTag.jar it it "bequantic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bescanonina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "identification" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comalcalco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biacore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montebelluna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "potenti" 1000  keyword_it.txt
