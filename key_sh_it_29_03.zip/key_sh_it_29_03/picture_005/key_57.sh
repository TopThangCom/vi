java -jar getLatinTag.jar it it "ascsacca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "estimator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asdifica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "auditores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asegolf" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asegollo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asegonia" 1000  keyword_it.txt
