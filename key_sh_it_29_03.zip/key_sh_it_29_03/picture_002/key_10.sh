java -jar getLatinTag.jar it it "dio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "girona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sacrament" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accordi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spartito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canzone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cabinet" 1000  keyword_it.txt
