java -jar getLatinTag.jar kr ko "冊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "女" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "悪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "干" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "五" 1000  keyword_ko.txt
