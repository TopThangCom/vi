java -jar getLatinTag.jar kr kr "面积" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "养殖" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "温泉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "家" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "式观元始" 1000  keyword_kr.txt
