java -jar getLatinTag.jar kr ko "演" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "湯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "綠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "胎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "週" 1000  keyword_ko.txt
