java -jar getLatinTag.jar kr kr "상품권" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하이포인트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "라운지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "플래티늄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "연회비" 1000  keyword_kr.txt
