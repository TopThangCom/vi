java -jar getLatinTag.jar it it "anticondensspray" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticondensvilt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antitiroidals" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nerimo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comunes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sertralin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atipici" 1000  keyword_it.txt
