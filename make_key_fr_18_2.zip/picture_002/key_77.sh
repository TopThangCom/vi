java -jar getLatinTag.jar fr  fr "filiale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "film" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "h" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "besoin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mode" 1000  keyword_fr.txt
