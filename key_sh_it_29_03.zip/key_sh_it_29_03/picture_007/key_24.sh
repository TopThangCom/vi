java -jar getLatinTag.jar it it "coto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "puffer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campereve" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camperis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camperiz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campersite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giglio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campesinato" 1000  keyword_it.txt
