java -jar getLatinTag.jar it it "caseta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giardino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compagnie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comet" 1000  keyword_it.txt
