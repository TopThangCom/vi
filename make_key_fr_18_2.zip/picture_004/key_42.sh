java -jar getLatinTag.jar fr  fr "néerlandais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "supplémentaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mots" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "reprises" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nécessaires" 1000  keyword_fr.txt
