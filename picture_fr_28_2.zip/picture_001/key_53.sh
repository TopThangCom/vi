java -jar getLatinTag.jar kr kr "종류" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "남자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영어로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "반티" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "염색" 1000  keyword_kr.txt
