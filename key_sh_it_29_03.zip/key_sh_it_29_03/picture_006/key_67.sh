java -jar getLatinTag.jar it it "bralimpia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distanza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magenta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tempietto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "esercitazioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pittore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cortona" 1000  keyword_it.txt
