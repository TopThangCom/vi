java -jar getLatinTag.jar kr ko "鬆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "艦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "姚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "凌" 1000  keyword_ko.txt
