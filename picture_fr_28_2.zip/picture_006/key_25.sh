java -jar getLatinTag.jar kr kr "化粧水" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "成分" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "潤い不足" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "asia" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이클립스" 1000  keyword_kr.txt
