java -jar getLatinTag.jar kr kr "계약" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관리감독에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지침" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "별지" 1000  keyword_kr.txt
