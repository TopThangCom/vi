java -jar getLatinTag.jar fr  fr "employés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sites" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "élections" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "détient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'importe" 1000  keyword_fr.txt
