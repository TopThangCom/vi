java -jar getLatinTag.jar kr kr "해지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "위약금" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해지방어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "계산" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "신청" 1000  keyword_kr.txt
