java -jar getLatinTag.jar kr kr "초안" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공공기관" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "국민연금" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "투자자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관점" 1000  keyword_kr.txt
