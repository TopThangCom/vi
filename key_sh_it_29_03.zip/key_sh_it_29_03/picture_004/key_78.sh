java -jar getLatinTag.jar it it "discussion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "matricidio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pallares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "romanel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rommanel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italicized" 1000  keyword_it.txt
