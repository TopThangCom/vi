java -jar getLatinTag.jar kr kr "調べ学習" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "啓林館" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "東京書籍" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "教科書内容" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "植物の発芽と成長" 1000  keyword_kr.txt
