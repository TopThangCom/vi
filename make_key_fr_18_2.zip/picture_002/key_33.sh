java -jar getLatinTag.jar fr  fr "Pas" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "représente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réalité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "femme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vaut" 1000  keyword_fr.txt
