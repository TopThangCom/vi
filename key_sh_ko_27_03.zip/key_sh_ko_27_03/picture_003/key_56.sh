java -jar getLatinTag.jar kr ko "웜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뱃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "욕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "붕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "凍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "櫃" 1000  keyword_ko.txt
