java -jar getLatinTag.jar kr kr "역할" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "액체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배양" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "만드는" 1000  keyword_kr.txt
