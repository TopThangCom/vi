java -jar getLatinTag.jar kr kr "新管肺炎症状" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "心眼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "张一山" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "宋妍霏" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "eps" 1000  keyword_kr.txt
