java -jar getLatinTag.jar it it "asquenazita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asquenazites" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dialnet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "millonario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assabile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "votorantim" 1000  keyword_it.txt
