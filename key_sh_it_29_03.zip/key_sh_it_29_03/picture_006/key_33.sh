java -jar getLatinTag.jar it it "brassicaretm" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassinazole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassolaelia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "limpia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassolinae" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassolini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassolution" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brassovation" 1000  keyword_it.txt
