java -jar getLatinTag.jar it it "anochecia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "positive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "negative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anodermprolaps" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "titanio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catodo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sacrificio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "genetica" 1000  keyword_it.txt
