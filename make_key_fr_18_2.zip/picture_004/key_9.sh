java -jar getLatinTag.jar fr  fr "recours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'esprit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Communauté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "annuelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "T" 1000  keyword_fr.txt
