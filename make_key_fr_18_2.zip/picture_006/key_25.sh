java -jar getLatinTag.jar fr  fr "relative" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "actuels" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "envie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'équipe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ministres" 1000  keyword_fr.txt
