java -jar getLatinTag.jar kr kr "飯塚" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "魁晟" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "咲" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "崎村組" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "北川工業" 1000  keyword_kr.txt
