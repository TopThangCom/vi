java -jar getLatinTag.jar it it "colegial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asivecam" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asmatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pdi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asmodianprince" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petroil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecuatorial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asogolf" 1000  keyword_it.txt
