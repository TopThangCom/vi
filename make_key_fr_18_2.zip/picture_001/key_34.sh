java -jar getLatinTag.jar fr  fr "des" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "en" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "un" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "du" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "une" 1000  keyword_fr.txt
