java -jar getLatinTag.jar kr kr "한글패치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "컬렉션" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단테" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "애니" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "애니메이션" 1000  keyword_kr.txt
