java -jar getLatinTag.jar it it "aporetica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporetico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporetisch" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aporomantic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardiosperma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dioica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "beneficiario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colpensiones" 1000  keyword_it.txt
