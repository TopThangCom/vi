java -jar getLatinTag.jar kr ko "팁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "摺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "갈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蛄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "也" 1000  keyword_ko.txt
