java -jar getLatinTag.jar kr kr "落地冰溫熱純水飲水機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "理科" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "林製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鰐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "m-filter@cloud" 1000  keyword_kr.txt
