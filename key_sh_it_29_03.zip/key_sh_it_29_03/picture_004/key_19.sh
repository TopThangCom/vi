java -jar getLatinTag.jar it it "accesorios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distroller" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bocconi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spinea" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stezzano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "villafranca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "triton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gloss" 1000  keyword_it.txt
