java -jar getLatinTag.jar kr ko "姉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瞼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蒜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "縣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "晩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "헐" 1000  keyword_ko.txt
