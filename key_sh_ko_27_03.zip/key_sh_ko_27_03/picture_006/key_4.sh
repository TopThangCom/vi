java -jar getLatinTag.jar kr ko "俸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "犁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "噪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "簇" 1000  keyword_ko.txt
