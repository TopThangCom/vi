java -jar getLatinTag.jar it it "laboratorios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cologne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "androstenolone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "androstenone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "testosterone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "androstenediona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anecdotal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anemia" 1000  keyword_it.txt
