java -jar getLatinTag.jar kr kr "마스터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사용법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "저작권" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "맞추기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수상" 1000  keyword_kr.txt
