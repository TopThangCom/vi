java -jar getLatinTag.jar kr kr "jfe" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "有価証券報告書" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "統合報告書" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버와" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국사이버결제" 1000  keyword_kr.txt
