java -jar getLatinTag.jar it it "svalutazioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autovetture" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avviamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "impianto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fotovoltaico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italiano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "limpio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cadiz" 1000  keyword_it.txt
