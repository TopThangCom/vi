java -jar getLatinTag.jar fr  fr "demandé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "respect" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "continuer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'organisation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lesquelles" 1000  keyword_fr.txt
