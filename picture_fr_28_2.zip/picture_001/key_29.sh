java -jar getLatinTag.jar kr kr "방법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실패" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메일함" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "용량" 1000  keyword_kr.txt
