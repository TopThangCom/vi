java -jar getLatinTag.jar it it "clips" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "braidotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "braincapitol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "esercito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "posit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brazzaville" 1000  keyword_it.txt
