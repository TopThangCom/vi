java -jar getLatinTag.jar it it "fabian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "servicio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sabbione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montegallo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "senatore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "certifications" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anteriore" 1000  keyword_it.txt
