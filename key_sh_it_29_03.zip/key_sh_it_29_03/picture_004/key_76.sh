java -jar getLatinTag.jar it it "nea" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chillan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conchali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giorgini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personaggi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pinotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricioppo" 1000  keyword_it.txt
