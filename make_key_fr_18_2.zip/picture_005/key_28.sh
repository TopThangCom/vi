java -jar getLatinTag.jar fr  fr "connaissent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "reprendre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "village" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "emploi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "amis" 1000  keyword_fr.txt
