java -jar getLatinTag.jar kr kr "北方" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "组" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "爱情保卫战" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "最新" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "반딧불이의" 1000  keyword_kr.txt
