java -jar getLatinTag.jar fr  fr "l'investissement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lié" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "zones" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aime" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lettres" 1000  keyword_fr.txt
