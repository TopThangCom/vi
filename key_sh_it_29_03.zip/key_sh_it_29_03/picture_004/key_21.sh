java -jar getLatinTag.jar it it "compleanno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contatti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pescantina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caldogno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquarelliste" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquarellstaffeleien" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquarevalidatie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ciumento" 1000  keyword_it.txt
