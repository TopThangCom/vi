java -jar getLatinTag.jar kr kr "歌詞" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "お座敷青梅奥多摩号" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "予約方法" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "液体試料用電極" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "色即是空" 1000  keyword_kr.txt
