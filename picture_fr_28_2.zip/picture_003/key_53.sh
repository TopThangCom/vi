java -jar getLatinTag.jar kr kr "剣道部" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "企業" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "企業内保育" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "工業団地" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "水上公園" 1000  keyword_kr.txt
