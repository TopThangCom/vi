java -jar getLatinTag.jar kr ko "롬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "끄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "록" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "독" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "목" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "守" 1000  keyword_ko.txt
