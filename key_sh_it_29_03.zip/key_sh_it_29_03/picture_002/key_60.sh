java -jar getLatinTag.jar it it "adonit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "note" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adonitology" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sostantivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adoperarsi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adoperator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adoperato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pizza" 1000  keyword_it.txt
