java -jar getLatinTag.jar it it "interiores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pergola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gratuito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piscine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abritant" 1000  keyword_it.txt
