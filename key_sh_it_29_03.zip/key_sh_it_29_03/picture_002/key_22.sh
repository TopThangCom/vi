java -jar getLatinTag.jar it it "criminalista" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diabo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aecomic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aecomposite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aemcolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "components" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fanart" 1000  keyword_it.txt
