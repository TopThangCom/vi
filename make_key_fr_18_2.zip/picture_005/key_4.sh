java -jar getLatinTag.jar fr  fr "veille" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "difficulté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'état" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "limites" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commerciales" 1000  keyword_fr.txt
