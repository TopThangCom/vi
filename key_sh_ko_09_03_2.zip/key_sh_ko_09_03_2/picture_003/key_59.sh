java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "̓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "պ" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "읂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "]" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "	" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "땢" 1000  keyword_ko.txt
