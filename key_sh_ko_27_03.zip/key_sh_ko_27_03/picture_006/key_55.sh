java -jar getLatinTag.jar kr ko "蕈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "餅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蔭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "尖" 1000  keyword_ko.txt
