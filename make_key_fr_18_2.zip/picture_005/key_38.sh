java -jar getLatinTag.jar fr  fr "l'été" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "changé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "masse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "unités" 1000  keyword_fr.txt
