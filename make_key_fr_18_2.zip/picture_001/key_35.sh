java -jar getLatinTag.jar fr  fr "cet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chaque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chiffre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pourrait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devrait" 1000  keyword_fr.txt
