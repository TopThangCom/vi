java -jar getLatinTag.jar fr  fr "peine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "certain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "septembre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sommes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "famille" 1000  keyword_fr.txt
