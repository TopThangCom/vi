java -jar getLatinTag.jar kr kr "英語訳" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "文" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "類語" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "好喜欢你知不知道" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "遺伝子" 1000  keyword_kr.txt
