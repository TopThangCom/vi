java -jar getLatinTag.jar it it "lll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cheqara" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdelbasset" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdessattar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "opiniones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "soria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regions" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distension" 1000  keyword_it.txt
