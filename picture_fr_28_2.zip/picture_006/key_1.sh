java -jar getLatinTag.jar kr kr "하이닉스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자소서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "식단" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하리니스콘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하리나" 1000  keyword_kr.txt
