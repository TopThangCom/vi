java -jar getLatinTag.jar kr ko "転" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "職" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "進" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "向" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "許" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麒" 1000  keyword_ko.txt
