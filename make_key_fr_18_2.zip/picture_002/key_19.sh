java -jar getLatinTag.jar fr  fr "taille" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "éviter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "risques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Jean" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Pourtant" 1000  keyword_fr.txt
