java -jar getLatinTag.jar it it "recessivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "xlascending" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artigo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tratar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alossomico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "somatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autossuficiente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiori" 1000  keyword_it.txt
