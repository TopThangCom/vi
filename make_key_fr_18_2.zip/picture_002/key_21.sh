java -jar getLatinTag.jar fr  fr "puisque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Du" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "reprise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "compris" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "projets" 1000  keyword_fr.txt
