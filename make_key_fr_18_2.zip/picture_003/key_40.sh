java -jar getLatinTag.jar fr  fr "protection" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'aide" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "couleur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nouvel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Lorsque" 1000  keyword_fr.txt
