java -jar getLatinTag.jar kr ko "占" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "添" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "널" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "건" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "례" 1000  keyword_ko.txt
