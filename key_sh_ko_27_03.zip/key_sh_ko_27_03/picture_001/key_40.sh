java -jar getLatinTag.jar kr ko "현" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "피" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "구" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "대" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "월" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "코" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "버" 1000  keyword_ko.txt
