java -jar getLatinTag.jar fr  fr "certaines" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "savoir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "loin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "explique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plupart" 1000  keyword_fr.txt
