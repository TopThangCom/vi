java -jar getLatinTag.jar kr ko "매" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "잘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "못" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "되" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "었" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "습" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訓" 1000  keyword_ko.txt
