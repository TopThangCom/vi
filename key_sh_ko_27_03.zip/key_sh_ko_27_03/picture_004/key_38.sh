java -jar getLatinTag.jar kr ko "碰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "碧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "著" 1000  keyword_ko.txt
