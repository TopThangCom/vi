java -jar getLatinTag.jar kr ko "甲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "府" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "下" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "綜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "合" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "擴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "葵" 1000  keyword_ko.txt
