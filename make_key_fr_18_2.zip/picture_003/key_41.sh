java -jar getLatinTag.jar fr  fr "ait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bonnes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "opérations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pied" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'art" 1000  keyword_fr.txt
