java -jar getLatinTag.jar kr kr "CSA" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "貼吧" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "意思" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "題跋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "團霸" 1000  keyword_kr.txt
