java -jar getLatinTag.jar kr ko "駒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "잠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "텟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "魅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "猜" 1000  keyword_ko.txt
