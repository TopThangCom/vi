java -jar getLatinTag.jar fr  fr "secondes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "CGER" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contenu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quotidien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "flamande" 1000  keyword_fr.txt
