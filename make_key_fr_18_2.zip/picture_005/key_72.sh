java -jar getLatinTag.jar fr  fr "anglais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'ai" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "présentent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "décisions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "législation" 1000  keyword_fr.txt
