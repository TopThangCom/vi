java -jar getLatinTag.jar it it "periorali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sulla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "occhi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "occhio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arrossato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cranca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antoni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "transitivo" 1000  keyword_it.txt
