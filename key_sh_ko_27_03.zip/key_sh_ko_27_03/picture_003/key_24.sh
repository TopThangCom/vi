java -jar getLatinTag.jar kr ko "쓰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쇄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "컴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "롭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탠" 1000  keyword_ko.txt
