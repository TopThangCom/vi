java -jar getLatinTag.jar kr kr "u+" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하락" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채용연계형" 1000  keyword_kr.txt
