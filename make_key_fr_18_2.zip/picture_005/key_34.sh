java -jar getLatinTag.jar fr  fr "tourner" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Club" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "attendant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quantité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "roi" 1000  keyword_fr.txt
