java -jar getLatinTag.jar fr  fr "Sans" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "américaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "face" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trouver" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "durant" 1000  keyword_fr.txt
