java -jar getLatinTag.jar kr kr "진" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "글자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "혜수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "현피" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개구릿대" 1000  keyword_kr.txt
