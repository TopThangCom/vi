java -jar getLatinTag.jar fr  fr "auraient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "caisse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "simples" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "maladie" 1000  keyword_fr.txt
