java -jar getLatinTag.jar fr  fr "compartiment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "publicitaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "EN" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "article" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bande" 1000  keyword_fr.txt
