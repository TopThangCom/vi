java -jar getLatinTag.jar kr ko "彼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嫌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "應" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "張" 1000  keyword_ko.txt
