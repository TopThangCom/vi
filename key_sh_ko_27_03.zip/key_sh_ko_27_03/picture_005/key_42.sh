java -jar getLatinTag.jar kr ko "렛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "좀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "좋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쏜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "摂" 1000  keyword_ko.txt
