java -jar getLatinTag.jar fr  fr "complet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "danger" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "indispensable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "syndicats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comporte" 1000  keyword_fr.txt
