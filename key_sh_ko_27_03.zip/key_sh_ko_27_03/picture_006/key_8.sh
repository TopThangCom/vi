java -jar getLatinTag.jar kr ko "龜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뭔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "荘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "烹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뜰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旬" 1000  keyword_ko.txt
