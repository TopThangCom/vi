java -jar getLatinTag.jar fr  fr "Jacques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "montre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "population" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "analystes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "S" 1000  keyword_fr.txt
