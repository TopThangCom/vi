java -jar getLatinTag.jar fr  fr "découvert" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'inverse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "différent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "emploie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bleu" 1000  keyword_fr.txt
