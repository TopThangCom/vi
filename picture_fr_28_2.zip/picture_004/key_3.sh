java -jar getLatinTag.jar kr kr "포함" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파일을" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "열" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "열처리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "경도" 1000  keyword_kr.txt
