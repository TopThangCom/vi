java -jar getLatinTag.jar it it "canicom" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calming" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canicompet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canillac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ideia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "revestimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cannabinoides" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cannondale" 1000  keyword_it.txt
