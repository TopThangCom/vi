java -jar getLatinTag.jar fr  fr "magasin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "candidats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marges" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "asiatique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "inférieur" 1000  keyword_fr.txt
