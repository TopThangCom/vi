java -jar getLatinTag.jar kr kr "天気の変化" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "電磁石" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "人の誕生" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ipa" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "dx推進指標" 1000  keyword_kr.txt
