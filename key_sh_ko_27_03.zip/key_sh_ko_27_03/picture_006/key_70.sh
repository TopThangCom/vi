java -jar getLatinTag.jar kr ko "캇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "왼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "슘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "窟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桿" 1000  keyword_ko.txt
