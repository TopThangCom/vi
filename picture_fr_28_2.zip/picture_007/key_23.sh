java -jar getLatinTag.jar kr kr "PTH" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "붉은" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "흔적" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모코코" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모험의" 1000  keyword_kr.txt
