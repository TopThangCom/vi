java -jar getLatinTag.jar it it "biologics" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rental" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abbreviation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admedicall" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solostar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mitologia" 1000  keyword_it.txt
