java -jar getLatinTag.jar kr ko "物" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "理" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "験" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "則" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "赤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "外" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "線" 1000  keyword_ko.txt
