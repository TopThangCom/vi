java -jar getLatinTag.jar kr ko "釋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "制" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "娛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "樂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "겨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "땀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "댄" 1000  keyword_ko.txt
