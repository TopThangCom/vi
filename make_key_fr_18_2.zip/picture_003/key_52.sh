java -jar getLatinTag.jar fr  fr "pression" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'était" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "style" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "économiques" 1000  keyword_fr.txt
