java -jar getLatinTag.jar it it "fitting" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vittorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giovanni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "terminal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "moll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scrabble" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "finance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unifi" 1000  keyword_it.txt
