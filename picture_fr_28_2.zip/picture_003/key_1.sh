java -jar getLatinTag.jar kr kr "일본" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "항공권" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "할부" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "빅스마일데이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "노트북" 1000  keyword_kr.txt
