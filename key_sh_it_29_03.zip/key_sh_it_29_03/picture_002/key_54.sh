java -jar getLatinTag.jar it it "editorial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "villefranche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sanchez" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adesione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "negoziazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rottamazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "quater" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "portatil" 1000  keyword_it.txt
