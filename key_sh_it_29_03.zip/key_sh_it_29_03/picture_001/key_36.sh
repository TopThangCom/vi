java -jar getLatinTag.jar it it "acorrimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "termino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tanto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inferiormente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "matematicas" 1000  keyword_it.txt
