java -jar getLatinTag.jar kr ko "鎖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "治" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "膚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "約" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "健" 1000  keyword_ko.txt
