java -jar getLatinTag.jar kr ko "끌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "劾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "篡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "凹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "詢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蹊" 1000  keyword_ko.txt
