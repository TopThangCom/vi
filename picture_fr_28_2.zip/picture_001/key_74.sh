java -jar getLatinTag.jar kr kr "안드로이드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "필터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ublock" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비활성화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "끄기" 1000  keyword_kr.txt
