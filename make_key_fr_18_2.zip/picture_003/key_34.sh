java -jar getLatinTag.jar fr  fr "moteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "augmentation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suivi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "volonté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "beau" 1000  keyword_fr.txt
