java -jar getLatinTag.jar it it "funzioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "istologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ormoni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prostatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cistica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "odontogener" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "odontogenic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fallopian" 1000  keyword_it.txt
