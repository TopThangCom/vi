java -jar getLatinTag.jar kr kr "三井住友銀行" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "atm" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "허나" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "거절한다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cl" 1000  keyword_kr.txt
