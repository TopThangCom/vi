java -jar getLatinTag.jar kr ko "힙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "贈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "熨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "僻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遍" 1000  keyword_ko.txt
