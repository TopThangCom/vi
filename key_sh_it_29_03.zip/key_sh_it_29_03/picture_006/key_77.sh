java -jar getLatinTag.jar it it "metalico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dragonica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bastimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "batidecor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pinerolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "estetoscopio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caterpillar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "volcano" 1000  keyword_it.txt
