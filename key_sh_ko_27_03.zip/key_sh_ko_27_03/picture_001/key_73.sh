java -jar getLatinTag.jar kr ko "曲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "代" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "特" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "后" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "型" 1000  keyword_ko.txt
