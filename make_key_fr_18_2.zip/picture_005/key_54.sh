java -jar getLatinTag.jar fr  fr "considéré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "auront" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "noms" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "riche" 1000  keyword_fr.txt
