java -jar getLatinTag.jar it it "stagnante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anostico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anostomus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalogus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antigone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neonatal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perinatal" 1000  keyword_it.txt
