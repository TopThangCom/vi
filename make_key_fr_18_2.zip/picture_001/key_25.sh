java -jar getLatinTag.jar fr  fr "point" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "grande" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "va" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avoir" 1000  keyword_fr.txt
