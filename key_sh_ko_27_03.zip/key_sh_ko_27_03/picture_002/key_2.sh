java -jar getLatinTag.jar kr ko "밴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "갑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "느" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "요" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "납" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "청" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "샵" 1000  keyword_ko.txt
