java -jar getLatinTag.jar kr ko "少" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "핵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "릉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "着" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "智" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "恆" 1000  keyword_ko.txt
