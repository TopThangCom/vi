java -jar getLatinTag.jar kr kr "usb에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "usb로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "프리미엄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아르헨티나" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우회" 1000  keyword_kr.txt
