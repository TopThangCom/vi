java -jar getLatinTag.jar it it "fasi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "convenzionate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tariffario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "definitiva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assignacions" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "universitat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "configuration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assignedaccess" 1000  keyword_it.txt
