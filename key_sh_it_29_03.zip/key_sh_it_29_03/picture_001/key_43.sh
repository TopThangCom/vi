java -jar getLatinTag.jar it it "adaptivation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scanner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rolle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medicine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcapital" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcapitol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcentralrecords" 1000  keyword_it.txt
