java -jar getLatinTag.jar it it "infantiles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "turistico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "animatamente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capannori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giochi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "animatronic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anisocoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "politico" 1000  keyword_it.txt
