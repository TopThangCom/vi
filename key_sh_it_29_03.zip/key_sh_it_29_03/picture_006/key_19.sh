java -jar getLatinTag.jar it it "antoniotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disciplinare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "palazzina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pianelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "roccia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sportcenter" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brambilla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bramedicafisio" 1000  keyword_it.txt
