java -jar getLatinTag.jar it it "giussano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "puglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aragostelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "traduttore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antiguo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "florianopolis" 1000  keyword_it.txt
