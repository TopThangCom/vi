java -jar getLatinTag.jar kr ko "즈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "내" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "번" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "호" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "報" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "名" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "香" 1000  keyword_ko.txt
