java -jar getLatinTag.jar kr ko "弄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "疹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "焉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "낭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빨" 1000  keyword_ko.txt
