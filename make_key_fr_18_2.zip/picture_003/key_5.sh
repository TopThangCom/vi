java -jar getLatinTag.jar fr  fr "pouvait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "million" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Paul" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "britannique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'entreprises" 1000  keyword_fr.txt
