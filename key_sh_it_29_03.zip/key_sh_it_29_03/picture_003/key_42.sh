java -jar getLatinTag.jar it it "marmiton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anconetti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "partedis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancomarel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancomarine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancomarzioliceo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancon" 1000  keyword_it.txt
