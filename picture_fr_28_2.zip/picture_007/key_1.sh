java -jar getLatinTag.jar kr kr "힘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "절구" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "찧는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이야기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "방아" 1000  keyword_kr.txt
