java -jar getLatinTag.jar kr ko "龍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "減" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "等" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "縮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巴" 1000  keyword_ko.txt
