java -jar getLatinTag.jar fr  fr "demandes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "diversification" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "montré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "renseignements" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "souscription" 1000  keyword_fr.txt
