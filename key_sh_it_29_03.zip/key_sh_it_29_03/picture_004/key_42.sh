java -jar getLatinTag.jar it it "cave" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regurgitation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compression" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pregnancy" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aortocoronario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aortoiliacaler" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcifications" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iliaco" 1000  keyword_it.txt
