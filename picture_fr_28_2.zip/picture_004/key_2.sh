java -jar getLatinTag.jar kr kr "線上藝術字體產生器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "s" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이버" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "킵" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "밴드" 1000  keyword_kr.txt
