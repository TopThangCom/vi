java -jar getLatinTag.jar kr ko "殊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "狄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "狐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "狗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "甚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "甜" 1000  keyword_ko.txt
