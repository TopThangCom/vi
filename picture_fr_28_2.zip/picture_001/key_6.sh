java -jar getLatinTag.jar kr kr "정석" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대회" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "반도체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "원리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시장" 1000  keyword_kr.txt
