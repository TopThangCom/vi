java -jar getLatinTag.jar kr kr "사계절" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "covera-hs錠片屬滲透壓性劑型" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미모" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "방송사고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미드" 1000  keyword_kr.txt
