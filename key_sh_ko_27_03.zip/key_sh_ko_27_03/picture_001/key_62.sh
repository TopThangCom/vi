java -jar getLatinTag.jar kr ko "明" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "王" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "言" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "心" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "危" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "険" 1000  keyword_ko.txt
