java -jar getLatinTag.jar kr ko "研" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "啡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "飛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "過" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "飲" 1000  keyword_ko.txt
