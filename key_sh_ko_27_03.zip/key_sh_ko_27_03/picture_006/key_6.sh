java -jar getLatinTag.jar kr ko "艋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "悲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "黴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "尋" 1000  keyword_ko.txt
