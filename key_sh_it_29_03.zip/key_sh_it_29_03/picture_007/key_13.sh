java -jar getLatinTag.jar it it "casserole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casseroles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "onoranze" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassettes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassettespeler" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassetto" 1000  keyword_it.txt
