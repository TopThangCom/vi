java -jar getLatinTag.jar kr ko "釜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "淑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "靶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "逗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "岳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撕" 1000  keyword_ko.txt
