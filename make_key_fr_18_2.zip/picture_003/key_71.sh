java -jar getLatinTag.jar fr  fr "l'information" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voici" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "effectivement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "puisse" 1000  keyword_fr.txt
