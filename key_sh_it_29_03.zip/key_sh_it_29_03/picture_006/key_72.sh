java -jar getLatinTag.jar it it "antinori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avalanche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bramone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "civic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chianti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "classico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ilatraia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brancaleone" 1000  keyword_it.txt
