java -jar getLatinTag.jar fr  fr "totale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voyage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "logique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'échéance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "concurrents" 1000  keyword_fr.txt
