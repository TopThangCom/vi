java -jar getLatinTag.jar kr kr "臼井彰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "臼井彰一" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "漫画" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "yoon" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가변" 1000  keyword_kr.txt
