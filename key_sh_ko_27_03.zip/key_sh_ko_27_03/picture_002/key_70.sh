java -jar getLatinTag.jar kr ko "換" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "気" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "可" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "搬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "液" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "形" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "振" 1000  keyword_ko.txt
