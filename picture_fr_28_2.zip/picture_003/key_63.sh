java -jar getLatinTag.jar kr kr "発熱外来" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "小児科" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "福岡" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "口コミ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "院長" 1000  keyword_kr.txt
