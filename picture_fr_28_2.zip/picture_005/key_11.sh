java -jar getLatinTag.jar kr kr "하트골드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "三菱布団乾燥機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "使い方" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모음" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "탬신" 1000  keyword_kr.txt
