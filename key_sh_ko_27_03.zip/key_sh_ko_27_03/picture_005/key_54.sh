java -jar getLatinTag.jar kr ko "莉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "譽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "濟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "칩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뱅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앤" 1000  keyword_ko.txt
