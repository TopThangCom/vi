java -jar getLatinTag.jar kr kr "칸나" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이루루" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "엘마" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "루코아" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쇼타" 1000  keyword_kr.txt
