java -jar getLatinTag.jar it it "bromatometrie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromatometrische" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alergia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "epifitas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nero" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cloridrato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromitane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromitapp" 1000  keyword_it.txt
