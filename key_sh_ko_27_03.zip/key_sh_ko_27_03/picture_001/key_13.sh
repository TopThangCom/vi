java -jar getLatinTag.jar kr ko "어" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "추" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "천" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "군" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "바" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "화" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "생" 1000  keyword_ko.txt
