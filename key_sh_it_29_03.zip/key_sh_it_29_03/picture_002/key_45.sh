java -jar getLatinTag.jar it it "generalitat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abreviatura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dissolved" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cisco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prohibited" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personnel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "administratoraccess" 1000  keyword_it.txt
