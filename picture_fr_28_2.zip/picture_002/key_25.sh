java -jar getLatinTag.jar kr kr "아이유" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그해우리는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판매점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오래된" 1000  keyword_kr.txt
