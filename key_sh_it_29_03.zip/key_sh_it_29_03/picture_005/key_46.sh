java -jar getLatinTag.jar it it "acessorar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assessorato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "famiglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cooperazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "istruzione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "formazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "territorio" 1000  keyword_it.txt
