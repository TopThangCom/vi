java -jar getLatinTag.jar kr kr "워드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수학" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "세개" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "중앙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선" 1000  keyword_kr.txt
