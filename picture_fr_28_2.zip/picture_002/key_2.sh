java -jar getLatinTag.jar kr kr "오류" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٤٥×" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "١=٤٥" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "dubox" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "클라우드" 1000  keyword_kr.txt
