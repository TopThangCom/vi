java -jar getLatinTag.jar kr ko "肌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "載" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "知" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "왕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "油" 1000  keyword_ko.txt
