java -jar getLatinTag.jar fr  fr "Certains" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ayant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "papier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commerce" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Région" 1000  keyword_fr.txt
