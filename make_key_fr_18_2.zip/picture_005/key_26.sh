java -jar getLatinTag.jar fr  fr "contribuable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moderne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "passion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "primes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "in" 1000  keyword_fr.txt
