java -jar getLatinTag.jar it it "alliance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concord" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentric" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentroid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentron" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentronic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentsia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascertia" 1000  keyword_it.txt
