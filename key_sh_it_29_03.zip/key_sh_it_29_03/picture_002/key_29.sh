java -jar getLatinTag.jar it it "anticoncepcional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nicotina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vinilico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clientes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dimou" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "music" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cosmetics" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corsa" 1000  keyword_it.txt
