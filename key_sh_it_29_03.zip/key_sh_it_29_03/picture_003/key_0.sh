java -jar getLatinTag.jar it it "amatrol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amavento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cristia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcoi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambarella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "congo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nominations" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "proposal" 1000  keyword_it.txt
