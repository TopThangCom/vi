java -jar getLatinTag.jar kr ko "嵐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "숫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "糙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "綾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "냉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "爸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "姓" 1000  keyword_ko.txt
