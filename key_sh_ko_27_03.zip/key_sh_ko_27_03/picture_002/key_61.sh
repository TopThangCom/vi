java -jar getLatinTag.jar kr ko "現" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "西" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "帰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蔵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "熱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "児" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "科" 1000  keyword_ko.txt
