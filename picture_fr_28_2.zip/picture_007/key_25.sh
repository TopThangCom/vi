java -jar getLatinTag.jar kr kr "오르골" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "협동" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "퀘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "혼자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "프로크리에이트" 1000  keyword_kr.txt
