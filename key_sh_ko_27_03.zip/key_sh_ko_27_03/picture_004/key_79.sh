java -jar getLatinTag.jar kr ko "各" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "庭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "翼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肉" 1000  keyword_ko.txt
