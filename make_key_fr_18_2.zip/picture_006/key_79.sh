java -jar getLatinTag.jar fr  fr "limiter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "livraison" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "placements" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "raconte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "volumes" 1000  keyword_fr.txt
