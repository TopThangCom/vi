java -jar getLatinTag.jar fr  fr "précédente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rose" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "versions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'études" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "destination" 1000  keyword_fr.txt
