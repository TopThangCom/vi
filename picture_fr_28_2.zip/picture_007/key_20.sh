java -jar getLatinTag.jar kr kr "因为所以地址" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "因为所以造句救星" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "因为所以造句英文" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "因为所以造句子" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英文片语" 1000  keyword_kr.txt
