java -jar getLatinTag.jar it it "latero" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mediastinale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mediastino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "peritoneale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "radiopaedia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "difusa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ultrassom" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecografia" 1000  keyword_it.txt
