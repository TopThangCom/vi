java -jar getLatinTag.jar kr ko "넷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "릭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "석" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "논" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "란" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "둑" 1000  keyword_ko.txt
