java -jar getLatinTag.jar fr  fr "caractéristiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Eric" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Union" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "paix" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "puisqu'il" 1000  keyword_fr.txt
