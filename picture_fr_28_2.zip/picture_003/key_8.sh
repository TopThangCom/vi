java -jar getLatinTag.jar kr kr "기호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가운데" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "특수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "곱하기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "루이스" 1000  keyword_kr.txt
