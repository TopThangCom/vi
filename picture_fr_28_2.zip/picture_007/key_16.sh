java -jar getLatinTag.jar kr kr "문제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단원평가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아리랑" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "운동모형" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "초등과학" 1000  keyword_kr.txt
