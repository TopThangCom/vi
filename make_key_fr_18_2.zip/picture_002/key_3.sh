java -jar getLatinTag.jar fr  fr "Car" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Comment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voiture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chef" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constitue" 1000  keyword_fr.txt
