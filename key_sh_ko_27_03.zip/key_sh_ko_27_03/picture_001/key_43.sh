java -jar getLatinTag.jar kr ko "院" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "厚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "労" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "働" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "省" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "看" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "護" 1000  keyword_ko.txt
