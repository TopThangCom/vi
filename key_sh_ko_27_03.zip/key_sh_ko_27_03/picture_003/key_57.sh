java -jar getLatinTag.jar kr ko "슬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "있" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "흉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "녀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "잡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "런" 1000  keyword_ko.txt
