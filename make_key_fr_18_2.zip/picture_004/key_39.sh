java -jar getLatinTag.jar fr  fr "lecteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "objets" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fabricant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "niveaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Entre" 1000  keyword_fr.txt
