java -jar getLatinTag.jar kr ko "四" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "程" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "影" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "締" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塩" 1000  keyword_ko.txt
