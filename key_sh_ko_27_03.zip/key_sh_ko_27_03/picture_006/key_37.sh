java -jar getLatinTag.jar kr ko "鍊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "溜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "褐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "祝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "냐" 1000  keyword_ko.txt
