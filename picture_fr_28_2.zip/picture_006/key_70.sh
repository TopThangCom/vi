java -jar getLatinTag.jar kr kr "리치왕" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하스스톤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "泉肌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "泉肌症" 1000  keyword_kr.txt
