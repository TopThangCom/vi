java -jar getLatinTag.jar fr  fr "parce" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "seul" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'une" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sociétés" 1000  keyword_fr.txt
