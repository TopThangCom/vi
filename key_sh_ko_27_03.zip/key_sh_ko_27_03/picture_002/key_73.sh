java -jar getLatinTag.jar kr ko "팬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "암" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "롱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "착" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "륙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "날" 1000  keyword_ko.txt
