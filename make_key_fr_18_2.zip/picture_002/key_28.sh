java -jar getLatinTag.jar fr  fr "guerre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "acheter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rendre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "février" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ma" 1000  keyword_fr.txt
