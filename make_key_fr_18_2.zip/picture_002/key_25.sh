java -jar getLatinTag.jar fr  fr "faible" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "terrain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "site" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "droits" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moitié" 1000  keyword_fr.txt
