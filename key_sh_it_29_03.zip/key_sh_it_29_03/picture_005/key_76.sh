java -jar getLatinTag.jar it it "fatualis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ategurrola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atemporale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atemporalli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copec" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "telefonicas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atenolol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cristina" 1000  keyword_it.txt
