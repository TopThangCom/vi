java -jar getLatinTag.jar kr ko "集" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "針" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "休" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "笑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "返" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鑑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "親" 1000  keyword_ko.txt
