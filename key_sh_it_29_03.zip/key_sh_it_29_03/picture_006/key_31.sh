java -jar getLatinTag.jar it it "mion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mistico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calderone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calderoni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nenem" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caldonazzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caldorazole" 1000  keyword_it.txt
