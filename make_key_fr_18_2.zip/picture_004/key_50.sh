java -jar getLatinTag.jar fr  fr "droite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "responsabilité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commande" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Kredietbank" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'argent" 1000  keyword_fr.txt
