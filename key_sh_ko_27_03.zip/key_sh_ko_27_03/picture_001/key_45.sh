java -jar getLatinTag.jar kr ko "利" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "益" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "意" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "味" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "橋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "醫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "藍" 1000  keyword_ko.txt
