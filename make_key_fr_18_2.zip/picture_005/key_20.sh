java -jar getLatinTag.jar fr  fr "remboursement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "and" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "efforts" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "restaurant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Toutes" 1000  keyword_fr.txt
