java -jar getLatinTag.jar kr ko "狩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "했" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "냄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "흙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瀏" 1000  keyword_ko.txt
