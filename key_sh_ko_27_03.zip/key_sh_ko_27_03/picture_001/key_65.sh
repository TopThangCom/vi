java -jar getLatinTag.jar kr ko "급" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뉴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "므" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "칸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쇼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "권" 1000  keyword_ko.txt
