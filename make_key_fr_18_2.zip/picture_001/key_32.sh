java -jar getLatinTag.jar fr  fr "autant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "développement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mettre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "grandes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vue" 1000  keyword_fr.txt
