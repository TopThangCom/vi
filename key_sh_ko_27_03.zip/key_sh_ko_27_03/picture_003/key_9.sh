java -jar getLatinTag.jar kr ko "돈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "많" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쌀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "까" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "몰" 1000  keyword_ko.txt
