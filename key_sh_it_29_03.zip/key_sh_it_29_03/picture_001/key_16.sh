java -jar getLatinTag.jar it it "probation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absconding" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abscondito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absconse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absconsion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "io" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiesa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absolvent" 1000  keyword_it.txt
