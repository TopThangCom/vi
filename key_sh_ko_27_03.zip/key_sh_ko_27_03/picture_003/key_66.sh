java -jar getLatinTag.jar kr ko "젯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "핸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "같" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "덕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빛" 1000  keyword_ko.txt
