java -jar getLatinTag.jar kr ko "島" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "熊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "玻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "璃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "絵" 1000  keyword_ko.txt
