java -jar getLatinTag.jar fr  fr "pages" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "évidemment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "résultat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aura" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parmi" 1000  keyword_fr.txt
