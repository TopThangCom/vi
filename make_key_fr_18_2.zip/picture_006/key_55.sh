java -jar getLatinTag.jar fr  fr "central" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "exigences" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "assuré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contacts" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "consacré" 1000  keyword_fr.txt
