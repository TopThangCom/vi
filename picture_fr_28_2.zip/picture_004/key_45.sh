java -jar getLatinTag.jar kr kr "地鶏" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "因幡" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "叡" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "京都市" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "羅暁" 1000  keyword_kr.txt
