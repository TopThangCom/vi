java -jar getLatinTag.jar fr  fr "géant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "automatique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "attend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "litres" 1000  keyword_fr.txt
