java -jar getLatinTag.jar kr ko "찾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "泰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "妻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "教" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "韓" 1000  keyword_ko.txt
