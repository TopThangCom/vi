java -jar getLatinTag.jar it it "concorsi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dipendenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dipendente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "moscati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdominale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aorticilliac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accesorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acessorio" 1000  keyword_it.txt
