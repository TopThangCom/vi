java -jar getLatinTag.jar kr ko "貞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "睛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "內" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杏" 1000  keyword_ko.txt
