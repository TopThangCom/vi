java -jar getLatinTag.jar kr kr "미드인증" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "유니온" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "순서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정리" 1000  keyword_kr.txt
