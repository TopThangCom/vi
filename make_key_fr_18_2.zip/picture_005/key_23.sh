java -jar getLatinTag.jar fr  fr "samedi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "palais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Tractebel" 1000  keyword_fr.txt
