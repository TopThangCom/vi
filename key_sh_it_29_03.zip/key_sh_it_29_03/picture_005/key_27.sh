java -jar getLatinTag.jar it it "ascorpi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorsorbide" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorutin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascosal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascosali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pyrrolidinone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascosec" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascoseco" 1000  keyword_it.txt
