java -jar getLatinTag.jar kr ko "펀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "焼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "灼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "님" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꿔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "따" 1000  keyword_ko.txt
