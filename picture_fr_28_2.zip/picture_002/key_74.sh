java -jar getLatinTag.jar kr kr "套餐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٥٤÷(٣+٦)×٣-١" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "년형" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "江苏省苏州市工业" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "溶接技能者" 1000  keyword_kr.txt
