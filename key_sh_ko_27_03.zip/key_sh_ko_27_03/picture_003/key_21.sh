java -jar getLatinTag.jar kr ko "핑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "씨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "썰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "른" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "專" 1000  keyword_ko.txt
