java -jar getLatinTag.jar kr ko "取" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "學" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "議" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "事" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "録" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "話" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "者" 1000  keyword_ko.txt
