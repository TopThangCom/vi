java -jar getLatinTag.jar kr kr "결제확인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "결제취소" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "결제창" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정기결제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해외결제" 1000  keyword_kr.txt
