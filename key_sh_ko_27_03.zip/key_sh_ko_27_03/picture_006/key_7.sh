java -jar getLatinTag.jar kr ko "棺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "赴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嚮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瘍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "緣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뮬" 1000  keyword_ko.txt
