java -jar getLatinTag.jar kr ko "루" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "박" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "제" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퍼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "즐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "증" 1000  keyword_ko.txt
