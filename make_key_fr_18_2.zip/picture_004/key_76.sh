java -jar getLatinTag.jar fr  fr "vacances" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lieux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "naturellement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'y" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lorsqu'il" 1000  keyword_fr.txt
