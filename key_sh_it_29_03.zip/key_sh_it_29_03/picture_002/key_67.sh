java -jar getLatinTag.jar it it "motosserra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biologico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sistemico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "periodica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dicionario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "laboratorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aforisticamente" 1000  keyword_it.txt
