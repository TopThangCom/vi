java -jar getLatinTag.jar kr ko "녕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "총" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "먹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "돗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "큰" 1000  keyword_ko.txt
