java -jar getLatinTag.jar kr ko "샤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "윌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "론" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뤼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퐁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "몸" 1000  keyword_ko.txt
