java -jar getLatinTag.jar it it "collapse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costruzioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unior" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tuttocampo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antincendio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cavagnolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "evian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bsconfig" 1000  keyword_it.txt
