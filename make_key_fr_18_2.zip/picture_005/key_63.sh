java -jar getLatinTag.jar fr  fr "artistes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "déficit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cadres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fédéral" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "probable" 1000  keyword_fr.txt
