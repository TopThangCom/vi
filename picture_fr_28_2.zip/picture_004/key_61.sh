java -jar getLatinTag.jar kr kr "체크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "딥러닝" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "머신러닝" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인공지능" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공부" 1000  keyword_kr.txt
