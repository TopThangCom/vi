java -jar getLatinTag.jar fr  fr "remarquable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vol" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Claude" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tourisme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "internationaux" 1000  keyword_fr.txt
