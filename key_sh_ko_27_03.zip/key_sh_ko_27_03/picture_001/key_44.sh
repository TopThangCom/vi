java -jar getLatinTag.jar kr ko "질" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "럭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "차" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "모" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "너" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "슈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "패" 1000  keyword_ko.txt
