java -jar getLatinTag.jar it it "superiormente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guitar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "strap" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "segnialli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acqua" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dermatologica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cirenaica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "firenze" 1000  keyword_it.txt
