java -jar getLatinTag.jar fr  fr "nos" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quelque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "place" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "grand" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "personnes" 1000  keyword_fr.txt
