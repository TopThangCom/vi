java -jar getLatinTag.jar it it "carrozzeria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calmont" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "moniz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "decomposizione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nestor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discography" 1000  keyword_it.txt
