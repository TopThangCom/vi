java -jar getLatinTag.jar kr ko "吃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "什" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "么" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "管" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "妍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霏" 1000  keyword_ko.txt
