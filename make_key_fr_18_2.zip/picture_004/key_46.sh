java -jar getLatinTag.jar fr  fr "idées" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trouvé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dette" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Sud" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réellement" 1000  keyword_fr.txt
