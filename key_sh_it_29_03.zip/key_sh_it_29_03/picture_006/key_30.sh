java -jar getLatinTag.jar it it "branzino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anterior" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "insercion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pediatria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dolicocefalia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dolicocefalico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mesocefalico" 1000  keyword_it.txt
