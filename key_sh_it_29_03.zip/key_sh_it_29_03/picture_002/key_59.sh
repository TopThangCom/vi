java -jar getLatinTag.jar it it "mediastinicas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mesentericas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adenophlegmone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lozione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adenosilmetionina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "difosfato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monofosfato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adenotonsillitis" 1000  keyword_it.txt
