java -jar getLatinTag.jar it it "assicurazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chilometraggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uniti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "viaggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assicurazioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dirigenti" 1000  keyword_it.txt
