java -jar getLatinTag.jar kr kr "수립" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전략목표" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "컨설팅" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ESG" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "표준화" 1000  keyword_kr.txt
