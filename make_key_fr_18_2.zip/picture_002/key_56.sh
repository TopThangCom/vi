java -jar getLatinTag.jar fr  fr "solution" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "créer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'économie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "concerne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'époque" 1000  keyword_fr.txt
