java -jar getLatinTag.jar kr ko "탯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "姻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蛾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "僵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蓬" 1000  keyword_ko.txt
