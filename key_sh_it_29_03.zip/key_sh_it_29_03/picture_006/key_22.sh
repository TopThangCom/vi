java -jar getLatinTag.jar it it "coccion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "strat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "soporte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoatendimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "croazia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "latinos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rodizio" 1000  keyword_it.txt
