java -jar getLatinTag.jar kr kr "린치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배틀그라운드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "키" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하버드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "은퇴" 1000  keyword_kr.txt
