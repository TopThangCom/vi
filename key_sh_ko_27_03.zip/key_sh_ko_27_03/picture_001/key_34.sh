java -jar getLatinTag.jar kr ko "삼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "성" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "프" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "린" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "터" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "무" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "선" 1000  keyword_ko.txt
