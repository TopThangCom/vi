java -jar getLatinTag.jar kr ko "鍛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "絡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "啊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "啤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "縁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "摧" 1000  keyword_ko.txt
