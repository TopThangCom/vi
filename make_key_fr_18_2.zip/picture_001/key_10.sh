java -jar getLatinTag.jar fr  fr "projet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "grands" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réseau" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'autre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "données" 1000  keyword_fr.txt
