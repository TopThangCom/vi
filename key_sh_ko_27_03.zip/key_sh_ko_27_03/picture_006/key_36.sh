java -jar getLatinTag.jar kr ko "륨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "큘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "齒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "匹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "淒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "召" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "癒" 1000  keyword_ko.txt
