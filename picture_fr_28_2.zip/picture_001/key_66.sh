java -jar getLatinTag.jar kr kr "규모" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "설계" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "회로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스타트업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "활용" 1000  keyword_kr.txt
