java -jar getLatinTag.jar fr  fr "professionnels" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "raisons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "néanmoins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "preuve" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "social" 1000  keyword_fr.txt
