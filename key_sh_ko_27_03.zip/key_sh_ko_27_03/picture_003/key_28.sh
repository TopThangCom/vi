java -jar getLatinTag.jar kr ko "探" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "給" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "血" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "異" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抜" 1000  keyword_ko.txt
