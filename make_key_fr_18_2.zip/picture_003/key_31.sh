java -jar getLatinTag.jar fr  fr "Express" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faudra" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "travailler" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Crédit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "directement" 1000  keyword_fr.txt
