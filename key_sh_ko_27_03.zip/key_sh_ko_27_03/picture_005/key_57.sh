java -jar getLatinTag.jar kr ko "泣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "簽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "證" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "疆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "厄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壹" 1000  keyword_ko.txt
