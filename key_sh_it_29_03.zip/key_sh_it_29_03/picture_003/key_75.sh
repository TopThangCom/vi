java -jar getLatinTag.jar it it "amendation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amendiares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "confeitaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pettiz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "claudio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amenitiz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secondaria" 1000  keyword_it.txt
