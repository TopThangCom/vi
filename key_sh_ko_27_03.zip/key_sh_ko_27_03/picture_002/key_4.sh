java -jar getLatinTag.jar kr ko "麻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "族" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "憲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "菜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "史" 1000  keyword_ko.txt
