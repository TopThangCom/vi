java -jar getLatinTag.jar fr  fr "réputation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fameux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rappelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conseille" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "heure" 1000  keyword_fr.txt
