java -jar getLatinTag.jar kr kr "갤러리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레전드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "야" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오르카" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "루시드" 1000  keyword_kr.txt
