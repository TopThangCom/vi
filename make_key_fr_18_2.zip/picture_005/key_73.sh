java -jar getLatinTag.jar fr  fr "local" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'impression" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'existe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rare" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "restructuration" 1000  keyword_fr.txt
