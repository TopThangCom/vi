java -jar getLatinTag.jar it it "ascidiella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascites" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascitis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asciugano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asciugatrice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asciugatrici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascl" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montagne" 1000  keyword_it.txt
