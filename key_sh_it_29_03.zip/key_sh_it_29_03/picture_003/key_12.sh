java -jar getLatinTag.jar it it "fanno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricetta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "triciclici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atipicos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colaterais" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "citalopram" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "escitalopram" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antiderivative" 1000  keyword_it.txt
