java -jar getLatinTag.jar fr  fr "l'école" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "liquidités" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "correction" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "CA" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comité" 1000  keyword_fr.txt
