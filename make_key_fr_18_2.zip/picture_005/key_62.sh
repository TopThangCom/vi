java -jar getLatinTag.jar fr  fr "Sabena" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "acteurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dehors" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constructeur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'auteur" 1000  keyword_fr.txt
