java -jar getLatinTag.jar kr ko "역" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "량" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "검" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "사" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "후" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "플" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벤" 1000  keyword_ko.txt
