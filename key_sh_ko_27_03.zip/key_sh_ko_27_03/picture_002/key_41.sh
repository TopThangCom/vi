java -jar getLatinTag.jar kr ko "텐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "按" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "發" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "椅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "付" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "布" 1000  keyword_ko.txt
