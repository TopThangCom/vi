java -jar getLatinTag.jar kr kr "발전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "현황" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "속도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단계" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "반대" 1000  keyword_kr.txt
