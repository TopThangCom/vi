java -jar getLatinTag.jar it it "affiliate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcommission" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compliance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "properties" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capital" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcontabil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "control" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "opcon" 1000  keyword_it.txt
