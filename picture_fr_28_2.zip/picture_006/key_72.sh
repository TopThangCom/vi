java -jar getLatinTag.jar kr kr "优米" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "국회" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "포럼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한경" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "머니투데이" 1000  keyword_kr.txt
