java -jar getLatinTag.jar fr  fr "revenir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "superbe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "volontiers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "document" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nommé" 1000  keyword_fr.txt
