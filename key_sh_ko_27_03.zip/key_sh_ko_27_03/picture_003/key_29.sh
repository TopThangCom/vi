java -jar getLatinTag.jar kr ko "짱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "털" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "津" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "近" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "役" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "割" 1000  keyword_ko.txt
