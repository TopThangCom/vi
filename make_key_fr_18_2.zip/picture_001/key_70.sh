java -jar getLatinTag.jar fr  fr "n'est" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marché" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Pour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "donc" 1000  keyword_fr.txt
