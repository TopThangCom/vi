java -jar getLatinTag.jar it it "orio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "serio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "meridionali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mancato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "traffico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cipd" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giolaser" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avanceret" 1000  keyword_it.txt
