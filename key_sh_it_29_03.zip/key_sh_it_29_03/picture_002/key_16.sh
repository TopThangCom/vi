java -jar getLatinTag.jar it it "neiva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "precon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pizzaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinema" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adroll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adscivil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adscope" 1000  keyword_it.txt
