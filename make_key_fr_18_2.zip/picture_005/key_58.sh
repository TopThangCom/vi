java -jar getLatinTag.jar fr  fr "faite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "juridique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "langue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rendez-vous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'informations" 1000  keyword_fr.txt
