java -jar getLatinTag.jar kr ko "暗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "証" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "番" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "백" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "준" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "웅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "훈" 1000  keyword_ko.txt
