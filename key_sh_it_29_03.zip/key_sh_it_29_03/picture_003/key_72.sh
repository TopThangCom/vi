java -jar getLatinTag.jar it it "quartzolit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antirusso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tolerance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antolarrain" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antonomase" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antonomasia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chocolates" 1000  keyword_it.txt
