java -jar getLatinTag.jar kr kr "SPL" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "spl" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대구" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "起動" 1000  keyword_kr.txt
