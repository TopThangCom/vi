java -jar getLatinTag.jar fr  fr "hausse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "secteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "part" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "beaucoup" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Je" 1000  keyword_fr.txt
