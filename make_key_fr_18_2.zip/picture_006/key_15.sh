java -jar getLatinTag.jar fr  fr "CD-Rom" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "H" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "forcément" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'essentiel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'enseignement" 1000  keyword_fr.txt
