java -jar getLatinTag.jar kr ko "회" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "향" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쟁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "력" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "망" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "활" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "황" 1000  keyword_ko.txt
