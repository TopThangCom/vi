java -jar getLatinTag.jar kr kr "프레임에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공유" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "드라이브" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "초대" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공유하는" 1000  keyword_kr.txt
