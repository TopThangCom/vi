java -jar getLatinTag.jar fr  fr "largement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "milliard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "soient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Pierre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devenir" 1000  keyword_fr.txt
