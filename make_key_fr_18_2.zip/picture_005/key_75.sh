java -jar getLatinTag.jar fr  fr "coups" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "émissions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "éventuellement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Royale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'agence" 1000  keyword_fr.txt
