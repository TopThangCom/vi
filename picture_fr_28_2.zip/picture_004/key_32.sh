java -jar getLatinTag.jar kr kr "아스트로니어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "rtg" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "燕飞" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "x" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "星球" 1000  keyword_kr.txt
