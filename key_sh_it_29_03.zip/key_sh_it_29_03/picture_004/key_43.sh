java -jar getLatinTag.jar it it "ascardio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascarelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ariane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascaridia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scielo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascaridiose" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascaris" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colindres" 1000  keyword_it.txt
