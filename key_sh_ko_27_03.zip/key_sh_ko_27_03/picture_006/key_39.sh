java -jar getLatinTag.jar kr ko "뻑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뼈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "秉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "튕" 1000  keyword_ko.txt
