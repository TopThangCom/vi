java -jar getLatinTag.jar kr ko "噬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "샷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "醋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "젝" 1000  keyword_ko.txt
