java -jar getLatinTag.jar it it "restoration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "portile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "negre" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neagra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "normativ" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pisici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "speranta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antiaeriene" 1000  keyword_it.txt
