java -jar getLatinTag.jar kr ko "祭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "莓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "輝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "緒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盔" 1000  keyword_ko.txt
