java -jar getLatinTag.jar kr ko "랜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "친" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "켓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "환" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "채" 1000  keyword_ko.txt
