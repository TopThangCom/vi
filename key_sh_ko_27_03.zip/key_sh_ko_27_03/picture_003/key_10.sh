java -jar getLatinTag.jar kr ko "己" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "果" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "究" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "調" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "習" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豪" 1000  keyword_ko.txt
