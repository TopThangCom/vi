java -jar getLatinTag.jar fr  fr "utilise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commune" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dimanche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "option" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partis" 1000  keyword_fr.txt
