java -jar getLatinTag.jar fr  fr "entier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "business" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "peinture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'était" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voisins" 1000  keyword_fr.txt
