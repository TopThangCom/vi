java -jar getLatinTag.jar kr ko "塗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "持" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "框" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "太" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "存" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "跡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "栄" 1000  keyword_ko.txt
