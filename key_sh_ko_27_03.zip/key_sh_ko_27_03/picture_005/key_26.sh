java -jar getLatinTag.jar kr ko "賽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "碳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茄" 1000  keyword_ko.txt
