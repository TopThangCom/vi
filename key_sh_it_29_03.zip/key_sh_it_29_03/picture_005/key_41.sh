java -jar getLatinTag.jar it it "astronomical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astronomicon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "telescopes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chilenos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astroscale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astroscope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astroscoped" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartografia" 1000  keyword_it.txt
