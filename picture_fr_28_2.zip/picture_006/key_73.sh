java -jar getLatinTag.jar kr kr "cdc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "最新疫苗數據曝光" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트와이스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "fancy" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "excel" 1000  keyword_kr.txt
