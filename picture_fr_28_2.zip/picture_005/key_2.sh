java -jar getLatinTag.jar kr kr "피터팬" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실거래가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "매물등록" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "웨일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스포츠" 1000  keyword_kr.txt
