java -jar getLatinTag.jar kr kr "피파대리구매" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오버롤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "커리어모드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사양" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "無線折疊搖頭風扇" 1000  keyword_kr.txt
