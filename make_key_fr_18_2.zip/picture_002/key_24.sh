java -jar getLatinTag.jar fr  fr "sait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "via" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "stratégie" 1000  keyword_fr.txt
