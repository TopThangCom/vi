java -jar getLatinTag.jar kr kr "jp" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "過去" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cla" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비말차단" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "데일리" 1000  keyword_kr.txt
