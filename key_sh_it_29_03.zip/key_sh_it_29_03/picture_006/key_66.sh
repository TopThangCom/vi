java -jar getLatinTag.jar it it "portatile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncoaspiratori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ventilatoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tomografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncoliber" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncolin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncolor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncoscopia" 1000  keyword_it.txt
