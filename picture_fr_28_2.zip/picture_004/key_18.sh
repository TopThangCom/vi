java -jar getLatinTag.jar kr kr "유성점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "야탑" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서면점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "애슐리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구로" 1000  keyword_kr.txt
