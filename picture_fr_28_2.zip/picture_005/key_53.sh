java -jar getLatinTag.jar kr kr "使用期限" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "hwp" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파일로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일괄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "hwp변환" 1000  keyword_kr.txt
