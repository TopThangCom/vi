java -jar getLatinTag.jar fr  fr "rapidement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "j'ai" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ville" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "etc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mars" 1000  keyword_fr.txt
