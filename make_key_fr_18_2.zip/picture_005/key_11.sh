java -jar getLatinTag.jar fr  fr "leader" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "calcul" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gaz" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D'abord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Rens" 1000  keyword_fr.txt
