java -jar getLatinTag.jar kr kr "紀尾井町" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "実況" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "lg" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "업그레이드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배터리" 1000  keyword_kr.txt
