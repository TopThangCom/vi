java -jar getLatinTag.jar kr kr "ad" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "포켓몬스터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "gba" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "롬파일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "라이터" 1000  keyword_kr.txt
