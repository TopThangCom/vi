java -jar getLatinTag.jar kr ko "폭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "핫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "圧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崎" 1000  keyword_ko.txt
