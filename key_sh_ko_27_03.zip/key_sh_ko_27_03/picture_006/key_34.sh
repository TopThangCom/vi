java -jar getLatinTag.jar kr ko "讓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "》" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "懸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "詣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崑" 1000  keyword_ko.txt
