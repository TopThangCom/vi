java -jar getLatinTag.jar fr  fr "publics" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fortement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plein" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "wallonne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "DEM" 1000  keyword_fr.txt
