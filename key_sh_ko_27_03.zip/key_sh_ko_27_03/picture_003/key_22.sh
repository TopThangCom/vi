java -jar getLatinTag.jar kr ko "뢰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퓨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "홀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "졸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "섬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "픈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "칙" 1000  keyword_ko.txt
