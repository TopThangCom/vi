java -jar getLatinTag.jar it it "agrola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carreta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pellicer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agromarcos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "direccion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agromerca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agromercantil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sca" 1000  keyword_it.txt
