java -jar getLatinTag.jar kr ko "붙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "악" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "共" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "諭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "萬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "強" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "力" 1000  keyword_ko.txt
