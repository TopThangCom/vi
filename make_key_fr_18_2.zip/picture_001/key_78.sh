java -jar getLatinTag.jar fr  fr "valeur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "croissance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rapport" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "USD" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aujourd'hui" 1000  keyword_fr.txt
