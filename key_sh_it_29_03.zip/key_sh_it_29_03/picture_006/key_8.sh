java -jar getLatinTag.jar it it "biassono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nastrificio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arenzano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cogoleto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "convalescence" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "soccer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rivoli" 1000  keyword_it.txt
