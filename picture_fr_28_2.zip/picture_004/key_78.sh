java -jar getLatinTag.jar kr kr "曲" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "追加" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "臨床化学自動分析装置" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "自動雙面/彩色螢幕" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "連續供墨複合機" 1000  keyword_kr.txt
