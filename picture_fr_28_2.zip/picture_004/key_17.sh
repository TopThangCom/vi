java -jar getLatinTag.jar kr kr "책" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cnn" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "분류" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이란" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "예측" 1000  keyword_kr.txt
