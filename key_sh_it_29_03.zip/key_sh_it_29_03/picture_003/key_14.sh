java -jar getLatinTag.jar it it "cebolla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "financiamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "credito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amortizasse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amortization" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "depreciation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amortize" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amosca" 1000  keyword_it.txt
