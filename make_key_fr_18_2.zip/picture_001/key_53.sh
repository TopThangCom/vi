java -jar getLatinTag.jar fr  fr "produits" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cela" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'autres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "niveau" 1000  keyword_fr.txt
