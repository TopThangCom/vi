java -jar getLatinTag.jar kr kr "오즈뷰어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오피스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "웹페이지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "회전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "짤림" 1000  keyword_kr.txt
