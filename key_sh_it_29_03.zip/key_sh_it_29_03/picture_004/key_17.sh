java -jar getLatinTag.jar it it "arbitrage" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arbitramento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arbitraments" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arbitration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arborescent" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gingivodentales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "indios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absoluto" 1000  keyword_it.txt
