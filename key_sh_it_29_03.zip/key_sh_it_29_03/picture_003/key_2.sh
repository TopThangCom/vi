java -jar getLatinTag.jar it it "anemostat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diptongo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "hiato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dimm" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oscillation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oscillator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medicatie" 1000  keyword_it.txt
