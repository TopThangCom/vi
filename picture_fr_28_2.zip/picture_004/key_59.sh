java -jar getLatinTag.jar kr kr "voxy" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "前期" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "後期" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "違い" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구두" 1000  keyword_kr.txt
