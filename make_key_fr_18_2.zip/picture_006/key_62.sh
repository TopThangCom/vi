java -jar getLatinTag.jar fr  fr "transmission" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "concurrent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "courte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quart" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "baisser" 1000  keyword_fr.txt
