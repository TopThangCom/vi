java -jar getLatinTag.jar fr  fr "l'Union" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "franc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "minimum" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mort" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "responsable" 1000  keyword_fr.txt
