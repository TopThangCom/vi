java -jar getLatinTag.jar kr kr "暉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新作" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "映画" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "bnt" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "防護力比莫德納低美" 1000  keyword_kr.txt
