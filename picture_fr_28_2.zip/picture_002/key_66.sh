java -jar getLatinTag.jar kr kr "혜택" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공시지원금" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기기변경" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "울트라" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "롤" 1000  keyword_kr.txt
