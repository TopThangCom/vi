java -jar getLatinTag.jar fr  fr "prises" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "secret" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "historique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "journée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'ancien" 1000  keyword_fr.txt
