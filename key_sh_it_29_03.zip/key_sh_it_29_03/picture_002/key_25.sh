java -jar getLatinTag.jar it it "componenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "usato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "positivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "combine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiscales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "configurator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medicala" 1000  keyword_it.txt
