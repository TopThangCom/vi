java -jar getLatinTag.jar fr  fr "talent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "appelé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "modifier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "définition" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "peintre" 1000  keyword_fr.txt
