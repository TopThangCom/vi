java -jar getLatinTag.jar kr ko "侑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "懷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鑒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "溢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "갯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "畸" 1000  keyword_ko.txt
