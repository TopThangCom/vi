java -jar getLatinTag.jar fr  fr "Peter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "feuilles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "football" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "identique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pouvons" 1000  keyword_fr.txt
