java -jar getLatinTag.jar fr  fr "retrouve" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Aux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "revient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Belgacom" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "route" 1000  keyword_fr.txt
