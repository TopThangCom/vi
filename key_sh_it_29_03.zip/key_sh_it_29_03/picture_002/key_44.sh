java -jar getLatinTag.jar it it "termina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unimed" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdutora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdutor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdutores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "civil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colloid" 1000  keyword_it.txt
