java -jar getLatinTag.jar kr kr "東口" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다이노스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "샵" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "명일방주" 1000  keyword_kr.txt
