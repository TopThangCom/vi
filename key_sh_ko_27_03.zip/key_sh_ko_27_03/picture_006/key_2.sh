java -jar getLatinTag.jar kr ko "膀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "飼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蜘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蛛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蝠" 1000  keyword_ko.txt
