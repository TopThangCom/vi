java -jar getLatinTag.jar kr kr "木村麻美" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "木村盛世" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "家族" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "木村" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "盛世" 1000  keyword_kr.txt
