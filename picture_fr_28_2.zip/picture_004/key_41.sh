java -jar getLatinTag.jar kr kr "시세" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전자칠판" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "매뉴얼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미러링" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "블라인드" 1000  keyword_kr.txt
