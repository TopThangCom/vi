java -jar getLatinTag.jar it it "cove" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "notice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chelles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "person" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iscisa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "icmc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "demissional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "univalle" 1000  keyword_it.txt
