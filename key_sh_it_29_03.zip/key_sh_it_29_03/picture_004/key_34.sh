java -jar getLatinTag.jar it it "cccd" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apposed" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apposing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apposite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apposition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appositive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apprentus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "approx" 1000  keyword_it.txt
