java -jar getLatinTag.jar fr  fr "logement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pourcentage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "stabilité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "difficilement" 1000  keyword_fr.txt
