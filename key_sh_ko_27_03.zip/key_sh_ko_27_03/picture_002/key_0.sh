java -jar getLatinTag.jar kr ko "눅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "외" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "릴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "접" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "를" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "져" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "올" 1000  keyword_ko.txt
