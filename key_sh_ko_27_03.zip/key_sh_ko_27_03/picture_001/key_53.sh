java -jar getLatinTag.jar kr ko "예" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "상" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "측" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "원" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "판" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "데" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빌" 1000  keyword_ko.txt
