java -jar getLatinTag.jar it it "intro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dinero" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "suaves" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aicasa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antigua" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aicome" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aicommit" 1000  keyword_it.txt
