java -jar getLatinTag.jar kr ko "배" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "경" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "도" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "안" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "레" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "션" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "줄" 1000  keyword_ko.txt
