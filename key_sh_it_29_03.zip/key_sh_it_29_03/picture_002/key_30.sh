java -jar getLatinTag.jar it it "model" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adezio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "certificate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adficonta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lettuce" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distribuicao" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adicional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adicionar" 1000  keyword_it.txt
