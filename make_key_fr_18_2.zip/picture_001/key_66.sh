java -jar getLatinTag.jar fr  fr "investisseurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trouve" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "maison" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mal" 1000  keyword_fr.txt
