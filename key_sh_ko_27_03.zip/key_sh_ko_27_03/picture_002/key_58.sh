java -jar getLatinTag.jar kr ko "漫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "윤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嘉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "積" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "풍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "축" 1000  keyword_ko.txt
