java -jar getLatinTag.jar it it "ride" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "airriderz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "restriccions" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "instituto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montargil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcalde" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piscina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcohol" 1000  keyword_it.txt
