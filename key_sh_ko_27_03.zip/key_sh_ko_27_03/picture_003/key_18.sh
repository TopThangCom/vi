java -jar getLatinTag.jar kr ko "膏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "克" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "変" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "石" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誕" 1000  keyword_ko.txt
