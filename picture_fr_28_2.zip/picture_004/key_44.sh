java -jar getLatinTag.jar kr kr "감독" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "커리어스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전형진행중" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "커리어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스" 1000  keyword_kr.txt
