java -jar getLatinTag.jar it it "intestinal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "marco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "championnat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "almeria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "preuniversitarias" 1000  keyword_it.txt
