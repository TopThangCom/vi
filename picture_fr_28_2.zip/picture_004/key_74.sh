java -jar getLatinTag.jar kr kr "쏠" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모베러웍스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "딥드림카드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피킹률" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "신용카드" 1000  keyword_kr.txt
