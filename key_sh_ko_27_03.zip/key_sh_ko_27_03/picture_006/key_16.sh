java -jar getLatinTag.jar kr ko "迅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "焰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "헥" 1000  keyword_ko.txt
