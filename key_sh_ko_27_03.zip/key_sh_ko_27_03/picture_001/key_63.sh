java -jar getLatinTag.jar kr ko "줘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "관" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "길" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "으" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "공" 1000  keyword_ko.txt
