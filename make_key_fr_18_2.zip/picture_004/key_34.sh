java -jar getLatinTag.jar fr  fr "anciens" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "graphique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Fortis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faveur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "retrouver" 1000  keyword_fr.txt
