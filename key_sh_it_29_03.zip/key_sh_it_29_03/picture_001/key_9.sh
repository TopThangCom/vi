java -jar getLatinTag.jar it it "verifica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "della" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clientela" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "proporzionate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adeguatezza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appropriatezza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "patrimoniale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adeguato" 1000  keyword_it.txt
