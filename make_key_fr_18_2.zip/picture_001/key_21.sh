java -jar getLatinTag.jar fr  fr "long" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "petit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'ailleurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "notamment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "FB" 1000  keyword_fr.txt
