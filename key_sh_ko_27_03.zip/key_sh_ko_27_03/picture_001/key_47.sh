java -jar getLatinTag.jar kr ko "브" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "라" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "언" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "타" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퀸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "드" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "페" 1000  keyword_ko.txt
