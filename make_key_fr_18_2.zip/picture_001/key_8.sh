java -jar getLatinTag.jar fr  fr "avec" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "son" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'un" 1000  keyword_fr.txt
