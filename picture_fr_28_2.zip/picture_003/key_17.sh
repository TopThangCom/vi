java -jar getLatinTag.jar kr kr "면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "입체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공간" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "차원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미술" 1000  keyword_kr.txt
