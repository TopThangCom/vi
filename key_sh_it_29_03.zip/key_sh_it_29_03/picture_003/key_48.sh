java -jar getLatinTag.jar it it "aolion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corvallis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aonorion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arcanist" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spiritualist" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aopalliance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prenotazioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ritiro" 1000  keyword_it.txt
