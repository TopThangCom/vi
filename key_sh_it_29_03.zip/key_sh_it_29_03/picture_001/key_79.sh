java -jar getLatinTag.jar it it "indication" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "predial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcirca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "periscope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adclick" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adclinic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitcoin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ico" 1000  keyword_it.txt
