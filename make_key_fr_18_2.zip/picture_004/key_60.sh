java -jar getLatinTag.jar fr  fr "dirigeants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "changer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conséquence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sociales" 1000  keyword_fr.txt
