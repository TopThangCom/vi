java -jar getLatinTag.jar fr  fr "privée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rares" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "succession" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "liberté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rentabilité" 1000  keyword_fr.txt
