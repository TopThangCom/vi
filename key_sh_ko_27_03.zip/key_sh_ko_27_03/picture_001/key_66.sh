java -jar getLatinTag.jar kr ko "責" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "任" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "監" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "査" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "法" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "使" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "用" 1000  keyword_ko.txt
