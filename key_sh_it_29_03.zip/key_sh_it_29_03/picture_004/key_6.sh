java -jar getLatinTag.jar it it "graniteville" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accreditation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascbb" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascdi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asceet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascefi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "associate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "glendale" 1000  keyword_it.txt
