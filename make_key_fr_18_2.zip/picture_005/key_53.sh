java -jar getLatinTag.jar fr  fr "surprise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Etats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mariage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nécessité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Puis" 1000  keyword_fr.txt
