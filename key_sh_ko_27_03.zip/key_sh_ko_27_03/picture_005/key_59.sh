java -jar getLatinTag.jar kr ko "盡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "閘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "籠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "翁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伐" 1000  keyword_ko.txt
