java -jar getLatinTag.jar kr kr "한번에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이름" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "줄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "abs" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "함수" 1000  keyword_kr.txt
