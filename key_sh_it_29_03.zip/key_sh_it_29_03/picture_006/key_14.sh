java -jar getLatinTag.jar it it "tilibra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petaro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montevideo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "linares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "portfolio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iodico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "felici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coches" 1000  keyword_it.txt
