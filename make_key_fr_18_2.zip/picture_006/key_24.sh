java -jar getLatinTag.jar fr  fr "furent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "possibles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "circonstances" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "placer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "publication" 1000  keyword_fr.txt
