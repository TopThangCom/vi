java -jar getLatinTag.jar kr ko "烏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "슨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "檔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "완" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "劇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腹" 1000  keyword_ko.txt
