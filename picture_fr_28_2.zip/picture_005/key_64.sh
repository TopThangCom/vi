java -jar getLatinTag.jar kr kr "지도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "닐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "암스트롱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "명언" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "달" 1000  keyword_kr.txt
