java -jar getLatinTag.jar kr kr "s-vctf" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "timep@ck-iciv" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "笠原理化工業" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "임페라토르" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "롬" 1000  keyword_kr.txt
