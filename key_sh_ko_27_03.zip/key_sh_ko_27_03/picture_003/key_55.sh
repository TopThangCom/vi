java -jar getLatinTag.jar kr ko "쉬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "승" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "척" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "옷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "읍" 1000  keyword_ko.txt
