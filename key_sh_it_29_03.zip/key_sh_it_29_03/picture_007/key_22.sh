java -jar getLatinTag.jar it it "camasella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appassimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "figli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scilloides" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camassola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "modugno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corsico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camastroneria" 1000  keyword_it.txt
