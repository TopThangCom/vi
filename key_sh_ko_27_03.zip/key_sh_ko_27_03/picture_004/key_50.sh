java -jar getLatinTag.jar kr ko "듚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뇚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쁍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "텳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캂" 1000  keyword_ko.txt
