java -jar getLatinTag.jar kr ko "蘭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "且" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "灌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "噴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "孤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "邱" 1000  keyword_ko.txt
