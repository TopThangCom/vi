java -jar getLatinTag.jar it it "amodit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tatita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "locomotion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "microglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "migration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rincon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prison" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amomedia" 1000  keyword_it.txt
