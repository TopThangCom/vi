java -jar getLatinTag.jar it it "cristo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ilc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acapella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accalmie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acceleration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accelerometer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "access" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accessibility" 1000  keyword_it.txt
