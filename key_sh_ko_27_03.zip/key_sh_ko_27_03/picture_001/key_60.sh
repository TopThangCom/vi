java -jar getLatinTag.jar kr ko "남" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "반" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "염" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "색" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "한" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "국" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "담" 1000  keyword_ko.txt
