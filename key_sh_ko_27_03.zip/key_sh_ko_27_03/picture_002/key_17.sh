java -jar getLatinTag.jar kr ko "帶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "컨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "殖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "泉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "始" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "玄" 1000  keyword_ko.txt
