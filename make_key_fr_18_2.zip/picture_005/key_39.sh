java -jar getLatinTag.jar fr  fr "suit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "auquel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dépasse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spécialisée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bruxellois" 1000  keyword_fr.txt
