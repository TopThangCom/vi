java -jar getLatinTag.jar it it "astrocel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cristal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oroscopo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scorpio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "univision" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrocitoma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tranzite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "demolition" 1000  keyword_it.txt
