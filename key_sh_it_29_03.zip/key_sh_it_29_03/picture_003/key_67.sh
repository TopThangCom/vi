java -jar getLatinTag.jar it it "montana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perfil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricambi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carrizo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dispatch" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cota" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montero" 1000  keyword_it.txt
