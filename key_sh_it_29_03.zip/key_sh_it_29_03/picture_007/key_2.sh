java -jar getLatinTag.jar it it "rellenos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "direto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corretor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gratinate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "delusion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mediona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "granota" 1000  keyword_it.txt
