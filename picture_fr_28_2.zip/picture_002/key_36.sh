java -jar getLatinTag.jar kr kr "레플리카" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정가품" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레플" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "버니스웨터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "금장" 1000  keyword_kr.txt
