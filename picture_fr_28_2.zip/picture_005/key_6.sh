java -jar getLatinTag.jar kr kr "冷蔵庫" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "utc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국시간" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스케치업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌襦袢" 1000  keyword_kr.txt
