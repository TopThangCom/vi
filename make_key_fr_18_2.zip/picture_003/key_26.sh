java -jar getLatinTag.jar fr  fr "Chaque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "put" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tableau" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "terre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "permettent" 1000  keyword_fr.txt
