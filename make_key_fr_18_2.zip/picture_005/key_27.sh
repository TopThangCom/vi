java -jar getLatinTag.jar fr  fr "recettes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "poursuivre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dessous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "portant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Aussi" 1000  keyword_fr.txt
