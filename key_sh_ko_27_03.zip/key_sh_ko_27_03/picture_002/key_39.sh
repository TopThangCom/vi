java -jar getLatinTag.jar kr ko "詐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "差" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "押" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "終" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "和" 1000  keyword_ko.txt
