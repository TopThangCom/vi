java -jar getLatinTag.jar kr kr "해외야구" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "댓글" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "크롬캐스트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pip" 1000  keyword_kr.txt
