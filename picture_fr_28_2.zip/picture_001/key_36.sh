java -jar getLatinTag.jar kr kr "높이기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "저하" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안바뀜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "낮추기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트위치티비" 1000  keyword_kr.txt
