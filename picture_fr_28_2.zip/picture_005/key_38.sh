java -jar getLatinTag.jar kr kr "마스크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nhn" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시즌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "교육" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자격증" 1000  keyword_kr.txt
