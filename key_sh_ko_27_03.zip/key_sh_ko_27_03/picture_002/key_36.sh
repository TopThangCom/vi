java -jar getLatinTag.jar kr ko "世" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "地" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "因" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "교" 1000  keyword_ko.txt
