java -jar getLatinTag.jar kr ko "횟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鈴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "結" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "婚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卒" 1000  keyword_ko.txt
