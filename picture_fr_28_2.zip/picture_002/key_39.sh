java -jar getLatinTag.jar kr kr "기업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대학생" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자기소개" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자기소개서" 1000  keyword_kr.txt
