java -jar getLatinTag.jar it it "regole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comentario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apparatus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appascam" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appimage" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inventor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appium" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apporto" 1000  keyword_it.txt
