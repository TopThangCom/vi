java -jar getLatinTag.jar fr  fr "direct" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'inflation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'avait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "utiliser" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tonnes" 1000  keyword_fr.txt
