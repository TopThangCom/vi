java -jar getLatinTag.jar kr ko "到" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "飽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "厭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "權" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "與" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맵" 1000  keyword_ko.txt
