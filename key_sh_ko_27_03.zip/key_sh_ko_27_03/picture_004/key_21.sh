java -jar getLatinTag.jar kr ko "잼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "헬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뒤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "몽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퀄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앞" 1000  keyword_ko.txt
