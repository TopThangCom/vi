java -jar getLatinTag.jar fr  fr "six" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "firme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "perte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Philippe" 1000  keyword_fr.txt
