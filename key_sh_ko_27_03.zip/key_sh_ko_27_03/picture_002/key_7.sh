java -jar getLatinTag.jar kr ko "뿌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쏠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "웍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "킹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "률" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "머" 1000  keyword_ko.txt
