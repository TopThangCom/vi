java -jar getLatinTag.jar it it "ascoservi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascoservice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lasciti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascosing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solenoid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascoson" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "germination" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diploid" 1000  keyword_it.txt
