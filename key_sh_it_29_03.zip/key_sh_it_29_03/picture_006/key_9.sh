java -jar getLatinTag.jar it it "caicosinseln" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distinto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "albi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caimano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dagli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "occhiali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caimanoe" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "microscopio" 1000  keyword_it.txt
