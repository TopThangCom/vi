java -jar getLatinTag.jar fr  fr "lancer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "supérieur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "atteindre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "référence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "téléphone" 1000  keyword_fr.txt
