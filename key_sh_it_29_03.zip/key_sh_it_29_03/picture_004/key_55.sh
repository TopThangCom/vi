java -jar getLatinTag.jar it it "imperio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "reta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "glucose" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "microlet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascension" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montascale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "falconi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stipendio" 1000  keyword_it.txt
