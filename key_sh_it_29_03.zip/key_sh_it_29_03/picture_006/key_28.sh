java -jar getLatinTag.jar it it "piazza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "viale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fila" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "duraton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bodicote" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "visualization" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vibrant" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pipoco" 1000  keyword_it.txt
