java -jar getLatinTag.jar kr ko "幹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "両" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "編" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "輸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "途" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "秒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "補" 1000  keyword_ko.txt
