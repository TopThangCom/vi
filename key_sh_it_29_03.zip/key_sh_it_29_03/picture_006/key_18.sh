java -jar getLatinTag.jar it it "salentino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitcasino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitcomet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitemporale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitemporaler" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recession" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitoca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitocaps" 1000  keyword_it.txt
