java -jar getLatinTag.jar kr ko "민" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "術" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "體" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "產" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "킵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "등" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "람" 1000  keyword_ko.txt
