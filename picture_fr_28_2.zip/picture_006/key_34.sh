java -jar getLatinTag.jar kr kr "돼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "or" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안됌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "됨" 1000  keyword_kr.txt
