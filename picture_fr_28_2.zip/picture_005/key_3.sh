java -jar getLatinTag.jar kr kr "콘솔" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "치트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "로마" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "더뉴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아반떼" 1000  keyword_kr.txt
