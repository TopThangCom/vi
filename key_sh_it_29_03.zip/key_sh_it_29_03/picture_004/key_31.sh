java -jar getLatinTag.jar it it "penetration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "incendio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "altimetrias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aromantic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aromaterapia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arondon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arpeggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acetone" 1000  keyword_it.txt
