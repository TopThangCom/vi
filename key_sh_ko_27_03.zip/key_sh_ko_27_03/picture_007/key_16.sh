java -jar getLatinTag.jar kr ko "욥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "겁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嶺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿽" 1000  keyword_ko.txt
