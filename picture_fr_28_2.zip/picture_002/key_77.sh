java -jar getLatinTag.jar kr kr "広さ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "小型高速切断機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "idm" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "크랙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바이러스" 1000  keyword_kr.txt
