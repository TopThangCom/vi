java -jar getLatinTag.jar kr ko "壞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "辨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瘦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "經" 1000  keyword_ko.txt
