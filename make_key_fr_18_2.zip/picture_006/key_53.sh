java -jar getLatinTag.jar fr  fr "téléphonique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comptable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "effectuer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trafic" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "degré" 1000  keyword_fr.txt
