java -jar getLatinTag.jar kr kr "듀오백" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "dk" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nh투자증권" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "qv" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해외주식" 1000  keyword_kr.txt
