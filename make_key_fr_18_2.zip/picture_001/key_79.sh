java -jar getLatinTag.jar fr  fr "vient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jusqu'" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quatre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marchés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mise" 1000  keyword_fr.txt
