java -jar getLatinTag.jar kr kr "보상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "군요금제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변경방법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新興製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이상" 1000  keyword_kr.txt
