java -jar getLatinTag.jar kr kr "결과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발표일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쥐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "png" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "캐릭터" 1000  keyword_kr.txt
