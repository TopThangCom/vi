java -jar getLatinTag.jar fr  fr "était" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Si" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'est" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chez" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "L" 1000  keyword_fr.txt
