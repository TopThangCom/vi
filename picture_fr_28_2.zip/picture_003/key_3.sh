java -jar getLatinTag.jar kr kr "賃貸" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "久喜中" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "吹奏楽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "陸上部" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "偏差値" 1000  keyword_kr.txt
