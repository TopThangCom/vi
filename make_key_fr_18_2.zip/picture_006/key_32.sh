java -jar getLatinTag.jar fr  fr "lien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "locales" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "francophone" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "clubs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "correspond" 1000  keyword_fr.txt
