java -jar getLatinTag.jar fr  fr "musique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "milieu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'entreprise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "autorités" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chute" 1000  keyword_fr.txt
