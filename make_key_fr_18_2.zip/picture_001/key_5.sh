java -jar getLatinTag.jar fr  fr "sa" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Mais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "été" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aussi" 1000  keyword_fr.txt
