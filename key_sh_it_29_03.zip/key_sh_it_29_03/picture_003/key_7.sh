java -jar getLatinTag.jar it it "cinelandia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "motel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amaretto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disaronno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "licor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ediciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "opera" 1000  keyword_it.txt
