java -jar getLatinTag.jar it it "editor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distribution" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "peregrina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "morfologico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anaquatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "utopia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anascoccinum" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anascol" 1000  keyword_it.txt
