java -jar getLatinTag.jar kr kr "전략적" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제휴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카카오" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "펌웨어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "住所" 1000  keyword_kr.txt
