java -jar getLatinTag.jar fr  fr "L'an" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "basé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "installations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bacob" 1000  keyword_fr.txt
