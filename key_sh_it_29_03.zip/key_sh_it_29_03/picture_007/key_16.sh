java -jar getLatinTag.jar it it "casadetti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casaiola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casaioli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "digitale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pediatric" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canonica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casanova" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casapulla" 1000  keyword_it.txt
