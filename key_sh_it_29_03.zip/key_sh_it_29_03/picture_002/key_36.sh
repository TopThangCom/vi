java -jar getLatinTag.jar it it "coomeva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absorbimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attivi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assorbimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "specifico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adspicit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "specifications" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medizinal" 1000  keyword_it.txt
