java -jar getLatinTag.jar kr ko "奏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "道" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "路" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "通" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "輛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "構" 1000  keyword_ko.txt
