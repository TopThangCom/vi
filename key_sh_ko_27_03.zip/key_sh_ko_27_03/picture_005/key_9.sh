java -jar getLatinTag.jar kr ko "囊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "罰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "諸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "슷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "缸" 1000  keyword_ko.txt
