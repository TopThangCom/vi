java -jar getLatinTag.jar kr kr "事故" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鈴木靖" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鈴木靖将" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鈴木屋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "我孫子" 1000  keyword_kr.txt
