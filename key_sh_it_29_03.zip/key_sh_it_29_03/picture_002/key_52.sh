java -jar getLatinTag.jar it it "adoministators" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "controller" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "signification" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diarios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lince" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adonel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "musical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cold" 1000  keyword_it.txt
