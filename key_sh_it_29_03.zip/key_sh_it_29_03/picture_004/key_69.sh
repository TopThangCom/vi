java -jar getLatinTag.jar it it "fantastico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apresentamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "covalentes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apresentaremos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pif" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apretadito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pero" 1000  keyword_it.txt
