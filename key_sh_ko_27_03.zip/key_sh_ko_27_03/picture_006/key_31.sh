java -jar getLatinTag.jar kr ko "釘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "낼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쯧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "攤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "楚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "萎" 1000  keyword_ko.txt
