java -jar getLatinTag.jar fr  fr "conserver" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "maximum" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "force" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fax" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Que" 1000  keyword_fr.txt
