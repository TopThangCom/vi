java -jar getLatinTag.jar kr kr "발자국" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "첫" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사망" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "양심" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "富士電線工業" 1000  keyword_kr.txt
