java -jar getLatinTag.jar fr  fr "transfert" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "composé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dimension" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "personnages" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ralentissement" 1000  keyword_fr.txt
