java -jar getLatinTag.jar it it "altirnao" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regulations" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corsi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "indirizzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scott" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aolcc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attendance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aolccbc" 1000  keyword_it.txt
