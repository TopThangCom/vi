java -jar getLatinTag.jar fr  fr "Group" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'informatique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "personnage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "portent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "attendu" 1000  keyword_fr.txt
