java -jar getLatinTag.jar kr kr "腘绳肌怎么读" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鹅肌肽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "锌肌肽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nd-etc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "車載器管理番号" 1000  keyword_kr.txt
