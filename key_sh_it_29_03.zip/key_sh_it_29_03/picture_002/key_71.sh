java -jar getLatinTag.jar it it "cpanel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vertical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "direta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arcos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pifano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alezzi" 1000  keyword_it.txt
