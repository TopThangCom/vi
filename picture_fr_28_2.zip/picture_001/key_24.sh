java -jar getLatinTag.jar kr kr "열애" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "더쿠" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인스타" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "여행" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국어" 1000  keyword_kr.txt
