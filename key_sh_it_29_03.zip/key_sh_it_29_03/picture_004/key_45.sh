java -jar getLatinTag.jar it it "petrarca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arquata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tronto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scrivia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pergole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "priston" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "egipcia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "torello" 1000  keyword_it.txt
