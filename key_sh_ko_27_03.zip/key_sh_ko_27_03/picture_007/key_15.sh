java -jar getLatinTag.jar kr ko "斬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瞻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "睪" 1000  keyword_ko.txt
