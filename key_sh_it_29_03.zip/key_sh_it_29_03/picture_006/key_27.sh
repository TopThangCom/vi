java -jar getLatinTag.jar it it "fiordispina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "maurizio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "craiova" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disegno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bradipolibri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tridattilo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colorat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inalt" 1000  keyword_it.txt
