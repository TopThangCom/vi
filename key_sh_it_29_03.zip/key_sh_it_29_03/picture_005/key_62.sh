java -jar getLatinTag.jar it it "atracon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atracones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atraente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perigo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atramenta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atramental" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atramentar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atramentarium" 1000  keyword_it.txt
