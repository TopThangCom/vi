java -jar getLatinTag.jar kr ko "彭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "或" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "扶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "恩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "淘" 1000  keyword_ko.txt
