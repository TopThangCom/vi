java -jar getLatinTag.jar fr  fr "forte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ici" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Quant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vu" 1000  keyword_fr.txt
