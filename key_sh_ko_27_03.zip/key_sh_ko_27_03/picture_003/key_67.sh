java -jar getLatinTag.jar kr ko "밀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "톱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "軒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "並" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "縄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "苗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "産" 1000  keyword_ko.txt
