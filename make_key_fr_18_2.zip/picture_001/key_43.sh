java -jar getLatinTag.jar fr  fr "risque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "début" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "banque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "an" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voir" 1000  keyword_fr.txt
