java -jar getLatinTag.jar kr ko "圭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "灰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "累" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콰" 1000  keyword_ko.txt
