java -jar getLatinTag.jar kr kr "노래방" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "같은" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "코드악보" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쉬운" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "김건모" 1000  keyword_kr.txt
