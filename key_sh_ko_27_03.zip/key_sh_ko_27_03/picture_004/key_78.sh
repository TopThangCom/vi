java -jar getLatinTag.jar kr ko "敏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "郭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "庄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咸" 1000  keyword_ko.txt
