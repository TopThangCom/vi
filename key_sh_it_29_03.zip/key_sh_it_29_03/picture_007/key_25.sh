java -jar getLatinTag.jar it it "prosciutto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sucata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conceria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disfraces" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carassale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carassin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carassone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carassonnage" 1000  keyword_it.txt
