java -jar getLatinTag.jar kr ko "램" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "네" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "발" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "송" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "취" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "방" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "됨" 1000  keyword_ko.txt
