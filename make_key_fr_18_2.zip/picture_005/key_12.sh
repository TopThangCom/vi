java -jar getLatinTag.jar fr  fr "standard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "auparavant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "construit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Quelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "principales" 1000  keyword_fr.txt
