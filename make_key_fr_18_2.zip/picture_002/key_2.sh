java -jar getLatinTag.jar fr  fr "femmes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "construction" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "désormais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "distribution" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "telle" 1000  keyword_fr.txt
