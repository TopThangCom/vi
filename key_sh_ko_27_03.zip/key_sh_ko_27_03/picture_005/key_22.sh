java -jar getLatinTag.jar kr ko "舵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鹿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蛇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聊" 1000  keyword_ko.txt
