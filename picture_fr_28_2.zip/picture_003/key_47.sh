java -jar getLatinTag.jar kr kr "眇觌玄风" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "式" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "构词" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "式光互联" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "式古堂" 1000  keyword_kr.txt
