java -jar getLatinTag.jar it it "bartolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "danielli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gnc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "titanic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "frontal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "region" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agni" 1000  keyword_it.txt
