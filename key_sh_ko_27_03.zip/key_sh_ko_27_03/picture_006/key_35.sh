java -jar getLatinTag.jar kr ko "蠹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "們" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "皆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "匈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嬰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拷" 1000  keyword_ko.txt
