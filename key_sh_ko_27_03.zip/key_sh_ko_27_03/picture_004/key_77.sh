java -jar getLatinTag.jar kr ko "밇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "봫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뢜" 1000  keyword_ko.txt
