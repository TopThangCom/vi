java -jar getLatinTag.jar kr ko "줰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꿌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "믚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "볦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꾴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폳" 1000  keyword_ko.txt
