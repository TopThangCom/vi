java -jar getLatinTag.jar it it "artdecorator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artecompapelfabianabim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "romanico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "palentino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pirce" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "zatti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tizio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "daldiano" 1000  keyword_it.txt
