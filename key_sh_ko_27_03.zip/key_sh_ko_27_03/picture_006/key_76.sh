java -jar getLatinTag.jar kr ko "닭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "醬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "샐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "從" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룡" 1000  keyword_ko.txt
