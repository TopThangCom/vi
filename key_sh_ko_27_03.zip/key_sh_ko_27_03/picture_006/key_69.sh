java -jar getLatinTag.jar kr ko "罩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "溯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "횡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챗" 1000  keyword_ko.txt
