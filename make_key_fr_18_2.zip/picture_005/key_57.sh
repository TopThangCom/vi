java -jar getLatinTag.jar fr  fr "Beaucoup" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fournir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "recherches" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "liés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tenue" 1000  keyword_fr.txt
