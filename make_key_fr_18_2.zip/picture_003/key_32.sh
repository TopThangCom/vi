java -jar getLatinTag.jar fr  fr "mondiale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "accord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "diverses" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "totalement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fil" 1000  keyword_fr.txt
