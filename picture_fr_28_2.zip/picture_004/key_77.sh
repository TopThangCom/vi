java -jar getLatinTag.jar kr kr "谏山创" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "作品" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "历史" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "天才" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村元吉" 1000  keyword_kr.txt
