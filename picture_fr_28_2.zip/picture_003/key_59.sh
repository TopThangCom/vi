java -jar getLatinTag.jar kr kr "교체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "景色" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英文" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "形容词" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英文翻译" 1000  keyword_kr.txt
