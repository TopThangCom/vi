java -jar getLatinTag.jar kr kr "费孝通江村" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ABS" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비중" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "冲云" 1000  keyword_kr.txt
