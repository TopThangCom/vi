java -jar getLatinTag.jar fr  fr "quoi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "particulier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "concurrence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "élevé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "position" 1000  keyword_fr.txt
