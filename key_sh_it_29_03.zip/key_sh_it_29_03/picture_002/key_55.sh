java -jar getLatinTag.jar it it "disciplinar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "advertima" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "advertorial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "advicor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "advicorp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "advisorclient" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "potential" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "remuneration" 1000  keyword_it.txt
