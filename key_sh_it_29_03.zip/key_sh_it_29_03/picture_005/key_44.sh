java -jar getLatinTag.jar it it "passaggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "livello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "axiomatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "azcentral" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "azidose" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "azitromicina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "moscatel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bocca" 1000  keyword_it.txt
