java -jar getLatinTag.jar fr  fr "indice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "neutre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Mon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constituer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'accord" 1000  keyword_fr.txt
