java -jar getLatinTag.jar kr ko "慘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "휠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "깡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "톰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "臓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "釈" 1000  keyword_ko.txt
