java -jar getLatinTag.jar kr ko "玫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瑰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "殲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "켈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쵸" 1000  keyword_ko.txt
