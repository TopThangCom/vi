java -jar getLatinTag.jar kr ko "廷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "叢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "삿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "덤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "榮" 1000  keyword_ko.txt
