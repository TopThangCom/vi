java -jar getLatinTag.jar it it "aidcon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aidentified" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diffuser" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aidone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riddim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "greco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dalt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aion" 1000  keyword_it.txt
