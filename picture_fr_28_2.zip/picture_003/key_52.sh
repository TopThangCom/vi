java -jar getLatinTag.jar kr kr "꿈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쥐새끼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쥐가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "번호변경" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안내" 1000  keyword_kr.txt
