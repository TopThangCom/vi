java -jar getLatinTag.jar kr kr "코닉스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "腰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "発音" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "痛い" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "背中" 1000  keyword_kr.txt
