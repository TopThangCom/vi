java -jar getLatinTag.jar kr ko "期" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "限" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "確" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "認" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "興" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "市" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "場" 1000  keyword_ko.txt
