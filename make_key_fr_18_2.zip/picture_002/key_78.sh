java -jar getLatinTag.jar fr  fr "Wallonie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Windows" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "termes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "met" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contraire" 1000  keyword_fr.txt
