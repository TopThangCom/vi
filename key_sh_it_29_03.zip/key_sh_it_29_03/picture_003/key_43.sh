java -jar getLatinTag.jar it it "paese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rifugio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antesco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antescope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scorrevoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "penelitian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antestor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carnificina" 1000  keyword_it.txt
