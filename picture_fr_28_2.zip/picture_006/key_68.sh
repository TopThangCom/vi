java -jar getLatinTag.jar kr kr "阿特福(c." 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "alderfer)提出的激勵理論" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "將人類需要的層級由低而高分成下列那三類" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "菅田" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "将" 1000  keyword_kr.txt
