java -jar getLatinTag.jar kr kr "에듀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사진" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "넣기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "도형에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "프레임" 1000  keyword_kr.txt
