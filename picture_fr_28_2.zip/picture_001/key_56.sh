java -jar getLatinTag.jar kr kr "라이덴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조합" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "원신" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "세팅" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "평타" 1000  keyword_kr.txt
