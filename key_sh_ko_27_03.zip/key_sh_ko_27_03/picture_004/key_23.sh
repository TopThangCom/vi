java -jar getLatinTag.jar kr ko "쳱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뫢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "붤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "숷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "솖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쳬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "읂" 1000  keyword_ko.txt
