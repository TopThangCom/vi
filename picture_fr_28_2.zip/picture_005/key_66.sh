java -jar getLatinTag.jar kr kr "+" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "燈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "遙控" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鋼材の一般受渡し条件" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "酸素解離曲線" 1000  keyword_kr.txt
