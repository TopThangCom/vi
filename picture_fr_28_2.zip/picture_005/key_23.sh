java -jar getLatinTag.jar kr kr "교과서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통합과학" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통합문서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통합사회" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미래엔" 1000  keyword_kr.txt
