java -jar getLatinTag.jar kr kr "お座敷列車" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "奥多摩" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "松尾" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "和子" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "お座敷小唄" 1000  keyword_kr.txt
