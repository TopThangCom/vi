java -jar getLatinTag.jar fr  fr "possible" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "toutefois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nouveaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "selon" 1000  keyword_fr.txt
