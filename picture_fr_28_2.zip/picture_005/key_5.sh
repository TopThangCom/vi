java -jar getLatinTag.jar kr kr "확률" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "버그판" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "손흥민" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레벨업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "계산기" 1000  keyword_kr.txt
