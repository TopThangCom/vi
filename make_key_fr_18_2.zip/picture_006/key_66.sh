java -jar getLatinTag.jar fr  fr "léger" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mener" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "propriétaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spécifique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "récupérer" 1000  keyword_fr.txt
