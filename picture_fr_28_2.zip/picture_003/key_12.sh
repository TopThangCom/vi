java -jar getLatinTag.jar kr kr "각" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "wsl" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제거" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "재설치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배포판" 1000  keyword_kr.txt
