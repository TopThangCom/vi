java -jar getLatinTag.jar kr kr "実家" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nhk" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "解説委員" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "今井尚哉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "岩田明子解説委員" 1000  keyword_kr.txt
