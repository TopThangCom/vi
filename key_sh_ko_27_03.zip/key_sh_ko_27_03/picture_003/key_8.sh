java -jar getLatinTag.jar kr ko "衣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "施" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "被" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "逆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "黙" 1000  keyword_ko.txt
