java -jar getLatinTag.jar it it "aritmetica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assurdel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "patterns" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ticino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astanteria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "animation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legions" 1000  keyword_it.txt
