java -jar getLatinTag.jar kr kr "클래식" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해커톤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "링크스킬" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정리표" 1000  keyword_kr.txt
