java -jar getLatinTag.jar kr kr "인벤토리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "확장" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실루엣" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "박제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "퍼즐" 1000  keyword_kr.txt
