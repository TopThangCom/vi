java -jar getLatinTag.jar kr ko "晰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퀀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "郡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "荻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "窪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "둥" 1000  keyword_ko.txt
