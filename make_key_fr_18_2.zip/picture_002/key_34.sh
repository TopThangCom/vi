java -jar getLatinTag.jar fr  fr "propose" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gens" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "derniers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "étant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fut" 1000  keyword_fr.txt
