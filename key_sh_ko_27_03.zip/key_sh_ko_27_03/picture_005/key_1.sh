java -jar getLatinTag.jar kr ko "努" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "講" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "눈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "姫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탭" 1000  keyword_ko.txt
