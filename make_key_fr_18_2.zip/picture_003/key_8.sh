java -jar getLatinTag.jar fr  fr "soi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "métier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "probablement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aller" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'investissement" 1000  keyword_fr.txt
