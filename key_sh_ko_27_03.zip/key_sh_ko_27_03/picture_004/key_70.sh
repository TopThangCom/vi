java -jar getLatinTag.jar kr ko "尊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "爵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "矽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鏈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歐" 1000  keyword_ko.txt
