java -jar getLatinTag.jar it it "integratore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "baicoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fertilizer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "froide" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "crianza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alfandega" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avillez" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cavi" 1000  keyword_it.txt
