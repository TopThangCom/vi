java -jar getLatinTag.jar kr kr "메일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수신확인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "만들기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "로그인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아웃룩" 1000  keyword_kr.txt
