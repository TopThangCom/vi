java -jar getLatinTag.jar kr kr "메인힐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "섭힐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메인딜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서브딜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "더스틴" 1000  keyword_kr.txt
