java -jar getLatinTag.jar fr  fr "Gand" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chargé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "économies" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Nos" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "augmente" 1000  keyword_fr.txt
