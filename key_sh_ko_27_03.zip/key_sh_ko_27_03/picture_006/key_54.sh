java -jar getLatinTag.jar kr ko "蓋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "毫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "爾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "堪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "炫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밥" 1000  keyword_ko.txt
