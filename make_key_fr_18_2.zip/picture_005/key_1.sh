java -jar getLatinTag.jar fr  fr "cotées" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "décide" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "L'action" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Cependant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Certaines" 1000  keyword_fr.txt
