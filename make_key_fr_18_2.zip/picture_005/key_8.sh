java -jar getLatinTag.jar fr  fr "Patrick" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "proposé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "salon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "territoire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fixé" 1000  keyword_fr.txt
