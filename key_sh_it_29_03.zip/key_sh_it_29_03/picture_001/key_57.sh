java -jar getLatinTag.jar it it "parental" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "redentivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gascogne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "approval" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acoramone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acorane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castillo" 1000  keyword_it.txt
