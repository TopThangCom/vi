java -jar getLatinTag.jar kr kr "머신러닝을" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "위한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파이썬" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "넘파이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미적분" 1000  keyword_kr.txt
