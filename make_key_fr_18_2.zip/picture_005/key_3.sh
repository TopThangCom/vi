java -jar getLatinTag.jar fr  fr "déclaration" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "multiples" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quartier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vidéo" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dépend" 1000  keyword_fr.txt
