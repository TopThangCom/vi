java -jar getLatinTag.jar fr  fr "l'an" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moyen" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "choix" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "doivent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "NLG" 1000  keyword_fr.txt
