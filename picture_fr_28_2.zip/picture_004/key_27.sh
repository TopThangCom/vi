java -jar getLatinTag.jar kr kr "전원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ups" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전원장치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "란" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무정전" 1000  keyword_kr.txt
