java -jar getLatinTag.jar it it "regional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "altomira" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abuelito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infinite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "congresso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autoglass" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "norton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "resistance" 1000  keyword_it.txt
