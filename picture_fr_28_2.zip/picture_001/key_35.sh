java -jar getLatinTag.jar kr kr "google" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "열어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "줘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "lp" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관리자" 1000  keyword_kr.txt
