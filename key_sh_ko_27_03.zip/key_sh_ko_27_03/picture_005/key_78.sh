java -jar getLatinTag.jar kr ko "萃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "礙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "枕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聯" 1000  keyword_ko.txt
