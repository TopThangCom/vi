java -jar getLatinTag.jar kr ko "債" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "券" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "基" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "金" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "股" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "美" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "元" 1000  keyword_ko.txt
