java -jar getLatinTag.jar kr ko "북" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "읽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쥐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "덫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뭐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "났" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "끈" 1000  keyword_ko.txt
