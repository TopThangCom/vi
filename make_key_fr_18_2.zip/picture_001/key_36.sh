java -jar getLatinTag.jar fr  fr "jeunes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cinq" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contrat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Banque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "valeurs" 1000  keyword_fr.txt
