java -jar getLatinTag.jar fr  fr "Namur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bilan" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Vif" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sensiblement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Trois" 1000  keyword_fr.txt
