java -jar getLatinTag.jar kr ko "넬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "께" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瀬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嫁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滅" 1000  keyword_ko.txt
