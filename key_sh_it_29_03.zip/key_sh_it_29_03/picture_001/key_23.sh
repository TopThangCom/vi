java -jar getLatinTag.jar it it "absorbantie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conditions" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absorto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absorbitant" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "annos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atomica" 1000  keyword_it.txt
