java -jar getLatinTag.jar it it "preterio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiot" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attitude" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "signature" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perpignan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scpi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "puppies" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adoptivvater" 1000  keyword_it.txt
