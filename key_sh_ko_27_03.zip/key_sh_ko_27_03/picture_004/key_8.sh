java -jar getLatinTag.jar kr ko "仙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "劍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哲" 1000  keyword_ko.txt
