java -jar getLatinTag.jar fr  fr "faibles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "location" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "promotion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "technologies" 1000  keyword_fr.txt
