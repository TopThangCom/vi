java -jar getLatinTag.jar it it "ascania" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascanio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pacelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "leopoldo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascarat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascaravelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascardia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascarding" 1000  keyword_it.txt
