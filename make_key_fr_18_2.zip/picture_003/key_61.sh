java -jar getLatinTag.jar fr  fr "réel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "The" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "puissance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fixe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Belgium" 1000  keyword_fr.txt
