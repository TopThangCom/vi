java -jar getLatinTag.jar kr kr "모델" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "경량화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배포" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "최적화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "평가" 1000  keyword_kr.txt
