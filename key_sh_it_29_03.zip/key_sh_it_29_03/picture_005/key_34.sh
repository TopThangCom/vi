java -jar getLatinTag.jar it it "terminators" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atramentiert" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atramentove" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carnivora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "convenio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "restorative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "femicidio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "simonetti" 1000  keyword_it.txt
