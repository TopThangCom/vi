java -jar getLatinTag.jar kr kr "세이브파일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선택지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "랑종" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "밍" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "밍크" 1000  keyword_kr.txt
