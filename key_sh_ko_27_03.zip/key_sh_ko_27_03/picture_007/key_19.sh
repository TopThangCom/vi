java -jar getLatinTag.jar kr ko "쉴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "륜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "屑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "竜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "箕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "琳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誹" 1000  keyword_ko.txt
