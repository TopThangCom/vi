java -jar getLatinTag.jar fr  fr "Etats-Unis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'ils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'action" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "celle" 1000  keyword_fr.txt
