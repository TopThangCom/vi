java -jar getLatinTag.jar kr ko "獵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "羯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "炳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "惘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瓊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "荊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薔" 1000  keyword_ko.txt
