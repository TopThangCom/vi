java -jar getLatinTag.jar it it "profissional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcprocessortrigger" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clontarf" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adcritter" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addclass" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "removeclass" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scoped" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corrispettivi" 1000  keyword_it.txt
