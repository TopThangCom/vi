java -jar getLatinTag.jar kr kr "안돼지요" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그러면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그럼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안되" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구별법" 1000  keyword_kr.txt
