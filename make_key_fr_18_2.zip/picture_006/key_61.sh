java -jar getLatinTag.jar fr  fr "réalisés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'emplois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'éviter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'ouverture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "méthodes" 1000  keyword_fr.txt
