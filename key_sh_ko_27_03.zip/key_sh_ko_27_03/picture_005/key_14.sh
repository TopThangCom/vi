java -jar getLatinTag.jar kr ko "乃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "閣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "낸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "둠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싶" 1000  keyword_ko.txt
