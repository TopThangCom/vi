java -jar getLatinTag.jar fr  fr "Cela" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "serait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fort" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "frais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lieu" 1000  keyword_fr.txt
