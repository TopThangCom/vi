java -jar getLatinTag.jar kr kr "北风萧萧" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "天地" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "一片" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "苍茫" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "雪花飘飘北风萧萧迷因" 1000  keyword_kr.txt
