java -jar getLatinTag.jar kr kr "배경" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "도안" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일러스트레이터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일러스트레이션" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "거미줄" 1000  keyword_kr.txt
