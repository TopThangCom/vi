java -jar getLatinTag.jar it it "grammtica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "treccani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addscore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calciatore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lazio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chapelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cascavel" 1000  keyword_it.txt
