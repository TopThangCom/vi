java -jar getLatinTag.jar it it "afiliaciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disciplinas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "igual" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "impresora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqquagger" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "martorell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalogo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "goggles" 1000  keyword_it.txt
