java -jar getLatinTag.jar it it "antidotal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antidote" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vaccine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antidoto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "benzodiazepine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "classica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oriental" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "egito" 1000  keyword_it.txt
