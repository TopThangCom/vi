java -jar getLatinTag.jar kr ko "봄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뷰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "최" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "집" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "투" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "初" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "化" 1000  keyword_ko.txt
