java -jar getLatinTag.jar it it "dillon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monasterio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ranzolin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dalton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "armorcon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "armorcore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colesterolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "armorion" 1000  keyword_it.txt
