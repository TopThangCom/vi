java -jar getLatinTag.jar it it "altra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "milliamperes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "voltios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperizal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stomp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperometric" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperometro" 1000  keyword_it.txt
