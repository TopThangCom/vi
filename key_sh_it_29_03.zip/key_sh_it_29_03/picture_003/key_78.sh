java -jar getLatinTag.jar it it "amoraltra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "immoral" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dissertation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amorcito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amordino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amordiorah" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amordiorha" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amordio" 1000  keyword_it.txt
