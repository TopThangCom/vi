java -jar getLatinTag.jar kr kr "船橋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "竹田純" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "竹田純一" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "柏書房" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "順天堂" 1000  keyword_kr.txt
