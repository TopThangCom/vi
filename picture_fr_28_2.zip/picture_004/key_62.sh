java -jar getLatinTag.jar kr kr "fe" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "滅火器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "價格" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뉴진스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "민지" 1000  keyword_kr.txt
