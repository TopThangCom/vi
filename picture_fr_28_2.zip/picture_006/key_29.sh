java -jar getLatinTag.jar kr kr "보는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하린" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실물" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "타" 1000  keyword_kr.txt
