java -jar getLatinTag.jar fr  fr "Au" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "reste" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "non" 1000  keyword_fr.txt
