java -jar getLatinTag.jar it it "economy" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assoartigiani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assoartiglieri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pontal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montepio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dermatology" 1000  keyword_it.txt
