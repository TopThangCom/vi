java -jar getLatinTag.jar kr ko "倦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鉑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "阮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쁨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弔" 1000  keyword_ko.txt
