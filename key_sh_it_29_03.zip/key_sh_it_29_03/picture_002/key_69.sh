java -jar getLatinTag.jar it it "acceso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alternativos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tradicional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grant" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aguamenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imprime" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nelas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gottes" 1000  keyword_it.txt
