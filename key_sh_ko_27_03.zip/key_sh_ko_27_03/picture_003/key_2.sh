java -jar getLatinTag.jar kr ko "膜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "枚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "牙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "収" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "胃" 1000  keyword_ko.txt
