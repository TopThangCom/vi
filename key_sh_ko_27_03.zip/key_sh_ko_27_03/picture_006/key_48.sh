java -jar getLatinTag.jar kr ko "敢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "榨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "癬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "顕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "佰" 1000  keyword_ko.txt
