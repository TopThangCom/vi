java -jar getLatinTag.jar fr  fr "Qui" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "libre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rachat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Toutefois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "portes" 1000  keyword_fr.txt
