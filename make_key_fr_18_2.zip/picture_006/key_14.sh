java -jar getLatinTag.jar fr  fr "négatif" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "allemands" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'activité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "roman" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "victime" 1000  keyword_fr.txt
