java -jar getLatinTag.jar kr kr "肌力训练" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力训练菜单" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力训练科学解析" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力训练英文" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力评估量表" 1000  keyword_kr.txt
