java -jar getLatinTag.jar fr  fr "financement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "disponibles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vieux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marge" 1000  keyword_fr.txt
