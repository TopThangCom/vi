java -jar getLatinTag.jar fr  fr "activité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'exercice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'objet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tient" 1000  keyword_fr.txt
