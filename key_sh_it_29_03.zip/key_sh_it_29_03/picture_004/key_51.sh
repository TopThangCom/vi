java -jar getLatinTag.jar it it "llodio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "relic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambivalente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "evitativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inseguro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mccann" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comprension" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diabetic" 1000  keyword_it.txt
