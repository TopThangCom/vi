java -jar getLatinTag.jar it it "arrata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arratia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coreografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "datamovil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "economica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arrendatario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chamusca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "almoster" 1000  keyword_it.txt
