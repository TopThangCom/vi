java -jar getLatinTag.jar it it "admettons" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "relias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "documentation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adminclientconfig" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "deletetopics" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "console" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admincontroller" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "logg" 1000  keyword_it.txt
