java -jar getLatinTag.jar fr  fr "tel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "durée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "domaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aurait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jeune" 1000  keyword_fr.txt
