java -jar getLatinTag.jar it it "cardiology" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "senator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neoprene" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "integralmedica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scandal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bartolito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monserrat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nobita" 1000  keyword_it.txt
