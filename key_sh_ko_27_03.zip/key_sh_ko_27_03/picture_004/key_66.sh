java -jar getLatinTag.jar kr ko "숙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "괴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "튀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "然" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "펜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "實" 1000  keyword_ko.txt
