java -jar getLatinTag.jar kr ko "覽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "餘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蘿" 1000  keyword_ko.txt
