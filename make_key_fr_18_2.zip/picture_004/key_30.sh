java -jar getLatinTag.jar fr  fr "servir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bernard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commission" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faiblesse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plus-value" 1000  keyword_fr.txt
