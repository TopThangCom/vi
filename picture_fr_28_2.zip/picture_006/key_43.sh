java -jar getLatinTag.jar kr kr "더" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이따" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이따요" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "말도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "잘" 1000  keyword_kr.txt
