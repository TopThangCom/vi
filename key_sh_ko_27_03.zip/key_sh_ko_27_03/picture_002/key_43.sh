java -jar getLatinTag.jar kr ko "입" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "술" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "각" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "재" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "唐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "揚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "複" 1000  keyword_ko.txt
