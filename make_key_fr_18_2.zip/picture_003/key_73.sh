java -jar getLatinTag.jar fr  fr "annoncé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "choisi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "découvrir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "soutien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avez" 1000  keyword_fr.txt
