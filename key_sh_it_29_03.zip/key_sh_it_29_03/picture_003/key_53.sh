java -jar getLatinTag.jar it it "emollient" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italien" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "federica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "micca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cornella" 1000  keyword_it.txt
