java -jar getLatinTag.jar fr  fr "guide" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "proposition" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "laissé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spécialiste" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "francophones" 1000  keyword_fr.txt
