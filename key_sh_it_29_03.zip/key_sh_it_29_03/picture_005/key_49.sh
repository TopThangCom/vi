java -jar getLatinTag.jar it it "costal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atorvastatin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atosil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diagne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fatal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atraco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lolla" 1000  keyword_it.txt
