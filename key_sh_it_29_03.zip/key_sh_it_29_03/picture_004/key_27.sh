java -jar getLatinTag.jar it it "segni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "principal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascendian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascending" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascendino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascendio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appliance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trio" 1000  keyword_it.txt
