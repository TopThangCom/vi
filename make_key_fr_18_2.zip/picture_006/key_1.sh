java -jar getLatinTag.jar fr  fr "collaborateurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "implique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'assurance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "obligataire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "établi" 1000  keyword_fr.txt
