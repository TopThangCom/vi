java -jar getLatinTag.jar it it "ali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "automatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "metropolitano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vibratorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imposto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimentando" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimentation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tecnico" 1000  keyword_it.txt
