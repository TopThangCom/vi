java -jar getLatinTag.jar fr  fr "professionnelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "affirme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'intérieur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Wall" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "charges" 1000  keyword_fr.txt
