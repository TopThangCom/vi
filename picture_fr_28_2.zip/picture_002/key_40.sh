java -jar getLatinTag.jar kr kr "데이터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "유심" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고객센터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시간" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "번호" 1000  keyword_kr.txt
