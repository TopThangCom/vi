java -jar getLatinTag.jar fr  fr "effectué" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fortune" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fournit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lecteurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Morgan" 1000  keyword_fr.txt
