java -jar getLatinTag.jar fr  fr "davantage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ensuite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "janvier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "donne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vrai" 1000  keyword_fr.txt
