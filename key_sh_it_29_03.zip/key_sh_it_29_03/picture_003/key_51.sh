java -jar getLatinTag.jar it it "processing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amerio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amerion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ameroid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infonet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "servizio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amescisig" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amessio" 1000  keyword_it.txt
