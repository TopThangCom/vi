java -jar getLatinTag.jar fr  fr "d'environ" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "exactement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "outil" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "scénario" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Jones" 1000  keyword_fr.txt
