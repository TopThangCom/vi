java -jar getLatinTag.jar kr ko "申" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "都" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "베" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "툰" 1000  keyword_ko.txt
