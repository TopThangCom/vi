java -jar getLatinTag.jar kr ko "做" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瑪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "糖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "官" 1000  keyword_ko.txt
