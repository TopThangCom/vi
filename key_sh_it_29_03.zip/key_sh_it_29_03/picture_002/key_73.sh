java -jar getLatinTag.jar it it "almoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "moridi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cucullata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alondra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "graduation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dolomit" 1000  keyword_it.txt
