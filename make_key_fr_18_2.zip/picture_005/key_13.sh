java -jar getLatinTag.jar fr  fr "textes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quasi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "SNCB" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jeux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "permettra" 1000  keyword_fr.txt
