java -jar getLatinTag.jar kr ko "黎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "攻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "殻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "政" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "碗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宛" 1000  keyword_ko.txt
