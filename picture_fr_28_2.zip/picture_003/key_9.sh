java -jar getLatinTag.jar kr kr "英語" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英語で" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "終了" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "名詞" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "久喜" 1000  keyword_kr.txt
