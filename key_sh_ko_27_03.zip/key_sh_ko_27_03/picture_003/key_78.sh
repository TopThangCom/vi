java -jar getLatinTag.jar kr ko "훌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "십" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "첩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "것" 1000  keyword_ko.txt
