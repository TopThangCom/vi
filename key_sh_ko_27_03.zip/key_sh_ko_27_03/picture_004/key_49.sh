java -jar getLatinTag.jar kr ko "둊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쀁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "놕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뇒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "줒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뽒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "힦" 1000  keyword_ko.txt
