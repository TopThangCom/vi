java -jar getLatinTag.jar it it "fiorentino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vecchio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calarossani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calaveras" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fascite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcanhotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retratil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "descartavel" 1000  keyword_it.txt
