java -jar getLatinTag.jar kr ko "숨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "츠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "농" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "댓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "起" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "英" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "了" 1000  keyword_ko.txt
