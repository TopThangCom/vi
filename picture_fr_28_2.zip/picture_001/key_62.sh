java -jar getLatinTag.jar kr kr "묘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다시보기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자막" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "더빙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "넷플릭스" 1000  keyword_kr.txt
