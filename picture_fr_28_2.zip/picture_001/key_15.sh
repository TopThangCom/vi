java -jar getLatinTag.jar kr kr "메인딜러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서브딜러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메인탱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "궁극기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스킨" 1000  keyword_kr.txt
