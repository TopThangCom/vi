java -jar getLatinTag.jar fr  fr "réponse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'exploitation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "concept" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "obtenir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "poste" 1000  keyword_fr.txt
