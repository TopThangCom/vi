java -jar getLatinTag.jar kr ko "楽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "古" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "記" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "従" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "員" 1000  keyword_ko.txt
