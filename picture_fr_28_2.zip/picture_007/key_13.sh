java -jar getLatinTag.jar kr kr "창원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "광주" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조인선" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변호사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스타워즈" 1000  keyword_kr.txt
