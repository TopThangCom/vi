java -jar getLatinTag.jar it it "bascat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "baschirotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bascol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ocasion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bascovani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "basculegion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "basecone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "basidiocarpo" 1000  keyword_it.txt
