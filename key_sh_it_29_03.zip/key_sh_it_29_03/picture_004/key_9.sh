java -jar getLatinTag.jar it it "apero" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dinatoire" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aperol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sprizz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricolas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aperregi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "quantitativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinto" 1000  keyword_it.txt
