java -jar getLatinTag.jar kr kr "다시" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "얼마" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안되지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼지만" 1000  keyword_kr.txt
