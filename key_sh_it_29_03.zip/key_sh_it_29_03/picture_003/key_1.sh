java -jar getLatinTag.jar it it "concha" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aggression" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ppr" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "panico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scalene" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caldwell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capriche" 1000  keyword_it.txt
