java -jar getLatinTag.jar kr kr "프로토콜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인버터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메뉴얼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카탈로그" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "에러" 1000  keyword_kr.txt
