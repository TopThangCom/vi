java -jar getLatinTag.jar kr kr "전용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "入力規則" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "解除" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "共有" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정우.밍" 1000  keyword_kr.txt
