java -jar getLatinTag.jar it it "aquapurator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "silica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solargraph" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autolavaggi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "benicassim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lavaggi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "novello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capodanno" 1000  keyword_it.txt
