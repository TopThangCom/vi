java -jar getLatinTag.jar kr kr "新日本有限責任監査法人" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ja富山市" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "中央支店" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "南支店" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "本店" 1000  keyword_kr.txt
