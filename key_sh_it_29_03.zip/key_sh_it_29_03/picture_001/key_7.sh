java -jar getLatinTag.jar it it "perianales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "periodontales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abscess" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abscessed" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abscesso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abscomm" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abscond" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absconder" 1000  keyword_it.txt
