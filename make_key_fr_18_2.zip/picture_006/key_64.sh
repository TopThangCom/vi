java -jar getLatinTag.jar fr  fr "montrent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "placé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "loyer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "proximité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voient" 1000  keyword_fr.txt
