java -jar getLatinTag.jar fr  fr "venir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "générale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "courant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suffit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'ordre" 1000  keyword_fr.txt
