java -jar getLatinTag.jar kr ko "찬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "畫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "먼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "橢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "圓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "響" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雲" 1000  keyword_ko.txt
