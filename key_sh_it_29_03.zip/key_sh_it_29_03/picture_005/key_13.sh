java -jar getLatinTag.jar it it "autodemolizioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pollini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autodenominazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "continuo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castellar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autodocgoogle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "berazategui" 1000  keyword_it.txt
