java -jar getLatinTag.jar kr ko "敬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "畏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "譯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "暖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崖" 1000  keyword_ko.txt
