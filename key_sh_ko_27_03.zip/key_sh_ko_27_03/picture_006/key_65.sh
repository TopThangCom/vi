java -jar getLatinTag.jar kr ko "恐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "謙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "驗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鼓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "夸" 1000  keyword_ko.txt
