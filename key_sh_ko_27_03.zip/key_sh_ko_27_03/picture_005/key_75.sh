java -jar getLatinTag.jar kr ko "잉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "侵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "銭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雯" 1000  keyword_ko.txt
