java -jar getLatinTag.jar fr  fr "délais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "inférieure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spécial" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Amérique" 1000  keyword_fr.txt
