java -jar getLatinTag.jar it it "impressora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nazionale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oristano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "palermo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adiouza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adipic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adipose" 1000  keyword_it.txt
