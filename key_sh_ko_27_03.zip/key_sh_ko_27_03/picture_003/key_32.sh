java -jar getLatinTag.jar kr ko "붉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "흔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뜨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꼭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "펭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "귄" 1000  keyword_ko.txt
