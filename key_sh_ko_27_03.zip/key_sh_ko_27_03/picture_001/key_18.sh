java -jar getLatinTag.jar kr ko "료" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "개" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "귀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "여" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "운" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "할" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "윈" 1000  keyword_ko.txt
