java -jar getLatinTag.jar fr  fr "demande" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "belges" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ceux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "services" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bonne" 1000  keyword_fr.txt
