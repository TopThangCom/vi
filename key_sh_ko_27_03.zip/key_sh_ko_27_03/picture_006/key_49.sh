java -jar getLatinTag.jar kr ko "晒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "讃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쩌" 1000  keyword_ko.txt
