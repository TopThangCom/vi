java -jar getLatinTag.jar fr  fr "électrique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dynamique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "exposition" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "installé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plancher" 1000  keyword_fr.txt
