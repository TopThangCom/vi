java -jar getLatinTag.jar kr ko "上" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "郵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "築" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "読" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貸" 1000  keyword_ko.txt
