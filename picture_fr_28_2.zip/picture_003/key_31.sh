java -jar getLatinTag.jar kr kr "鈴木康之法律事務所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田愛斗" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "結婚" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田愛奈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "卒業" 1000  keyword_kr.txt
