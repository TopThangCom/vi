java -jar getLatinTag.jar kr kr "일렉트릭" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전기기능사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전기기사" 1000  keyword_kr.txt
