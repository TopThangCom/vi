java -jar getLatinTag.jar kr kr "木村元紀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pwc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "憲治" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村精市" 1000  keyword_kr.txt
