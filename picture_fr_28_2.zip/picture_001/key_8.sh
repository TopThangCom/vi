java -jar getLatinTag.jar kr kr "기타리스트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스페셜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조필성" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "물리학" 1000  keyword_kr.txt
