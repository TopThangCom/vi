java -jar getLatinTag.jar it it "absolventa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "crime" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "citate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "equation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "transmittance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concentration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "transmitancia" 1000  keyword_it.txt
