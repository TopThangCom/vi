java -jar getLatinTag.jar it it "complementaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "permanente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clave" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aportesingecivil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "proporcional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "profesionales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apostafc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prognosticos" 1000  keyword_it.txt
