java -jar getLatinTag.jar kr ko "帳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "広" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "高" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "랙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "에" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "作" 1000  keyword_ko.txt
