java -jar getLatinTag.jar fr  fr "meilleures" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Parce" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entrée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vendredi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "actif" 1000  keyword_fr.txt
