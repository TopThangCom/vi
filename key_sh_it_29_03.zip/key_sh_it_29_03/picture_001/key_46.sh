java -jar getLatinTag.jar it it "classic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "qualcuno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "persona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colpo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pranzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imperfetto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spagnolo" 1000  keyword_it.txt
