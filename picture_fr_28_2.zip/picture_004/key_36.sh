java -jar getLatinTag.jar kr kr "lot#" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "qos" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서비스센터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "출장비" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "청소" 1000  keyword_kr.txt
