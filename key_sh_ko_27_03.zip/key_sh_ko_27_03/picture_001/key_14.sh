java -jar getLatinTag.jar kr ko "牛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "館" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "眼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "套" 1000  keyword_ko.txt
