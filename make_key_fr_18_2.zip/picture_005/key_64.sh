java -jar getLatinTag.jar fr  fr "débat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'Allemagne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "élevée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ouvrage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "police" 1000  keyword_fr.txt
