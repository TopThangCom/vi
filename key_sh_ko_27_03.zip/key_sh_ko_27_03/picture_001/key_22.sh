java -jar getLatinTag.jar kr ko "깊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "은" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "의" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "명" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "종" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "류" 1000  keyword_ko.txt
