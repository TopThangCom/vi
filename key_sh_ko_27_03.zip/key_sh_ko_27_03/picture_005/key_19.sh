java -jar getLatinTag.jar kr ko "緑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "牧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "欄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "顔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奉" 1000  keyword_ko.txt
