java -jar getLatinTag.jar fr  fr "chiffres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Générale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dix" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prochain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'Etat" 1000  keyword_fr.txt
