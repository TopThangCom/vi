java -jar getLatinTag.jar kr kr "膝力康按摩器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛沙發按摩椅" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "裄綿" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "付け方" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "共布" 1000  keyword_kr.txt
