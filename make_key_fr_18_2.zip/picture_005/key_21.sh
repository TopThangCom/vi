java -jar getLatinTag.jar fr  fr "capable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "classe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "familiale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réserve" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fonctionne" 1000  keyword_fr.txt
