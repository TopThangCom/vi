java -jar getLatinTag.jar fr  fr "performances" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "électronique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "haute" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "responsables" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lancé" 1000  keyword_fr.txt
