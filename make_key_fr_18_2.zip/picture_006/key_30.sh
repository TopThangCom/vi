java -jar getLatinTag.jar fr  fr "coupons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'émission" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "estiment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "défi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "protéger" 1000  keyword_fr.txt
