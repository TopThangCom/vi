java -jar getLatinTag.jar kr ko "串" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "魚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "醒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "榆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渠" 1000  keyword_ko.txt
