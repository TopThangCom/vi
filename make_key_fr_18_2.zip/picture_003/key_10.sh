java -jar getLatinTag.jar fr  fr "Ensuite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Luxembourg" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "campagne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comptes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "hors" 1000  keyword_fr.txt
