java -jar getLatinTag.jar kr kr "아카이브" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "저장" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "광고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "차단" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "크롬" 1000  keyword_kr.txt
