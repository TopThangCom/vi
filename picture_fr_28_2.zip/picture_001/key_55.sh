java -jar getLatinTag.jar kr kr "대상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트위치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "화질" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "풀기" 1000  keyword_kr.txt
