java -jar getLatinTag.jar kr kr "苗字" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "読谷" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "沖縄そば" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "喜納" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "沖縄市" 1000  keyword_kr.txt
