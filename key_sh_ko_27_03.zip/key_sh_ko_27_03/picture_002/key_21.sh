java -jar getLatinTag.jar kr ko "比" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "較" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "受" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "格" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "実" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "績" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "備" 1000  keyword_ko.txt
