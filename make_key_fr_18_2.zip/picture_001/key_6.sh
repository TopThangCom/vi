java -jar getLatinTag.jar fr  fr "n'ont" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "veut" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "présent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "passé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "forme" 1000  keyword_fr.txt
