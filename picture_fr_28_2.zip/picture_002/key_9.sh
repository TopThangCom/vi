java -jar getLatinTag.jar kr kr "문열림센서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스마트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "플러그" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "연결" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네트워크" 1000  keyword_kr.txt
