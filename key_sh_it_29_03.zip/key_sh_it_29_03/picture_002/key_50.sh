java -jar getLatinTag.jar it it "diagnosis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artificial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "materno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "graffito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caledonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magnesium" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nataclor" 1000  keyword_it.txt
