java -jar getLatinTag.jar it it "preston" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ferentino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "matto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "marcato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "canela" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biscottando" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bissoto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bissotto" 1000  keyword_it.txt
