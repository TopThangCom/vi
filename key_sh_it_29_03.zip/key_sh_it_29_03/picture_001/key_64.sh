java -jar getLatinTag.jar it it "simple" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "station" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guidelines" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "india" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acoiriome" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interior" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pottery" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acomatic" 1000  keyword_it.txt
