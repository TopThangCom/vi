java -jar getLatinTag.jar kr ko "婷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "艇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "핏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "叫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "럿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "놀" 1000  keyword_ko.txt
