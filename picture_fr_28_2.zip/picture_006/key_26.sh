java -jar getLatinTag.jar kr kr "책임" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "항목" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사회공헌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사회공헌활동" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사회복지" 1000  keyword_kr.txt
