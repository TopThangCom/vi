java -jar getLatinTag.jar fr  fr "que" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "est" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qui" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dans" 1000  keyword_fr.txt
