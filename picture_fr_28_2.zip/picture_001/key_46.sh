java -jar getLatinTag.jar kr kr "스킬" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한글" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트레이너" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "슈퍼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "hd" 1000  keyword_kr.txt
