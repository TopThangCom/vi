java -jar getLatinTag.jar it it "ampopfilms" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampopmusic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "subtrator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampregol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amprenta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amprevolt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amprion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "decorativa" 1000  keyword_it.txt
