java -jar getLatinTag.jar kr kr "전화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "할당" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٧٨٧×٢" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "外中" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "外中派出所" 1000  keyword_kr.txt
