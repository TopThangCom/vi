java -jar getLatinTag.jar fr  fr "genre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bureau" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "communication" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "participation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gros" 1000  keyword_fr.txt
