java -jar getLatinTag.jar kr kr "形振り" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "納米水霧膠原蛋白美髮風筒" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "お隣速報" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "台湾" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "天皇" 1000  keyword_kr.txt
