java -jar getLatinTag.jar kr kr "뱀파이어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "라이프" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "포스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "보기" 1000  keyword_kr.txt
