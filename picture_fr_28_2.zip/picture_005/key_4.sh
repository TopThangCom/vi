java -jar getLatinTag.jar kr kr "통합" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통합인쇄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오버로드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통합본" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "천재교육" 1000  keyword_kr.txt
