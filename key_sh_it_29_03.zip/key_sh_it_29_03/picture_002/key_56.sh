java -jar getLatinTag.jar it it "rico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ric" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giordani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "integrales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tropicales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agroilla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mallorca" 1000  keyword_it.txt
