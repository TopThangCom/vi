java -jar getLatinTag.jar it it "accento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrollar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiusano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotilleo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fantamorph" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concerto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absceso" 1000  keyword_it.txt
