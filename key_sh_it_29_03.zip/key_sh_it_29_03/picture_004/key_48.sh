java -jar getLatinTag.jar it it "neologismo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diagnostics" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "metalicos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cities" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conosco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pimenta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "restalliance" 1000  keyword_it.txt
