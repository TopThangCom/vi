java -jar getLatinTag.jar it it "giancarlo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "picnico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collirio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compresse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "controindicazioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "litosfera" 1000  keyword_it.txt
