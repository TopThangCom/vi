java -jar getLatinTag.jar fr  fr "nature" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "second" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "payer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "actuel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Elles" 1000  keyword_fr.txt
