java -jar getLatinTag.jar fr  fr "luxembourgeois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "achats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "solde" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Serge" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "globale" 1000  keyword_fr.txt
