java -jar getLatinTag.jar kr ko "臥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "簧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "筏" 1000  keyword_ko.txt
