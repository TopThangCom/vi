java -jar getLatinTag.jar kr ko "偉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "郷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "辺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "畿" 1000  keyword_ko.txt
