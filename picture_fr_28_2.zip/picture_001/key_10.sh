java -jar getLatinTag.jar kr kr "매개" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "길이가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "잘못되었습니다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "mssql" 1000  keyword_kr.txt
