java -jar getLatinTag.jar fr  fr "distributeurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "déclare" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "connue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'avons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "préparation" 1000  keyword_fr.txt
