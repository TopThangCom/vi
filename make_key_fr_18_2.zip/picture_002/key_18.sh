java -jar getLatinTag.jar fr  fr "passer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "départ" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "total" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "série" 1000  keyword_fr.txt
