java -jar getLatinTag.jar kr kr "xl" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "k-esg" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지표" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "업계" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "간담회" 1000  keyword_kr.txt
