java -jar getLatinTag.jar it it "otto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diritto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arromantica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arromantico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "potager" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arrosion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coloriage" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pelle" 1000  keyword_it.txt
