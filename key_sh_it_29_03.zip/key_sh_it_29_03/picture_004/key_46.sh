java -jar getLatinTag.jar it it "quatro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aparatoso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "goianesia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "estatal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "auditivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ortodontico" 1000  keyword_it.txt
