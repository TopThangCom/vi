java -jar getLatinTag.jar fr  fr "l'option" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Jean-Pierre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "articles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "changements" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fallu" 1000  keyword_fr.txt
