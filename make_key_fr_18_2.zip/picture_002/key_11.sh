java -jar getLatinTag.jar fr  fr "M" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "BBL" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "relativement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Deux" 1000  keyword_fr.txt
