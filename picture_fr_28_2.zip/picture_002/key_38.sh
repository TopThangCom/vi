java -jar getLatinTag.jar kr kr "문의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "예약" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "장애신고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가능지역" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다이렉트" 1000  keyword_kr.txt
