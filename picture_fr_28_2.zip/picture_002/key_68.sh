java -jar getLatinTag.jar kr kr "다이렉트샵" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개통" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "플랜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바로픽업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "광랜" 1000  keyword_kr.txt
