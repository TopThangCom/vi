java -jar getLatinTag.jar fr  fr "naturel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "principale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "support" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "week-end" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Dehaene" 1000  keyword_fr.txt
