java -jar getLatinTag.jar kr kr "新冠肺炎症状" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新冠肺炎症状第一天" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新冠肺炎症状喉咙痛" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新冠肺炎症状后遗症" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新冠肺炎症状吃什么药" 1000  keyword_kr.txt
