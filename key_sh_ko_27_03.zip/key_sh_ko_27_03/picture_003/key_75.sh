java -jar getLatinTag.jar kr ko "莫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "據" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "毛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "째" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밍" 1000  keyword_ko.txt
