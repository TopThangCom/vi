java -jar getLatinTag.jar kr ko "衢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蓄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "靴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "苔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "捐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "薄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "枯" 1000  keyword_ko.txt
