java -jar getLatinTag.jar fr  fr "actuelle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "permis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dossier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Quand" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'heure" 1000  keyword_fr.txt
