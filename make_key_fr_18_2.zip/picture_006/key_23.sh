java -jar getLatinTag.jar fr  fr "réglementation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "salles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "grimpé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prochains" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prévue" 1000  keyword_fr.txt
