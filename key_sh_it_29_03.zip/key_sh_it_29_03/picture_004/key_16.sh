java -jar getLatinTag.jar it it "trello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aoratoto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sigle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "doll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asigmatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secondo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sigmatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pretorio" 1000  keyword_it.txt
