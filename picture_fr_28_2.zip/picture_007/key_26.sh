java -jar getLatinTag.jar kr kr "모양" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "브랜드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "특수문자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무드등" 1000  keyword_kr.txt
