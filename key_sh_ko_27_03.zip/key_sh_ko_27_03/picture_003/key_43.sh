java -jar getLatinTag.jar kr ko "払" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꼼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "販" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "売" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "態" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "培" 1000  keyword_ko.txt
