java -jar getLatinTag.jar kr ko "컬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "단" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "테" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "애" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "덴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "합" 1000  keyword_ko.txt
