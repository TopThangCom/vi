java -jar getLatinTag.jar kr ko "賀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "孟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "采" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "菸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "項" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "患" 1000  keyword_ko.txt
