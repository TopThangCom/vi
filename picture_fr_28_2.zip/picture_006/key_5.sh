java -jar getLatinTag.jar kr kr "지속가능경영" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사회문제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사회" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "세미나" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국생산성본부" 1000  keyword_kr.txt
