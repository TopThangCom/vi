java -jar getLatinTag.jar fr  fr "l'homme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Chez" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "retour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'elles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "C" 1000  keyword_fr.txt
