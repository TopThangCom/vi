java -jar getLatinTag.jar kr kr "펀드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수익률" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "펀드의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그린워싱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "방지를" 1000  keyword_kr.txt
