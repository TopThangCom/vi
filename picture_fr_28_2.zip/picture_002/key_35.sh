java -jar getLatinTag.jar kr kr "サーバ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "保守期限" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "確認" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "nn" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "(l)" 1000  keyword_kr.txt
