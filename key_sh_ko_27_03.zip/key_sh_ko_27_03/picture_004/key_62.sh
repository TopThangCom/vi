java -jar getLatinTag.jar kr ko "葛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "搭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "唇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棒" 1000  keyword_ko.txt
