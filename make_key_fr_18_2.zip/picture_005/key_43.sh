java -jar getLatinTag.jar fr  fr "d'emploi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "hasard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "matin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "assureurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réforme" 1000  keyword_fr.txt
