java -jar getLatinTag.jar it it "aemon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rondonopolis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "polaris" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avocats" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "content" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "creators" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequantium" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aequationes" 1000  keyword_it.txt
