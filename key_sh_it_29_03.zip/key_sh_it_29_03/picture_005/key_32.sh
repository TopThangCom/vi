java -jar getLatinTag.jar it it "atravessarem" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atresia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inflamatorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attachment" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attoumane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unirio" 1000  keyword_it.txt
