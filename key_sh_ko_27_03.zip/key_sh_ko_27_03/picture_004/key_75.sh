java -jar getLatinTag.jar kr ko "봦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "췒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "줱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "돓" 1000  keyword_ko.txt
