java -jar getLatinTag.jar fr  fr "logiciels" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sommet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'activité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'en" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vivre" 1000  keyword_fr.txt
