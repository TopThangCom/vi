java -jar getLatinTag.jar kr kr "新興市場債券基金x股美元(月配息)" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新興市場債券基金x股對沖級別南非幣(月配息)" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "相信爱一天抵过永远" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "團購電器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ozen-ts自動翻炒氣炸爐" 1000  keyword_kr.txt
