java -jar getLatinTag.jar kr kr "익스프레스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "온라인상에서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "압축풀기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "led" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "白熱電球" 1000  keyword_kr.txt
