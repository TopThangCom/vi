java -jar getLatinTag.jar kr kr "카리나" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力分级" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力康锭" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌力康锭副作用" 1000  keyword_kr.txt
