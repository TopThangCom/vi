java -jar getLatinTag.jar fr  fr "Enfin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "haut" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Plus" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "petits" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "porte" 1000  keyword_fr.txt
