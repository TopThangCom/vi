java -jar getLatinTag.jar kr ko "힐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "궁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "극" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "킨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "섭" 1000  keyword_ko.txt
