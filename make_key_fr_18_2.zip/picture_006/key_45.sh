java -jar getLatinTag.jar fr  fr "échéance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "recevoir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tableaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "arriver" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "évident" 1000  keyword_fr.txt
