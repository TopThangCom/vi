java -jar getLatinTag.jar it it "crisi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "organizzativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diamonis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "college" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cottage" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "united" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "toronto" 1000  keyword_it.txt
