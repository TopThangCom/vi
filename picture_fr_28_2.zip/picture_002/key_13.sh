java -jar getLatinTag.jar kr kr "갤럭시" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "증폭기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "핫스팟" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "직접" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "막기" 1000  keyword_kr.txt
