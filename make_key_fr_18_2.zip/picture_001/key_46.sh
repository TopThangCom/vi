java -jar getLatinTag.jar fr  fr "bon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "surtout" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "toutes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nombre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fonds" 1000  keyword_fr.txt
