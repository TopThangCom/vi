java -jar getLatinTag.jar kr ko "際" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "空" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "業" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "務" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "継" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "続" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "計" 1000  keyword_ko.txt
