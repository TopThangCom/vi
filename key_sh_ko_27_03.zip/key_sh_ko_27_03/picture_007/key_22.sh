java -jar getLatinTag.jar kr ko "糊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쯔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "깜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "槳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嘩" 1000  keyword_ko.txt
