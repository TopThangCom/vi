java -jar getLatinTag.jar kr kr "스마일클럽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스마일배송" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채용사이트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "캐나다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조회" 1000  keyword_kr.txt
