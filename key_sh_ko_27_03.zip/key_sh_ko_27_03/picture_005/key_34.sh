java -jar getLatinTag.jar kr ko "霉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "軍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "옹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "숲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "懶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剰" 1000  keyword_ko.txt
