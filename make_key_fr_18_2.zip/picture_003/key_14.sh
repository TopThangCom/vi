java -jar getLatinTag.jar fr  fr "B" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'image" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "études" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Microsoft" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "condition" 1000  keyword_fr.txt
