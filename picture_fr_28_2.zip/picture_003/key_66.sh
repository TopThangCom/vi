java -jar getLatinTag.jar kr kr "価格" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٥×٥+٥÷٥-٥=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٥×٥=٢٥" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٤+٥×٥_٢=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "fkd" 1000  keyword_kr.txt
