java -jar getLatinTag.jar kr kr "외부" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이클립스에서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리스트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자바로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마마무" 1000  keyword_kr.txt
