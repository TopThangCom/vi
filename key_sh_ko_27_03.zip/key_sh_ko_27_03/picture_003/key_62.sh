java -jar getLatinTag.jar kr ko "趣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "踏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "削" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遠" 1000  keyword_ko.txt
