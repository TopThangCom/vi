java -jar getLatinTag.jar fr  fr "vague" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "General" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'immobilier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "légumes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ceux-ci" 1000  keyword_fr.txt
