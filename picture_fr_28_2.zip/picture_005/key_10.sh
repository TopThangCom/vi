java -jar getLatinTag.jar kr kr "메이커" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하는법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피파대리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피파대리업체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피파대리충전" 1000  keyword_kr.txt
