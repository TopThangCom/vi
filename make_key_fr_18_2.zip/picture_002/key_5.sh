java -jar getLatinTag.jar fr  fr "décision" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'avenir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "actionnaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'y" 1000  keyword_fr.txt
