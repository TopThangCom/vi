java -jar getLatinTag.jar fr  fr "peur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "hauteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "centres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voulu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "industrielle" 1000  keyword_fr.txt
