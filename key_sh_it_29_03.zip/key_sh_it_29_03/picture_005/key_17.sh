java -jar getLatinTag.jar it it "compile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autografiada" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "telescopio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "morelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "liderazgo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "negociacion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mercantil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inferencial" 1000  keyword_it.txt
