java -jar getLatinTag.jar kr kr "짭" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정품구별" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "버니" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "급식" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발리스틱" 1000  keyword_kr.txt
