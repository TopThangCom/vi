java -jar getLatinTag.jar kr ko "墓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "덩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "恥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鴻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "骰" 1000  keyword_ko.txt
