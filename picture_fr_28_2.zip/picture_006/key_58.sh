java -jar getLatinTag.jar kr kr "건설사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "등급" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채권" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "건설업계" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "건설업체" 1000  keyword_kr.txt
