java -jar getLatinTag.jar kr kr "안됨" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안뜸" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "없음" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발송취소하면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모바일" 1000  keyword_kr.txt
