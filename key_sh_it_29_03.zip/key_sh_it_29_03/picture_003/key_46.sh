java -jar getLatinTag.jar it it "cientifico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "remedio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pigneto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amaricoccus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cooper" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amarillo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tutorial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "completa" 1000  keyword_it.txt
