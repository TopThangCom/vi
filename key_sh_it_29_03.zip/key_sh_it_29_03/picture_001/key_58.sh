java -jar getLatinTag.jar it it "antiatomice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "civile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "civila" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dispositivos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pantalla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iniciar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sesion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "client" 1000  keyword_it.txt
