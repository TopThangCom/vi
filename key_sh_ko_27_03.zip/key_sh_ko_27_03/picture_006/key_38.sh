java -jar getLatinTag.jar kr ko "펨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "갱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "姜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "叉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "촉" 1000  keyword_ko.txt
