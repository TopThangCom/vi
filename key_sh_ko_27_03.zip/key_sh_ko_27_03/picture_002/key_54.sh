java -jar getLatinTag.jar kr ko "船" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "竹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "純" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "球" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "彦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "硬" 1000  keyword_ko.txt
