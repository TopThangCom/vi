java -jar getLatinTag.jar kr ko "士" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "採" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "営" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "時" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "間" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "閉" 1000  keyword_ko.txt
