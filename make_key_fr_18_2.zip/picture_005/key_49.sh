java -jar getLatinTag.jar fr  fr "pouvez" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "attention" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "a-t-il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "constructeurs" 1000  keyword_fr.txt
