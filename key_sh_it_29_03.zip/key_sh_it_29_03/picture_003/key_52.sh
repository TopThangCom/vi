java -jar getLatinTag.jar it it "sittard" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distribuzione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambrogiani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cote" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pierre" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cutter" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stefano" 1000  keyword_it.txt
