java -jar getLatinTag.jar it it "ampirical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fotografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fotografica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampliaremos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampmetropole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampoagna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampollas" 1000  keyword_it.txt
