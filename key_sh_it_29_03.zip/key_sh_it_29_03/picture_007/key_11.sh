java -jar getLatinTag.jar it it "sebiocap" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carpinando" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capiramobile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capirari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "detto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capirola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infissi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capiroto" 1000  keyword_it.txt
