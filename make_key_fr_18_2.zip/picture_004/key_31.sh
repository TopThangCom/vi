java -jar getLatinTag.jar fr  fr "Suisse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "catégorie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "complexe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "huit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'obligation" 1000  keyword_fr.txt
