java -jar getLatinTag.jar kr ko "薇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "帖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "甫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "但" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旱" 1000  keyword_ko.txt
