java -jar getLatinTag.jar kr kr "敗者復活戦" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "順位" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "配信" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "投票" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "順番" 1000  keyword_kr.txt
