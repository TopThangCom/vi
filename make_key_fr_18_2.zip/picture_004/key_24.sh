java -jar getLatinTag.jar fr  fr "CD" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parts" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comprend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fusion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "acquis" 1000  keyword_fr.txt
