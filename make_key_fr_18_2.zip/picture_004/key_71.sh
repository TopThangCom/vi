java -jar getLatinTag.jar fr  fr "devoir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "souligne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "respectivement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rapports" 1000  keyword_fr.txt
