java -jar getLatinTag.jar fr  fr "conclusion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'usage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "agents" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parfum" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rémunération" 1000  keyword_fr.txt
