java -jar getLatinTag.jar fr  fr "ordre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mobilier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parcours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "perspective" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "normes" 1000  keyword_fr.txt
