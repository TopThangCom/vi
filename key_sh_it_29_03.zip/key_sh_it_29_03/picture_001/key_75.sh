java -jar getLatinTag.jar it it "corrispettivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diretto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "separazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimentare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disfagici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimentari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addentrata" 1000  keyword_it.txt
