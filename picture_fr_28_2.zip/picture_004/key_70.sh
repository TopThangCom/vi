java -jar getLatinTag.jar kr kr "全自動雙研磨美式咖啡機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "飛利浦即熱過濾飲水機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "日立能源" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "池袋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "兜" 1000  keyword_kr.txt
