java -jar getLatinTag.jar kr kr "투자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기업지배구조" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기업지배구조보고서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기업지배구조원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모범규준" 1000  keyword_kr.txt
