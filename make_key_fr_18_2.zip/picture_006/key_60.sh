java -jar getLatinTag.jar fr  fr "traduit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "remettre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "situé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "différente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "longs" 1000  keyword_fr.txt
