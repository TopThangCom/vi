java -jar getLatinTag.jar fr  fr "faisait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "introduit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "intérieur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "outils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "précis" 1000  keyword_fr.txt
