java -jar getLatinTag.jar kr ko "炒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "爐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "獨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "首" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "愛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "染" 1000  keyword_ko.txt
