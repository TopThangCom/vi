java -jar getLatinTag.jar kr ko "廚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "藝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "小" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "家" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "自" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "動" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "翻" 1000  keyword_ko.txt
