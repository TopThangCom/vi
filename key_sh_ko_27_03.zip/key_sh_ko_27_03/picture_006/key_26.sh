java -jar getLatinTag.jar kr ko "왜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "轄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "숭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "즉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "褲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "儂" 1000  keyword_ko.txt
