java -jar getLatinTag.jar fr  fr "habitants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Weekend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bras" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "beaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bruxelloise" 1000  keyword_fr.txt
