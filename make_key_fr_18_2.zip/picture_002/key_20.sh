java -jar getLatinTag.jar fr  fr "parti" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "logiciel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "continue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Notre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bois" 1000  keyword_fr.txt
