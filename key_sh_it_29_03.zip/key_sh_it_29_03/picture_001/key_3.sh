java -jar getLatinTag.jar it it "acomatol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "termine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monofasicas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trifasica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acometimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acometimiento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disciplinari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "improcedent" 1000  keyword_it.txt
