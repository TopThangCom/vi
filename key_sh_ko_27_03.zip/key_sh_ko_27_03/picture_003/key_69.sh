java -jar getLatinTag.jar kr ko "個" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "得" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "済" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怖" 1000  keyword_ko.txt
