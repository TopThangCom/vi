java -jar getLatinTag.jar fr  fr "Web" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cherche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "filiales" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Sous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "signé" 1000  keyword_fr.txt
