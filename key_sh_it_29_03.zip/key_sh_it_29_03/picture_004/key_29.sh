java -jar getLatinTag.jar it it "apostaron" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apostata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apostatando" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apostatar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apostille" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apostrofar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "figura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retorica" 1000  keyword_it.txt
