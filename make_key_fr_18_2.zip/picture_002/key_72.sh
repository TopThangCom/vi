java -jar getLatinTag.jar fr  fr "européens" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Sa" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "éléments" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "unique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'eau" 1000  keyword_fr.txt
