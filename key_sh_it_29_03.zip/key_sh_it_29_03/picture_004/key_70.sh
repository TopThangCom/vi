java -jar getLatinTag.jar it it "tamponi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intensive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualed" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualeddesign" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualeva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualevel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualeven" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualevita" 1000  keyword_it.txt
