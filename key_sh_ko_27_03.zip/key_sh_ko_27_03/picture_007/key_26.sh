java -jar getLatinTag.jar kr ko "낵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꿨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뀌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꼈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "렇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盧" 1000  keyword_ko.txt
