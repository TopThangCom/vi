java -jar getLatinTag.jar kr ko "喪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "邸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瑞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "焚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "츄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "깅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "텍" 1000  keyword_ko.txt
