java -jar getLatinTag.jar fr  fr "date" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avaient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gamme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "revanche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comment" 1000  keyword_fr.txt
