java -jar getLatinTag.jar fr  fr "réduction" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "large" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "traitement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "perdu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "étrangers" 1000  keyword_fr.txt
