java -jar getLatinTag.jar kr kr "業界地図" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "業界動向" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "寄港地" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "寄港地上陆" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "成田" 1000  keyword_kr.txt
