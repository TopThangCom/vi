java -jar getLatinTag.jar kr ko "尾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "況" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "色" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "句" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "列" 1000  keyword_ko.txt
