java -jar getLatinTag.jar kr ko "뫢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "|" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "붤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "%" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "[" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쳬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "F" 1000  keyword_ko.txt
