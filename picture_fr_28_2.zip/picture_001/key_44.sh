java -jar getLatinTag.jar kr kr "그리기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이드카페" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "현실" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "담배" 1000  keyword_kr.txt
