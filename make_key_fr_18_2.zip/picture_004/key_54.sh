java -jar getLatinTag.jar fr  fr "seraient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'autre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "choisir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'instant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tellement" 1000  keyword_fr.txt
