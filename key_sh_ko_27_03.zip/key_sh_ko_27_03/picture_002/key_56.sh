java -jar getLatinTag.jar kr ko "吹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "偏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "値" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "育" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "団" 1000  keyword_ko.txt
