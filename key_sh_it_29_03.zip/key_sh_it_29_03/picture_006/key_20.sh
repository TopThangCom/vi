java -jar getLatinTag.jar it it "brasilicardin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capivari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brasilotitan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brasiltecnet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tecpar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "processamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "termico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "eletronico" 1000  keyword_it.txt
