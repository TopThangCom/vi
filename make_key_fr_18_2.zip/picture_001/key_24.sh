java -jar getLatinTag.jar fr  fr "s'agit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jamais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "production" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "action" 1000  keyword_fr.txt
