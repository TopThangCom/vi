java -jar getLatinTag.jar kr kr "申请" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "寄港地上陸" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "通過上陸" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "寄港地上陸許可" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "コロナ" 1000  keyword_kr.txt
