java -jar getLatinTag.jar fr  fr "rejoint" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "spécialisé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'amour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'exportation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "objet" 1000  keyword_fr.txt
