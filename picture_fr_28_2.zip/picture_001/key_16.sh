java -jar getLatinTag.jar kr kr "곤충" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "오버워치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메인힐러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메인탱커" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서브탱커" 1000  keyword_kr.txt
