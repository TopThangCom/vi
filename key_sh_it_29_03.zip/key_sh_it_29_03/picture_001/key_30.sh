java -jar getLatinTag.jar it it "acquarello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquaroli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquaroni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquaseal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coconut" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fermignano" 1000  keyword_it.txt
