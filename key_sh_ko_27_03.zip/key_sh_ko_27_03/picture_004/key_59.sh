java -jar getLatinTag.jar kr ko "貓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "涼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "十" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稲" 1000  keyword_ko.txt
