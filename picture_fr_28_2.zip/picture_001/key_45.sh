java -jar getLatinTag.jar kr kr "다운" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사탕" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해석" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "논란" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바둑" 1000  keyword_kr.txt
