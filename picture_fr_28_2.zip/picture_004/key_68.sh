java -jar getLatinTag.jar kr kr "신입" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "로봇사업센터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전자레인지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "소리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고장" 1000  keyword_kr.txt
