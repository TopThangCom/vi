java -jar getLatinTag.jar kr ko "側" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "朋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鄧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聲" 1000  keyword_ko.txt
