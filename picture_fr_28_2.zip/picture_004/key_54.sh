java -jar getLatinTag.jar kr kr "맥" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "io" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ios" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "항아리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "bgm" 1000  keyword_kr.txt
