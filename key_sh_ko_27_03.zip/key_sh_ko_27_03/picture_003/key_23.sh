java -jar getLatinTag.jar kr ko "輪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "춤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "版" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "倒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "庫" 1000  keyword_ko.txt
