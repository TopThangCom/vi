java -jar getLatinTag.jar it it "icp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aplicativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cpi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "divino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compiegne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "almond" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diffusion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discorso" 1000  keyword_it.txt
