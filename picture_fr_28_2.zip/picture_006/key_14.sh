java -jar getLatinTag.jar kr kr "안되면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "되게하라" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안되며" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마이크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "KG이니시스" 1000  keyword_kr.txt
