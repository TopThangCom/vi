java -jar getLatinTag.jar fr  fr "cité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "concours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "patrons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "populaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pétrole" 1000  keyword_fr.txt
