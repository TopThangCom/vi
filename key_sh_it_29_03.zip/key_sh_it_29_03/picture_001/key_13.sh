java -jar getLatinTag.jar it it "abritat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ranch" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "consultancy" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrocitinib" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contrario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "significa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrogate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrogation" 1000  keyword_it.txt
