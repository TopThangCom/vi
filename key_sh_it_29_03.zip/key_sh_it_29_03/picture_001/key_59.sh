java -jar getLatinTag.jar it it "fruto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comercial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catanduva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diode" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sinonimo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "escoltas" 1000  keyword_it.txt
