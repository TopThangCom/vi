java -jar getLatinTag.jar kr ko "옮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "튜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "옵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "툴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "늄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앙" 1000  keyword_ko.txt
