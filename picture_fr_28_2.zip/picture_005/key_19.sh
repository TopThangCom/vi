java -jar getLatinTag.jar kr kr "동해" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "차트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전기차" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "충전기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "충전" 1000  keyword_kr.txt
