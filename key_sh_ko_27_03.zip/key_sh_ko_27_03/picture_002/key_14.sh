java -jar getLatinTag.jar kr ko "朗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "逢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "락" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "턴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "봇" 1000  keyword_ko.txt
