java -jar getLatinTag.jar it it "adipositas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "privilege" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "golf" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avignon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adispot" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distancia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "icpr" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chile" 1000  keyword_it.txt
