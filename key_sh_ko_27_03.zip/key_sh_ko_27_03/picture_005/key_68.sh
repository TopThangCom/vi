java -jar getLatinTag.jar kr ko "紛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "첨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "또" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撞" 1000  keyword_ko.txt
