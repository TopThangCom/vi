java -jar getLatinTag.jar it it "prostatica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prostata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aperto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collaterali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "transvescicale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "transvesical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mediastinales" 1000  keyword_it.txt
