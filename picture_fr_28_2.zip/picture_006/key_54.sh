java -jar getLatinTag.jar kr kr "국민대" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인스타스타" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우석" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "저격" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이별" 1000  keyword_kr.txt
