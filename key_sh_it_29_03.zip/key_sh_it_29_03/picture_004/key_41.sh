java -jar getLatinTag.jar it it "definiciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inchiriat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "renta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ponent" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lloret" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "relatos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diplomaticos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apascali" 1000  keyword_it.txt
