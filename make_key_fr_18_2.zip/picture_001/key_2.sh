java -jar getLatinTag.jar fr  fr "Une" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prix" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "On" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dont" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lui" 1000  keyword_fr.txt
