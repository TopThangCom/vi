java -jar getLatinTag.jar kr ko "킬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "표" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "티" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "가" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "격" 1000  keyword_ko.txt
