java -jar getLatinTag.jar kr ko "랫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "강" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "중" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "익" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챌" 1000  keyword_ko.txt
