java -jar getLatinTag.jar fr  fr "novembre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'évolution" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pourra" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "semaines" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "consommation" 1000  keyword_fr.txt
