java -jar getLatinTag.jar fr  fr "voyages" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "procéder" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "locale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "médecins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "privés" 1000  keyword_fr.txt
