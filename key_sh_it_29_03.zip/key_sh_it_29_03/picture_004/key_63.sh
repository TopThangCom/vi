java -jar getLatinTag.jar it it "vacation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcanena" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prenotazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquanolite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquanology" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nordic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carolina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecolab" 1000  keyword_it.txt
