java -jar getLatinTag.jar it it "calella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ciutadella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bivariate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "correlatie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trizonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bizzotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "croche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "logistica" 1000  keyword_it.txt
