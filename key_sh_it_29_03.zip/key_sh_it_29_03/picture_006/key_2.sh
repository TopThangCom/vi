java -jar getLatinTag.jar it it "magistrates" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antenna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lanche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "polietileno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brocaller" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "villacarrillo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costituzione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cpp" 1000  keyword_it.txt
