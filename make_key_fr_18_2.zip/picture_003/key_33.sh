java -jar getLatinTag.jar fr  fr "nationale" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "regard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "représentent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Belges" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "état" 1000  keyword_fr.txt
