java -jar getLatinTag.jar kr kr "상업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "유튜브" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "wget" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "옵션" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "elf" 1000  keyword_kr.txt
