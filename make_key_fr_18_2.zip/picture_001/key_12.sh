java -jar getLatinTag.jar fr  fr "produit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'année" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Par" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mieux" 1000  keyword_fr.txt
