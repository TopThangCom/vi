java -jar getLatinTag.jar it it "colorir" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pronunciation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "app" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alternative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "definition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abidesigner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "store" 1000  keyword_it.txt
