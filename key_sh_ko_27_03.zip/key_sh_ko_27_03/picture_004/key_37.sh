java -jar getLatinTag.jar kr ko "鐵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鋅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "織" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "範" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "匯" 1000  keyword_ko.txt
