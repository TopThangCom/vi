java -jar getLatinTag.jar kr ko "눌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "崁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "祖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "컷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "樟" 1000  keyword_ko.txt
