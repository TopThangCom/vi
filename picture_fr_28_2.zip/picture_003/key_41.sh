java -jar getLatinTag.jar kr kr "났다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "끈끈이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실험용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스펠링" 1000  keyword_kr.txt
