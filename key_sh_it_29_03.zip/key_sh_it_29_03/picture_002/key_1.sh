java -jar getLatinTag.jar it it "ecologico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infedele" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nemica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "universo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "score" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camini" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "religion" 1000  keyword_it.txt
