java -jar getLatinTag.jar fr  fr "propriété" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "stratégique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Renault" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "porté" 1000  keyword_fr.txt
