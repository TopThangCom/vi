java -jar getLatinTag.jar it it "caspieonline" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caspiol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "notaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "notario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "periodista" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gucci" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassable" 1000  keyword_it.txt
