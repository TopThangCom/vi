java -jar getLatinTag.jar fr  fr "présence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "européennes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devraient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "groupes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ensemble" 1000  keyword_fr.txt
