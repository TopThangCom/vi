java -jar getLatinTag.jar it it "arizona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carnotauro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sorriso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "liberato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "division" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "registration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "import" 1000  keyword_it.txt
