java -jar getLatinTag.jar kr ko "秘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "露" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "溝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "域" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "質" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鉱" 1000  keyword_ko.txt
