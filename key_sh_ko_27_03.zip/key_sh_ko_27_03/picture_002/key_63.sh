java -jar getLatinTag.jar kr ko "標" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "入" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "參" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "指" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "듀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넣" 1000  keyword_ko.txt
