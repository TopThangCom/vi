java -jar getLatinTag.jar kr kr "coral" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "全新特仕机种" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "后视镜型行车记录器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "토양오염" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카카오톡" 1000  keyword_kr.txt
