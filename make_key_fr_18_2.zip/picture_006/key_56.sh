java -jar getLatinTag.jar fr  fr "sources" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Kong" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "destinée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "N" 1000  keyword_fr.txt
