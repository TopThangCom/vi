java -jar getLatinTag.jar kr kr "複数形" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "붙이기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무설치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자르기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "음악" 1000  keyword_kr.txt
