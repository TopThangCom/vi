java -jar getLatinTag.jar kr ko "삐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "錯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "湊" 1000  keyword_ko.txt
