java -jar getLatinTag.jar fr  fr "payé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rendu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'ils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "software" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "utile" 1000  keyword_fr.txt
