java -jar getLatinTag.jar it it "accesso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concettuale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rovelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anfibios" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italianos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accompagnement" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "provencale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recette" 1000  keyword_it.txt
