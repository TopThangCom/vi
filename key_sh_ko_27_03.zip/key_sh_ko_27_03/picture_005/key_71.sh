java -jar getLatinTag.jar kr ko "疾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蜥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蠣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "굴" 1000  keyword_ko.txt
