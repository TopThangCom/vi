java -jar getLatinTag.jar kr ko "雑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "猛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "筑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "領" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "械" 1000  keyword_ko.txt
