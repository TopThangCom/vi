java -jar getLatinTag.jar fr  fr "exportations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "négociations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Jan" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "répond" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "BEL" 1000  keyword_fr.txt
