java -jar getLatinTag.jar fr  fr "KB" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'offre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "active" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dépenses" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "donnent" 1000  keyword_fr.txt
