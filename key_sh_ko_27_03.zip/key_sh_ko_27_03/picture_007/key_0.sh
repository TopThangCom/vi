java -jar getLatinTag.jar kr ko "叩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "詠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "켜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "銷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盼" 1000  keyword_ko.txt
