java -jar getLatinTag.jar it it "elatior" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "migliore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fili" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inspiracional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "meconio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspirantenstelle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "professionale" 1000  keyword_it.txt
