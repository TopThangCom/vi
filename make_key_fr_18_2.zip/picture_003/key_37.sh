java -jar getLatinTag.jar fr  fr "perdre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cuisine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "telles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D'autres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "travaille" 1000  keyword_fr.txt
