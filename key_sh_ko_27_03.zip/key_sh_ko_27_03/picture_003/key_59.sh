java -jar getLatinTag.jar kr ko "対" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "効" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "准" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "爪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "廃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棄" 1000  keyword_ko.txt
