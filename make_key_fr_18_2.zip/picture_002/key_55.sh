java -jar getLatinTag.jar fr  fr "américain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ventes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Selon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "livre" 1000  keyword_fr.txt
