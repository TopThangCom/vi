java -jar getLatinTag.jar kr ko "常" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "詩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蓓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "謂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "險" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "創" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "厳" 1000  keyword_ko.txt
