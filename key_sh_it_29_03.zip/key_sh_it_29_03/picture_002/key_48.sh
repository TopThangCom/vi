java -jar getLatinTag.jar it it "fatigue" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adrenalin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adrenaline" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "moment" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "siuntos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "relativ" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adresimiz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "registar" 1000  keyword_it.txt
