java -jar getLatinTag.jar kr ko "쩑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쯀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꽥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "눮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폹" 1000  keyword_ko.txt
