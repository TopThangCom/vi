java -jar getLatinTag.jar kr kr "학습" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "프레임워크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "점유율" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카페" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "高階救命器具" 1000  keyword_kr.txt
