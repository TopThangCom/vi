java -jar getLatinTag.jar kr kr "우분투에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "설치하기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "설치파일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "경로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "UPS" 1000  keyword_kr.txt
