java -jar getLatinTag.jar kr ko "압" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "費" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "再" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "괄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "랑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뷔" 1000  keyword_ko.txt
