java -jar getLatinTag.jar kr kr "데이터를" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "찾을" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "없습니다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "竹田" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "恒泰" 1000  keyword_kr.txt
