java -jar getLatinTag.jar it it "aqualivelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualiving" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medicamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualliance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualonis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "reservio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualuminator" 1000  keyword_it.txt
