java -jar getLatinTag.jar it it "tropical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquarion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iniciante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sucesso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "desenzano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riantec" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquaroline" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquaroll" 1000  keyword_it.txt
