java -jar getLatinTag.jar fr  fr "tente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "financer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "scientifique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Georges" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "travaillent" 1000  keyword_fr.txt
