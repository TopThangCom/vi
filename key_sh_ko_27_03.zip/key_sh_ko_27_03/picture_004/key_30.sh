java -jar getLatinTag.jar kr ko "惹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "佳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "眉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蔽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "忙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "描" 1000  keyword_ko.txt
