java -jar getLatinTag.jar it it "suprimentos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fagiano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brandiators" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brandicolor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iconic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brandincolor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "innovation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brandito" 1000  keyword_it.txt
