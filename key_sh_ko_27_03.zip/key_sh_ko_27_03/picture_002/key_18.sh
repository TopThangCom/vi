java -jar getLatinTag.jar kr ko "無" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "把" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "價" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "林" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "性" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "要" 1000  keyword_ko.txt
