java -jar getLatinTag.jar it it "intransitivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ceglie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vicoletto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cisternino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "controle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "decoration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artdecorationfr" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artdecoration" 1000  keyword_it.txt
