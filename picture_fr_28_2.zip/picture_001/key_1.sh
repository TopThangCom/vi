java -jar getLatinTag.jar kr kr "깨짐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "양식" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "추가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "html" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사이즈" 1000  keyword_kr.txt
