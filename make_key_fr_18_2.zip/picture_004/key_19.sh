java -jar getLatinTag.jar fr  fr "investi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mission" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "profiter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "visite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comprendre" 1000  keyword_fr.txt
