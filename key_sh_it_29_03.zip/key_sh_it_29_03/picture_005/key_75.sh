java -jar getLatinTag.jar it it "assuntori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assuntoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "momento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conversar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assunzione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assunzioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "habitation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "decelles" 1000  keyword_it.txt
