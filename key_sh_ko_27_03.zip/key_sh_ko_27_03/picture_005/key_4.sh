java -jar getLatinTag.jar kr ko "빔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "忍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蝦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巷" 1000  keyword_ko.txt
