java -jar getLatinTag.jar it it "richmond" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brandolabb" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "egidio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accordions" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "radiatori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brandonisio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bottiglie" 1000  keyword_it.txt
