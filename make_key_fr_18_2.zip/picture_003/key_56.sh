java -jar getLatinTag.jar fr  fr "attendre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lignes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "consiste" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "augmenté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vert" 1000  keyword_fr.txt
