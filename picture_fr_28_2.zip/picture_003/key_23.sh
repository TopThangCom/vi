java -jar getLatinTag.jar kr kr "투넘버" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "sct" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "목적" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아동용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "보고서" 1000  keyword_kr.txt
