java -jar getLatinTag.jar fr  fr "change" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "changement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "garantie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "somme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Belge" 1000  keyword_fr.txt
