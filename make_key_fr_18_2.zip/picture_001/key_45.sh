java -jar getLatinTag.jar fr  fr "important" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parfois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nom" 1000  keyword_fr.txt
