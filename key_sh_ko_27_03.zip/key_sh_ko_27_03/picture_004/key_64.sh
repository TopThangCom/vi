java -jar getLatinTag.jar kr ko "姪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "藤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "秀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "堰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "虹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鷹" 1000  keyword_ko.txt
