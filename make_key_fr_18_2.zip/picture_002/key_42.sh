java -jar getLatinTag.jar fr  fr "politiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "malgré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "confiance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "homme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'actions" 1000  keyword_fr.txt
