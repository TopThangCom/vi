java -jar getLatinTag.jar kr kr "프로토콜을" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사용합니다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "田中金属製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "山形" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "甲府" 1000  keyword_kr.txt
