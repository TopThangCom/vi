java -jar getLatinTag.jar kr ko "흑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "夢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "炮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "苦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "覆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勢" 1000  keyword_ko.txt
