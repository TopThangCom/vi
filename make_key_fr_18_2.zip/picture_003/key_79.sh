java -jar getLatinTag.jar fr  fr "rend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "applications" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'ici" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "procédure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'opération" 1000  keyword_fr.txt
