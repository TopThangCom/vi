java -jar getLatinTag.jar kr kr "이재명" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피리춤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "動物用超音波画像診断装置" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "真空無線控溫電熱水壺" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新版" 1000  keyword_kr.txt
