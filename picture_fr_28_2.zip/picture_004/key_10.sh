java -jar getLatinTag.jar kr kr "예매" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "치어리더" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "내분" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "싸움" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "김하나" 1000  keyword_kr.txt
