java -jar getLatinTag.jar it it "pubblico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italiani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sedimentares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cling" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mercat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "maschile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cropped" 1000  keyword_it.txt
