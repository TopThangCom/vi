java -jar getLatinTag.jar kr kr "딥드림" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "플래티넘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뽐뿌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비교" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "상테크" 1000  keyword_kr.txt
