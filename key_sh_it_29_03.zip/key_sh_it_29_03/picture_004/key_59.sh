java -jar getLatinTag.jar it it "pizzaofen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ardot" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uniasselvi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colanta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colombiano" 1000  keyword_it.txt
