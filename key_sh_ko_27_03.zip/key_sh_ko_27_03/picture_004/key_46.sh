java -jar getLatinTag.jar kr ko "免" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "君" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "關" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抽" 1000  keyword_ko.txt
