java -jar getLatinTag.jar it it "racc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "substantivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assegurativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asseguratte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "persone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "improvviso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "organizzato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tedesco" 1000  keyword_it.txt
