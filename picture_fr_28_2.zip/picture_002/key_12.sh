java -jar getLatinTag.jar kr kr "카카오페이지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "원피스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카쿠" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "草原之夜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "草原之夜歌词" 1000  keyword_kr.txt
