java -jar getLatinTag.jar it it "acesso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "serpro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acessosisi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonae" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sicredi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aeroporto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "illa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "illallah" 1000  keyword_it.txt
