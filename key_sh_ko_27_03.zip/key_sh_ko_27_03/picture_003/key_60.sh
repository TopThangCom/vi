java -jar getLatinTag.jar kr ko "唾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "毒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "荷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "凸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "課" 1000  keyword_ko.txt
