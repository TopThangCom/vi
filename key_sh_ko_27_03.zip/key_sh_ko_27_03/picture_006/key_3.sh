java -jar getLatinTag.jar kr ko "듬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "馥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "獎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "軌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "莊" 1000  keyword_ko.txt
