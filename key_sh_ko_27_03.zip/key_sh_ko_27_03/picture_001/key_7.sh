java -jar getLatinTag.jar kr ko "영" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "림" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "책" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "복" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "충" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "워" 1000  keyword_ko.txt
