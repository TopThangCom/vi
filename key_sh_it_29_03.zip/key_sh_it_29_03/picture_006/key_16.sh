java -jar getLatinTag.jar it it "nei" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pediatrico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncostat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ravintola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brondata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chioggia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bronsiolita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "simptome" 1000  keyword_it.txt
