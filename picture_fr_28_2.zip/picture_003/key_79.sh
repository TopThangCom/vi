java -jar getLatinTag.jar kr kr "공유드라이브로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "옮기기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "디자인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "디자이너" 1000  keyword_kr.txt
