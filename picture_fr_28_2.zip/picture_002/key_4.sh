java -jar getLatinTag.jar kr kr "파일만" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지원됩니다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ntscorp.ru에서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지원되지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "않는" 1000  keyword_kr.txt
