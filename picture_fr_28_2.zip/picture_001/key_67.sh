java -jar getLatinTag.jar kr kr "예약발송" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "취소" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "앱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "알림" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안옴" 1000  keyword_kr.txt
