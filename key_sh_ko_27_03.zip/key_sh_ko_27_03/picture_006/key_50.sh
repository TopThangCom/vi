java -jar getLatinTag.jar kr ko "卸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "罹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "捕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蘇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "컵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빗" 1000  keyword_ko.txt
