java -jar getLatinTag.jar kr kr "고즈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "목격담" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "옷" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "계급" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "드라마" 1000  keyword_kr.txt
