java -jar getLatinTag.jar kr ko "醉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "黏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쎈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "捨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "悔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "媛" 1000  keyword_ko.txt
