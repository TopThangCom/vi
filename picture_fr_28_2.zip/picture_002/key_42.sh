java -jar getLatinTag.jar kr kr "٥×٥=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "旺德" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ro" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "新世代的诞生" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "雪花飘飘" 1000  keyword_kr.txt
