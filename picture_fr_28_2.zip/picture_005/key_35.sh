java -jar getLatinTag.jar kr kr "입모양" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고치는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ja岩井" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "組合長" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "岩井東支店" 1000  keyword_kr.txt
