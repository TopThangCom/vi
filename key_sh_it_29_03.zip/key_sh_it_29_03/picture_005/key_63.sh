java -jar getLatinTag.jar it it "scolastico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imposta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assolvono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "funzione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "relato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assorbenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascellari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotone" 1000  keyword_it.txt
