java -jar getLatinTag.jar fr  fr "Ainsi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ni" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "type" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Europe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pendant" 1000  keyword_fr.txt
