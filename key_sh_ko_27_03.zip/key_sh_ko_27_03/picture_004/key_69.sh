java -jar getLatinTag.jar kr ko "쥃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "솺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뚢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뺱" 1000  keyword_ko.txt
