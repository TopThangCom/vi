java -jar getLatinTag.jar kr ko "社" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "委" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "晃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "羅" 1000  keyword_ko.txt
