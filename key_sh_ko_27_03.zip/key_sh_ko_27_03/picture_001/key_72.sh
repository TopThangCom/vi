java -jar getLatinTag.jar kr ko "쿠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "폰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "띠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "부" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "씰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "직" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "업" 1000  keyword_ko.txt
