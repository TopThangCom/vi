java -jar getLatinTag.jar fr  fr "royal" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "technologique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "télécommunications" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Amsterdam" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fiscales" 1000  keyword_fr.txt
