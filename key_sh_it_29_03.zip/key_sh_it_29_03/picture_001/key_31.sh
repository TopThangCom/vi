java -jar getLatinTag.jar it it "canone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "locazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appalti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pubblici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coniugazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adeguata" 1000  keyword_it.txt
