java -jar getLatinTag.jar it it "ricardo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montaner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "religiosamente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "congolais" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "continu" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartagena" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sacramento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rivolta" 1000  keyword_it.txt
