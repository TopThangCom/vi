java -jar getLatinTag.jar kr ko "帽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "秋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "農" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "協" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "駅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "符" 1000  keyword_ko.txt
