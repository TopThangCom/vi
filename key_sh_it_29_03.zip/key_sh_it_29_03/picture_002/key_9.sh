java -jar getLatinTag.jar it it "aioria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unicom" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chrono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abitanti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cheville" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecofan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "superficiales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "airecito" 1000  keyword_it.txt
