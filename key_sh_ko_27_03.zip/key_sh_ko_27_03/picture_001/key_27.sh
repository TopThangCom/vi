java -jar getLatinTag.jar kr ko "능" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "젠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "픽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "텔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "품" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멀" 1000  keyword_ko.txt
