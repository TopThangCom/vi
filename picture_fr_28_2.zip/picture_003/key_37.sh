java -jar getLatinTag.jar kr kr "커터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "컨버터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비디오" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "式根岛" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "宿" 1000  keyword_kr.txt
