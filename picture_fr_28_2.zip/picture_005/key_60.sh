java -jar getLatinTag.jar kr kr "사이버결제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "adb" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기본앱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선탑재" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레노버" 1000  keyword_kr.txt
