java -jar getLatinTag.jar kr ko "決" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "병" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "택" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "울" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "皮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "롤" 1000  keyword_ko.txt
