java -jar getLatinTag.jar kr kr "草原之夜伴奏" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "草原之夜降央卓玛" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리복" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cap" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "道路交通(車輛構造及保養)規例" 1000  keyword_kr.txt
