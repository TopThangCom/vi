java -jar getLatinTag.jar fr  fr "faire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "elle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "c'est" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "peu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vous" 1000  keyword_fr.txt
