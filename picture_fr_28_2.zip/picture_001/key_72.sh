java -jar getLatinTag.jar kr kr "직업표" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카루마" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바보" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "만화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "생일" 1000  keyword_kr.txt
