java -jar getLatinTag.jar kr ko "熬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "狂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "婿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "訊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곳" 1000  keyword_ko.txt
