java -jar getLatinTag.jar kr kr "할로겐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수명" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "와트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "소켓" 1000  keyword_kr.txt
