java -jar getLatinTag.jar fr  fr "leurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "taux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "années" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "temps" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "groupe" 1000  keyword_fr.txt
