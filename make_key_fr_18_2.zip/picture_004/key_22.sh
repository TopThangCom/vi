java -jar getLatinTag.jar fr  fr "Premier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ancien" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "note" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parties" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pension" 1000  keyword_fr.txt
