java -jar getLatinTag.jar kr kr "삼성카드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "삼성전자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공시" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "의무화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "작성" 1000  keyword_kr.txt
