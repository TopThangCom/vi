java -jar getLatinTag.jar it it "spigno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "poltronesofa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ufficio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vaccino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cava" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "filomena" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prosecco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "codi" 1000  keyword_it.txt
