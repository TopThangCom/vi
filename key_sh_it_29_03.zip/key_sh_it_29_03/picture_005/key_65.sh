java -jar getLatinTag.jar it it "ascomiceto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "codeine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "called" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fermentation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asconauto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asconpepi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cooperar" 1000  keyword_it.txt
