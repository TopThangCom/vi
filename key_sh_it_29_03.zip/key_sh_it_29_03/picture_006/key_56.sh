java -jar getLatinTag.jar it it "cotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caesarsalaatti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conilon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nespresso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cagospiscio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fabbro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caguassierrasur" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caiabisonline" 1000  keyword_it.txt
