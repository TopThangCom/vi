java -jar getLatinTag.jar kr kr "쿠폰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가격" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "띠부씰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이벤트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "직업" 1000  keyword_kr.txt
