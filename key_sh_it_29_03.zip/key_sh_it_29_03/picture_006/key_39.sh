java -jar getLatinTag.jar it it "brancaleoni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brancalion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brancalonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gonone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gradazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "centrale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brancato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brancatos" 1000  keyword_it.txt
