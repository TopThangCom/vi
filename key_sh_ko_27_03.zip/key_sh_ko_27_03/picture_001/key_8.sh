java -jar getLatinTag.jar kr ko "×" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "메" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "수" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "신" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "확" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "인" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "만" 1000  keyword_ko.txt
