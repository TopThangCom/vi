java -jar getLatinTag.jar it it "neto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adriatica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adriazola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carballo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "omori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adrich" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adrion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adrionne" 1000  keyword_it.txt
