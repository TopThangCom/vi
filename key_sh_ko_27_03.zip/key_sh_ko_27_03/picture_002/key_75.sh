java -jar getLatinTag.jar kr ko "納" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "米" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "水" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "膠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蛋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "風" 1000  keyword_ko.txt
