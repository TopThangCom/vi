java -jar getLatinTag.jar it it "nivelles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legionella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "climatic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquaclimbing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nivillac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cocoon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquacolors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquacontroller" 1000  keyword_it.txt
