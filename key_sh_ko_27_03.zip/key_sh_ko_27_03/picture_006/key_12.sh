java -jar getLatinTag.jar kr ko "붐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "濁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "皈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "膳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "哭" 1000  keyword_ko.txt
