java -jar getLatinTag.jar it it "abralimp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "operation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ritual" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atendimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rufino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corazon" 1000  keyword_it.txt
