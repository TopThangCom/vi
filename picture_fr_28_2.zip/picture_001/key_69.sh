java -jar getLatinTag.jar kr kr "싱크로율" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "작곡" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "보헤미안" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "랩소디" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cj" 1000  keyword_kr.txt
