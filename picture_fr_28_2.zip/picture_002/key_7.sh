java -jar getLatinTag.jar kr kr "投票数" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "優勝" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "决胜进出者発表" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "出場者" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "準々決勝" 1000  keyword_kr.txt
