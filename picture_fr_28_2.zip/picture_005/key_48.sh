java -jar getLatinTag.jar kr kr "빌딩" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아쿠아리움" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레스토랑" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전망대" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뷔페" 1000  keyword_kr.txt
