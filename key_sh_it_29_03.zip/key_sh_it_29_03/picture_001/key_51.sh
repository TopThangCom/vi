java -jar getLatinTag.jar it it "spezia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "viareggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "palazzolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "succivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "filati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquadrop" 1000  keyword_it.txt
