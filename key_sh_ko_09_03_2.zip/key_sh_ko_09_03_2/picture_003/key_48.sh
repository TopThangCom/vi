java -jar getLatinTag.jar kr ko "탟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "ש" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko """ 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쥃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "찣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "I" 1000  keyword_ko.txt
