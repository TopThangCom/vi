java -jar getLatinTag.jar kr ko "펠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "름" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "두" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "처" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꿈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "끼" 1000  keyword_ko.txt
