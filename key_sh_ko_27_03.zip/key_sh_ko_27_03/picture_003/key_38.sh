java -jar getLatinTag.jar kr ko "次" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "引" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "擎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "運" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "碟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蒼" 1000  keyword_ko.txt
