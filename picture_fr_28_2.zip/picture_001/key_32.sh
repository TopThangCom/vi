java -jar getLatinTag.jar kr kr "동향" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우리나라" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "경쟁력" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "분석" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전망" 1000  keyword_kr.txt
