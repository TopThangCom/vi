java -jar getLatinTag.jar kr kr "動画" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "放送" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "感想" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "観覧" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "倍率" 1000  keyword_kr.txt
