java -jar getLatinTag.jar it it "comotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocompletar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aprendiz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collettivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collettivi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ppi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autodemolitori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autodemolizione" 1000  keyword_it.txt
