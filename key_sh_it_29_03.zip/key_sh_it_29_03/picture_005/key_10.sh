java -jar getLatinTag.jar it it "etica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cortina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fast" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intelbras" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartago" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "automocion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcala" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aragonesa" 1000  keyword_it.txt
