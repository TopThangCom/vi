java -jar getLatinTag.jar it it "sviluppo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oncologo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "frito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "baranello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camascol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camascoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piceno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camascopio" 1000  keyword_it.txt
