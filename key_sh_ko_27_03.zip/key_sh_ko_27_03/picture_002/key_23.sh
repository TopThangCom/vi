java -jar getLatinTag.jar kr ko "園" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "飯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "魁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "設" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "資" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "安" 1000  keyword_ko.txt
