java -jar getLatinTag.jar kr kr "열관류율" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "화장실" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "단열성능" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마감" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "소프트웨어사업" 1000  keyword_kr.txt
