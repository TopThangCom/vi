java -jar getLatinTag.jar kr ko "邁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蟠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鉚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "砸" 1000  keyword_ko.txt
