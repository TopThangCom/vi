java -jar getLatinTag.jar kr ko "煌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "띵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "營" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鬥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寒" 1000  keyword_ko.txt
