java -jar getLatinTag.jar it it "diferida" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imediata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clima" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bibliotecario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inscrito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "respiratory" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fass" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bonitos" 1000  keyword_it.txt
