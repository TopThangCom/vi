java -jar getLatinTag.jar it it "renovations" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monitor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "eco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "socorro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrianna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrianne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "botellas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clicar" 1000  keyword_it.txt
