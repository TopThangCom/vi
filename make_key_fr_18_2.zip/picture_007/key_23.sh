java -jar getLatinTag.jar fr  fr "suivent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Jusqu'au" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "classement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'exemple" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "norme" 1000  keyword_fr.txt
