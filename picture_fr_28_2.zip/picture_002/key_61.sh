java -jar getLatinTag.jar kr kr "可搬式液体窒素容器" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "TCD" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "tcd" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "후" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "간호" 1000  keyword_kr.txt
