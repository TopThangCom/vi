java -jar getLatinTag.jar it it "moschatellina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pipe" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adpolice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "digitarq" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adposition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ponta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "afeccion" 1000  keyword_it.txt
