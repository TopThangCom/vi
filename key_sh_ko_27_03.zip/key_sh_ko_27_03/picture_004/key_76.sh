java -jar getLatinTag.jar kr ko "乎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蝶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "魂" 1000  keyword_ko.txt
