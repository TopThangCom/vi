java -jar getLatinTag.jar fr  fr "Alain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vigueur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gagner" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Celui-ci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Philips" 1000  keyword_fr.txt
