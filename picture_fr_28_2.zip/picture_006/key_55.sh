java -jar getLatinTag.jar kr kr "遺伝子検査" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "診断" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "韓国人" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안두인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "린" 1000  keyword_kr.txt
