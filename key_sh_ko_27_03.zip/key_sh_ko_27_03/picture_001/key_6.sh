java -jar getLatinTag.jar kr ko "玉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "俊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "極" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "優" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "展" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "示" 1000  keyword_ko.txt
