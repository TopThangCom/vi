java -jar getLatinTag.jar kr ko "啦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "娟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蕉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "惠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "脅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拆" 1000  keyword_ko.txt
