java -jar getLatinTag.jar fr  fr "publicité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "train" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "coupon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "progression" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tenir" 1000  keyword_fr.txt
