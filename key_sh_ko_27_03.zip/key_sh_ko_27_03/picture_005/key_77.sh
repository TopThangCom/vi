java -jar getLatinTag.jar kr ko "墅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "慌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "丘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "텝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鳴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "랭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "償" 1000  keyword_ko.txt
