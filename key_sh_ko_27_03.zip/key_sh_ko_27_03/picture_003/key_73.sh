java -jar getLatinTag.jar kr ko "距" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "覚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "難" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "恵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "損" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "海" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麗" 1000  keyword_ko.txt
