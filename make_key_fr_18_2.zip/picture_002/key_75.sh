java -jar getLatinTag.jar fr  fr "technique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Aujourd'hui" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ailleurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "P" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'ensemble" 1000  keyword_fr.txt
