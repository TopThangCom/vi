java -jar getLatinTag.jar it it "mandello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "maggiore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquafertic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquafina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avoca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sportiom" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquagolfe" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "livigno" 1000  keyword_it.txt
