java -jar getLatinTag.jar kr kr "여러줄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발동" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사이드카" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기준" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "종목" 1000  keyword_kr.txt
