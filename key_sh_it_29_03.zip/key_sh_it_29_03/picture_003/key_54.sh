java -jar getLatinTag.jar it it "funziona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fanelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "beccaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intermodal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lorenzetti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "glue" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carminati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compagnon" 1000  keyword_it.txt
