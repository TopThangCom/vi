java -jar getLatinTag.jar it it "antiabrasion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antiabrasione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antiabrasivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tramontina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retrattile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pantene" 1000  keyword_it.txt
