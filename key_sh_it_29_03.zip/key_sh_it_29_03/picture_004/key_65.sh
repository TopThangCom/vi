java -jar getLatinTag.jar it it "morto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "municipal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caroline" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "irratia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arramont" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arrampicata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sportiva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conduta" 1000  keyword_it.txt
