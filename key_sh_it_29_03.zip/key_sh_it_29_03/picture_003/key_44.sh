java -jar getLatinTag.jar it it "torremolinos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antrasit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antrasitt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trattoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "religioso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antropomorfologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "polanco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antrostomia" 1000  keyword_it.txt
