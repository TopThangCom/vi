java -jar getLatinTag.jar fr  fr "octobre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vraiment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sein" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Or" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dollar" 1000  keyword_fr.txt
