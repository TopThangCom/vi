java -jar getLatinTag.jar kr kr "마크" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "y" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "좌표" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바이옴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "크리티컬" 1000  keyword_kr.txt
