java -jar getLatinTag.jar kr kr "체크카드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미니언즈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "후불교통" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "신한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "교통카드" 1000  keyword_kr.txt
