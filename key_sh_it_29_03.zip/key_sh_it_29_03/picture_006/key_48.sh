java -jar getLatinTag.jar it it "unicorn" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "remittance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bratato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bratosin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bratronice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fatturato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brescello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camillo" 1000  keyword_it.txt
