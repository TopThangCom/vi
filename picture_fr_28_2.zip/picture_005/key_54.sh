java -jar getLatinTag.jar kr kr "복지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "켄우드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "imei" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "알려줘도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "되나요" 1000  keyword_kr.txt
