java -jar getLatinTag.jar kr ko "첫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "笠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "솔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "떼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "몬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "商" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "周" 1000  keyword_ko.txt
