java -jar getLatinTag.jar kr ko "欣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蟑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "螂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "諾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汾" 1000  keyword_ko.txt
