java -jar getLatinTag.jar it it "eccellenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "attorney" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cadecolegio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardiologo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cadegliano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "viconago" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alifatica" 1000  keyword_it.txt
