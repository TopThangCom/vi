java -jar getLatinTag.jar fr  fr "passage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "of" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "justice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "page" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tels" 1000  keyword_fr.txt
