java -jar getLatinTag.jar fr  fr "certaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "formule" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jusqu'au" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "programmes" 1000  keyword_fr.txt
