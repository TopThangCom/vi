java -jar getLatinTag.jar it it "brostella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brotaneset" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brotato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brtato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rintraccia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spedizione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brtonigla" 1000  keyword_it.txt
