java -jar getLatinTag.jar kr ko "킴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "껄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "騰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "顎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "孕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禮" 1000  keyword_ko.txt
