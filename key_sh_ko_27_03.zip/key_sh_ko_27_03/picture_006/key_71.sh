java -jar getLatinTag.jar kr ko "塵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "您" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "跌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "窩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蔡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鐘" 1000  keyword_ko.txt
