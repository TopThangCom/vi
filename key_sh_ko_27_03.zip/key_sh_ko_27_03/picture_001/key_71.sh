java -jar getLatinTag.jar kr ko "說" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "山" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "央" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "支" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "扱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "説" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "書" 1000  keyword_ko.txt
