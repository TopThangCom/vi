java -jar getLatinTag.jar it it "artificiais" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ordizia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arranomendi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carnaval" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "soltar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "induzido" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infierno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copreterito" 1000  keyword_it.txt
