java -jar getLatinTag.jar it it "anzimine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sofiane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avocat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nedellec" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nignol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pronounciation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cuellar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "eca" 1000  keyword_it.txt
