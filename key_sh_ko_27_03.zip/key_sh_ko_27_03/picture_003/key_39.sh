java -jar getLatinTag.jar kr ko "낚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "量" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "俱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瑜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洲" 1000  keyword_ko.txt
