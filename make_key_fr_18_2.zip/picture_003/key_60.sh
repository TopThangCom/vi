java -jar getLatinTag.jar fr  fr "facile" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "International" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "importantes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Marc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "capitale" 1000  keyword_fr.txt
