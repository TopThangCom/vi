java -jar getLatinTag.jar it it "loizides" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "terraria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ferroviario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ucraniano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alessia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "armancette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iannucci" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "izzo" 1000  keyword_it.txt
