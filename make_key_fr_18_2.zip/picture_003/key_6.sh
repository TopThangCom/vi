java -jar getLatinTag.jar fr  fr "besoins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "oeuvres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "américains" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "relations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "peau" 1000  keyword_fr.txt
