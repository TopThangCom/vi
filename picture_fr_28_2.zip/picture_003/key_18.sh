java -jar getLatinTag.jar kr kr "小田和正" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鈴木大和" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "巨人" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鈴木康弘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "馬主" 1000  keyword_kr.txt
