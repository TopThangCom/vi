java -jar getLatinTag.jar kr ko "麟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "籤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "攣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "競" 1000  keyword_ko.txt
