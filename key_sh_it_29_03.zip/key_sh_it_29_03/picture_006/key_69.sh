java -jar getLatinTag.jar it it "telato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mollica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nerivan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bicomedica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bicomet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bicondominio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vinzare" 1000  keyword_it.txt
