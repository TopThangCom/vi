java -jar getLatinTag.jar it it "sono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "utica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fregiare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fitti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diamonds" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accessories" 1000  keyword_it.txt
