java -jar getLatinTag.jar kr ko "蜇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "笛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "僕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "頡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "諜" 1000  keyword_ko.txt
