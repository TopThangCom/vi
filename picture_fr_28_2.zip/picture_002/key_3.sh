java -jar getLatinTag.jar kr kr "情報開示請求" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ip情報を検出中" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "失敗" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kt" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인터넷" 1000  keyword_kr.txt
