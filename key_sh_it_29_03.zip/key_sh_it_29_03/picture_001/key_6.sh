java -jar getLatinTag.jar it it "passato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "prossimo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addormentata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addormentati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addormentato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aggettivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "francese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colpa" 1000  keyword_it.txt
