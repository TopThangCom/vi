java -jar getLatinTag.jar kr kr "대리점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영업시간" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "토요일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "휴대폰" 1000  keyword_kr.txt
