java -jar getLatinTag.jar kr ko "違" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "加" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "臨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "床" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "析" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "螢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "連" 1000  keyword_ko.txt
