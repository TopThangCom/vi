java -jar getLatinTag.jar kr ko "勒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "惡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "럴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "핀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쎄" 1000  keyword_ko.txt
