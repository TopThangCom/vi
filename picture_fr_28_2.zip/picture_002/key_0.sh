java -jar getLatinTag.jar kr kr "美國頂級" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "眼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "牛排" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "雙人" 1000  keyword_kr.txt
