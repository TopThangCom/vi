java -jar getLatinTag.jar kr kr "작성법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검증" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트렌드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "건설" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사례" 1000  keyword_kr.txt
