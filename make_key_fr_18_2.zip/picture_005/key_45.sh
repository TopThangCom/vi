java -jar getLatinTag.jar fr  fr "solutions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "LA" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fabricants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "paie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Finances" 1000  keyword_fr.txt
