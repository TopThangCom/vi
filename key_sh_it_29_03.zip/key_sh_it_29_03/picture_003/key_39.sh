java -jar getLatinTag.jar it it "pronote" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "automatic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "resuscitator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sparatoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amcannunci" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amcardia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "application" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mcat" 1000  keyword_it.txt
