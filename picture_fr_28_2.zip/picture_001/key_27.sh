java -jar getLatinTag.jar kr kr "다시보내기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "디스코드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인증" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인증번호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٦×٦" 1000  keyword_kr.txt
