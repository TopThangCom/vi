java -jar getLatinTag.jar it it "assoroccia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assorologi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assorotabili" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assortative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spices" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assortiment" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "picard" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scoring" 1000  keyword_it.txt
