java -jar getLatinTag.jar fr  fr "il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sont" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "La" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Les" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ou" 1000  keyword_fr.txt
