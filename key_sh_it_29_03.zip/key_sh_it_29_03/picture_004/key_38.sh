java -jar getLatinTag.jar it it "tobillo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artropatia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asacol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "supposte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardiff" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "domicilio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "original" 1000  keyword_it.txt
