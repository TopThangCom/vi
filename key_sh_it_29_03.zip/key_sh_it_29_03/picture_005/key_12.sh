java -jar getLatinTag.jar it it "ccc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bachillerato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artistica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "simetricas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcorisa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asiscore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allianz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "remota" 1000  keyword_it.txt
