java -jar getLatinTag.jar fr  fr "positif" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Luc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "administrateur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "intéressante" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commerciale" 1000  keyword_fr.txt
