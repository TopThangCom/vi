java -jar getLatinTag.jar it it "ascostromata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clienti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conegliano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gruppo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascott" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "verification" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascribing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iol" 1000  keyword_it.txt
