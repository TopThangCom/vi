java -jar getLatinTag.jar it it "genitori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "traduzione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "peti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cortines" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tranemo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pazzi" 1000  keyword_it.txt
