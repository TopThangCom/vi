java -jar getLatinTag.jar fr  fr "proposent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aide" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ferme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'enfant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'or" 1000  keyword_fr.txt
