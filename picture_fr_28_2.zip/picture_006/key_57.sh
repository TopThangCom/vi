java -jar getLatinTag.jar kr kr "yvr" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "출발" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "yqb" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "도착" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "항공편" 1000  keyword_kr.txt
