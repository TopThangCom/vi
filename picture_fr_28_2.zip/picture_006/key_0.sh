java -jar getLatinTag.jar kr kr "건설업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "건설산업연구원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "회사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "국내" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기업가치평가" 1000  keyword_kr.txt
