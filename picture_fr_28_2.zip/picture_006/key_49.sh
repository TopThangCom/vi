java -jar getLatinTag.jar kr kr "마왕님" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "짤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "돌아가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바꿔줄" 1000  keyword_kr.txt
