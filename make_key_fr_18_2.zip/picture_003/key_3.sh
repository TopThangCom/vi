java -jar getLatinTag.jar fr  fr "magasins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "collaboration" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "répondre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "TVA" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "holding" 1000  keyword_fr.txt
