java -jar getLatinTag.jar kr ko "唯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "變" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "떤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "此" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "零" 1000  keyword_ko.txt
