java -jar getLatinTag.jar it it "amperometry" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tintenpatronen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amperzand" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "etichetta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampicilina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampicillin" 1000  keyword_it.txt
