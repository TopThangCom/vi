java -jar getLatinTag.jar kr kr "卓上製本機" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "bq" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "jr" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "乗り放題" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사업계획서" 1000  keyword_kr.txt
