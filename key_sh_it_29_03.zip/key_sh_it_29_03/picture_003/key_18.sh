java -jar getLatinTag.jar it it "condicions" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intimo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "finissima" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diagnosi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sistemica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gentamicine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "classification" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aminossalicilatos" 1000  keyword_it.txt
