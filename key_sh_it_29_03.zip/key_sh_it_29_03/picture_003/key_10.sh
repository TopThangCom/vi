java -jar getLatinTag.jar it it "altaneros" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antropologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "editora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bartolome" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neae" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mdcalc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "llanera" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allergoid" 1000  keyword_it.txt
