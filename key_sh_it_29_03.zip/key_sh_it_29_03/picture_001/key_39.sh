java -jar getLatinTag.jar it it "alimentares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrancop" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antonimo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fisico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tratamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abranet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abranfio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abranfiscal" 1000  keyword_it.txt
