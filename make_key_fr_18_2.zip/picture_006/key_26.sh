java -jar getLatinTag.jar fr  fr "pieds" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "publié" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ford" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "menace" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réunion" 1000  keyword_fr.txt
