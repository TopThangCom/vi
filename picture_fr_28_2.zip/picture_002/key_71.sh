java -jar getLatinTag.jar kr kr "初期化" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "暗証番号" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "백준" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "js" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파이오니아" 1000  keyword_kr.txt
