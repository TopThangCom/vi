java -jar getLatinTag.jar kr kr "법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판매" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "김광석" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "부산" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "백예린" 1000  keyword_kr.txt
