java -jar getLatinTag.jar fr  fr "facilement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "publiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "croire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "disponible" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Louis" 1000  keyword_fr.txt
