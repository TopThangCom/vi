java -jar getLatinTag.jar fr  fr "culture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Commission" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'entre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "possibilités" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "semestre" 1000  keyword_fr.txt
