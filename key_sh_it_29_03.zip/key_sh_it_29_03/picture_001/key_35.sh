java -jar getLatinTag.jar it it "al" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "infantil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "telefono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mediterrani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cif" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "significat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antonio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "francesco" 1000  keyword_it.txt
