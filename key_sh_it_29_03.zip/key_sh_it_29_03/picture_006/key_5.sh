java -jar getLatinTag.jar it it "altera" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giorno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "latim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scarsito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brocato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broccoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brocolis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cuisson" 1000  keyword_it.txt
