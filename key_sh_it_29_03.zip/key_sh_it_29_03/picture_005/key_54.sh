java -jar getLatinTag.jar it it "atirol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ativan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chimenea" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atlixconoticias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atmosferra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "datos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cifarelli" 1000  keyword_it.txt
