java -jar getLatinTag.jar kr kr "藍美代子の店" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "銀座" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "瀬戸の花嫁" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "母" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "白光名曲" 1000  keyword_kr.txt
