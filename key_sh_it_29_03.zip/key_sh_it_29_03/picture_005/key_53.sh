java -jar getLatinTag.jar it it "astromantic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "telescope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrometrica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iasc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrometrical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astronomania" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astronomer" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astronomia" 1000  keyword_it.txt
