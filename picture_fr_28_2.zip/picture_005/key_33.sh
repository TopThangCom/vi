java -jar getLatinTag.jar kr kr "지는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "방향지시등" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "그랜저" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전구" 1000  keyword_kr.txt
