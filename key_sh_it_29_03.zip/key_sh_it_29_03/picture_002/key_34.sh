java -jar getLatinTag.jar it it "adenotonsillotomia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cells" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "unfall" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campollano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bregnano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adeodato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "netto" 1000  keyword_it.txt
