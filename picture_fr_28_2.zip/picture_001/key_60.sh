java -jar getLatinTag.jar kr kr "통계" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "어비스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "속표지" 1000  keyword_kr.txt
