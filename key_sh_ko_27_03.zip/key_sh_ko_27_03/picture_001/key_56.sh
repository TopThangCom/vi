java -jar getLatinTag.jar kr ko "우" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "변" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "설" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "늘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "초" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "체" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "약" 1000  keyword_ko.txt
