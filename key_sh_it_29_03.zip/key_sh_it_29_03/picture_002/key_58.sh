java -jar getLatinTag.jar it it "agricoltura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trattamenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "divinopolis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "decorativi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personalizzati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trasparenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pubblicitari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiudibusta" 1000  keyword_it.txt
