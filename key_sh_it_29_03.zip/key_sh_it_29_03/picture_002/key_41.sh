java -jar getLatinTag.jar it it "aeropasse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "passion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aeropassion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allemagne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aeroporti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catarina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aeropostale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rc" 1000  keyword_it.txt
