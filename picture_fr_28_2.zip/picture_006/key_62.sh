java -jar getLatinTag.jar kr kr "사업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사업보고서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관련" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사회적" 1000  keyword_kr.txt
