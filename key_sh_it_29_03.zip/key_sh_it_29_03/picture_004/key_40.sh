java -jar getLatinTag.jar it it "aqualicity" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "licorne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualimpia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "imperatriz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqualine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cannabis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "filtro" 1000  keyword_it.txt
