java -jar getLatinTag.jar kr kr "버튼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "회전해서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "jpg로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이미지로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통합하기" 1000  keyword_kr.txt
