java -jar getLatinTag.jar kr kr "넘기기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고군분투" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "두번째" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "줄거리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아몬드" 1000  keyword_kr.txt
