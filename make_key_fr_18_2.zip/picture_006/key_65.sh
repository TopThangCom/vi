java -jar getLatinTag.jar fr  fr "conduite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D'une" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "longueur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tarifs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vérité" 1000  keyword_fr.txt
