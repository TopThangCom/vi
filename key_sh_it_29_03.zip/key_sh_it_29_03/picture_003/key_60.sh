java -jar getLatinTag.jar it it "anosodiaforia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anosodiaforie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anosognosia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anemica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anossica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "neonato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ipossia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "istotossica" 1000  keyword_it.txt
