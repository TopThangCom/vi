java -jar getLatinTag.jar kr kr "스위치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ip" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ipo" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "鶴見製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "電子天平" 1000  keyword_kr.txt
