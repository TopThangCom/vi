java -jar getLatinTag.jar kr ko "冒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "軸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "偽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "駿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "河" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "改" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "談" 1000  keyword_ko.txt
