java -jar getLatinTag.jar fr  fr "informations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'industrie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "trimestre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "E" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "différence" 1000  keyword_fr.txt
