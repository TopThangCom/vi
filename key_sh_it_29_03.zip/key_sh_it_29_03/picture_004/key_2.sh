java -jar getLatinTag.jar it it "dalcis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interpretazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caorso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "limonest" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vittoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arterias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coronarias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iliacas" 1000  keyword_it.txt
