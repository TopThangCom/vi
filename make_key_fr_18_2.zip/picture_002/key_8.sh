java -jar getLatinTag.jar fr  fr "Internet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "J'ai" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "enfin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "net" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "charge" 1000  keyword_fr.txt
