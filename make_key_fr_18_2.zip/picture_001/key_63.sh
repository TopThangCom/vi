java -jar getLatinTag.jar fr  fr "année" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "base" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bourse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lors" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vers" 1000  keyword_fr.txt
