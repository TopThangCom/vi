java -jar getLatinTag.jar kr ko "樹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "擬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "局" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "晶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "骨" 1000  keyword_ko.txt
