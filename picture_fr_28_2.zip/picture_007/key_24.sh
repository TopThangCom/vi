java -jar getLatinTag.jar kr kr "승준아율" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주날씨" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kfc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "변천사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "awg" 1000  keyword_kr.txt
