java -jar getLatinTag.jar fr  fr "photo" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "salaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Avant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "compter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'Est" 1000  keyword_fr.txt
