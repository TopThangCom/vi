java -jar getLatinTag.jar fr  fr "pratiquement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "annuel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "paiement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bank" 1000  keyword_fr.txt
