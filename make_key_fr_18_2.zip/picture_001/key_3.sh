java -jar getLatinTag.jar fr  fr "souvent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'entreprise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "autre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "peuvent" 1000  keyword_fr.txt
