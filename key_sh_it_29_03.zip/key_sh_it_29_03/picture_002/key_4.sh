java -jar getLatinTag.jar it it "luxottica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giocaore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "storia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "circle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atencion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diccionario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "insolvenz" 1000  keyword_it.txt
