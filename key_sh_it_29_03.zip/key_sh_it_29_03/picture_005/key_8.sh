java -jar getLatinTag.jar it it "astranazol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pascal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astranet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "microgeo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrazeneca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cheval" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astriol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compatibility" 1000  keyword_it.txt
