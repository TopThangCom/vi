java -jar getLatinTag.jar kr ko "斤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "솟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "詳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "葡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "萄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "礎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "峰" 1000  keyword_ko.txt
