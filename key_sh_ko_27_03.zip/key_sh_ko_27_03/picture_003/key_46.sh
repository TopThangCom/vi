java -jar getLatinTag.jar kr ko "疫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "升" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "死" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "混" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "凝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鍋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昔" 1000  keyword_ko.txt
