java -jar getLatinTag.jar kr kr "코드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "차단기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "선정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전선" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전선아시아" 1000  keyword_kr.txt
