java -jar getLatinTag.jar fr  fr "italienne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ménages" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "repas" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "PetroFina" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "langues" 1000  keyword_fr.txt
