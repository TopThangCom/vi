java -jar getLatinTag.jar fr  fr "Pendant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "allemande" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'assurance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "André" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fille" 1000  keyword_fr.txt
