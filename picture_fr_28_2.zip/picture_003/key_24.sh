java -jar getLatinTag.jar kr kr "이용가능한도를" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모두" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사용하셨습니다.이후" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "wifi" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "환경에서" 1000  keyword_kr.txt
