java -jar getLatinTag.jar fr  fr "exemple" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "compte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "belge" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "premier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s" 1000  keyword_fr.txt
