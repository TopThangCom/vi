java -jar getLatinTag.jar kr ko "能" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "半" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "웨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "금" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "별" 1000  keyword_ko.txt
