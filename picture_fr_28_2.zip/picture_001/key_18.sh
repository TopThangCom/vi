java -jar getLatinTag.jar kr kr "연동" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "브라이언" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기타" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "퀸" 1000  keyword_kr.txt
