java -jar getLatinTag.jar fr  fr "également" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Dans" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "effet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pays" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cas" 1000  keyword_fr.txt
