java -jar getLatinTag.jar kr ko "薪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "包" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "됩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "않" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "을" 1000  keyword_ko.txt
