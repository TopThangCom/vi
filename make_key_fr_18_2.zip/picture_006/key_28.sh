java -jar getLatinTag.jar fr  fr "directe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "compétences" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conseiller" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "facteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'est" 1000  keyword_fr.txt
