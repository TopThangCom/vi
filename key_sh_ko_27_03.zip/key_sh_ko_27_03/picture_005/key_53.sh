java -jar getLatinTag.jar kr ko "沈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "棠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "垃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "圾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "푼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嗣" 1000  keyword_ko.txt
