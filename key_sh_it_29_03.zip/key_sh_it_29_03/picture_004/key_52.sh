java -jar getLatinTag.jar it it "principat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentech" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascented" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascential" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentium" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascentives" 1000  keyword_it.txt
