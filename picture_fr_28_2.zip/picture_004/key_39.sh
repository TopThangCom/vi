java -jar getLatinTag.jar kr kr "메모장" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전체" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "붙여넣기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "명령" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한줄" 1000  keyword_kr.txt
