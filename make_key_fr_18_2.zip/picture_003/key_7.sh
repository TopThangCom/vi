java -jar getLatinTag.jar fr  fr "essentiellement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prévu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Japon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prévisions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "centrale" 1000  keyword_fr.txt
