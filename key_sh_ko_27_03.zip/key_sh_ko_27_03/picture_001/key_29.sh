java -jar getLatinTag.jar kr ko "銀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "行" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "허" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "절" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "분" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "달" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "된" 1000  keyword_ko.txt
