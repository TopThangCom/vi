java -jar getLatinTag.jar it it "alimentar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ergonomica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cosco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lavagna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "siciliana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantonale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "svizzera" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cope" 1000  keyword_it.txt
