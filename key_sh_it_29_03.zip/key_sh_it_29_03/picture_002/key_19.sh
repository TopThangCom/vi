java -jar getLatinTag.jar it it "pabianice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "otorino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contagem" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pollo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allariz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chocolate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castilla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trap" 1000  keyword_it.txt
