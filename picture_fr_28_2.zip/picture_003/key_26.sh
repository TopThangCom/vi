java -jar getLatinTag.jar kr kr "看護師" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "歯科衛生士" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "採用" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "営業時間" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "登戸" 1000  keyword_kr.txt
