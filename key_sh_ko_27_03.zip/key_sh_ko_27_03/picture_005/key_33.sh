java -jar getLatinTag.jar kr ko "獣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "顆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "讀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蟾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "圍" 1000  keyword_ko.txt
