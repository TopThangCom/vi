java -jar getLatinTag.jar kr kr "할인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무제한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "요금" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "납부" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자동이체" 1000  keyword_kr.txt
