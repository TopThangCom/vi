java -jar getLatinTag.jar fr  fr "l'emploi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "main" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "voire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "technologie" 1000  keyword_fr.txt
