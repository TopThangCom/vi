java -jar getLatinTag.jar kr ko "猶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "잭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쾃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "凶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "暑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "촌" 1000  keyword_ko.txt
