java -jar getLatinTag.jar fr  fr "porteur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "répartition" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "blanche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "composants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "future" 1000  keyword_fr.txt
