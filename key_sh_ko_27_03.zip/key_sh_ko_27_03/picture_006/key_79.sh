java -jar getLatinTag.jar kr ko "薰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "괌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꺼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "捜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "獸" 1000  keyword_ko.txt
