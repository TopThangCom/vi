java -jar getLatinTag.jar kr kr "홈페이지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "홈버튼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "홈화면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바로가기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "홈키" 1000  keyword_kr.txt
