java -jar getLatinTag.jar fr  fr "sept" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partout" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "immobilier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lancement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rating" 1000  keyword_fr.txt
