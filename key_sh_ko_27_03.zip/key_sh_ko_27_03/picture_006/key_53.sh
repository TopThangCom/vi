java -jar getLatinTag.jar kr ko "酪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "恰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "藩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "虜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "餡" 1000  keyword_ko.txt
