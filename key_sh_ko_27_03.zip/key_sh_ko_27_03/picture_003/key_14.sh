java -jar getLatinTag.jar kr ko "됌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "며" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蒸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "重" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "乳" 1000  keyword_ko.txt
