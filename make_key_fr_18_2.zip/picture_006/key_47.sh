java -jar getLatinTag.jar fr  fr "tendances" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D'autre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prudence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "savent" 1000  keyword_fr.txt
