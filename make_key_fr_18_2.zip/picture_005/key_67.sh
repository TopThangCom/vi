java -jar getLatinTag.jar fr  fr "centaines" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "course" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "billet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "critique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'arrivée" 1000  keyword_fr.txt
