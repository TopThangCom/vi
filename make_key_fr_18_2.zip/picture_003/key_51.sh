java -jar getLatinTag.jar fr  fr "voitures" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "patron" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Malgré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "affiche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "situe" 1000  keyword_fr.txt
