java -jar getLatinTag.jar kr kr "투자자격증" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "투자자산" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "요구" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kbo" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한국시리즈" 1000  keyword_kr.txt
