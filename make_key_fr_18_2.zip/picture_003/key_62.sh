java -jar getLatinTag.jar fr  fr "devises" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "difficultés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sort" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "national" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "machines" 1000  keyword_fr.txt
