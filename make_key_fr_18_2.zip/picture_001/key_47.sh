java -jar getLatinTag.jar fr  fr "mais" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "on" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tout" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nous" 1000  keyword_fr.txt
