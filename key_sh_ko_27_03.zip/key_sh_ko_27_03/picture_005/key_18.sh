java -jar getLatinTag.jar kr ko "妝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "佬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "様" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "糕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "當" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勞" 1000  keyword_ko.txt
