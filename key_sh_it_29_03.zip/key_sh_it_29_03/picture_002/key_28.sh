java -jar getLatinTag.jar it it "rica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adistol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adiston" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adistone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adistop" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adistore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inicial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimentarios" 1000  keyword_it.txt
