java -jar getLatinTag.jar kr ko "니" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "온" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "치" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "순" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "서" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "정" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "효" 1000  keyword_ko.txt
