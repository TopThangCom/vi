java -jar getLatinTag.jar kr ko "휴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "펌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "正" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "組" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "犯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "罪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "開" 1000  keyword_ko.txt
