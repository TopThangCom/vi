java -jar getLatinTag.jar it it "meccaniche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "negozio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solares" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brachiaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brachiterapia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stimme" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bracottas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calvino" 1000  keyword_it.txt
