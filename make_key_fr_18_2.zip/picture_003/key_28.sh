java -jar getLatinTag.jar fr  fr "idée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'Internet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'eau" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "créé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nuit" 1000  keyword_fr.txt
