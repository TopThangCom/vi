java -jar getLatinTag.jar kr ko "巨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "馬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "主" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "靖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "我" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "孫" 1000  keyword_ko.txt
