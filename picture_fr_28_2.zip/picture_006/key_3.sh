java -jar getLatinTag.jar kr kr "hip" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "법무법인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "매출" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정지원" 1000  keyword_kr.txt
