java -jar getLatinTag.jar kr ko "렴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뇌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "儒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "竟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "곰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "癖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "碑" 1000  keyword_ko.txt
