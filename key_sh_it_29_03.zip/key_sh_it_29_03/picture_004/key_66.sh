java -jar getLatinTag.jar it it "aquarotter" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magnetic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perpeller" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "preservative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "impression" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lifetime" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonicare" 1000  keyword_it.txt
