java -jar getLatinTag.jar fr  fr "Mieux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "aider" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ancienne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "apporte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nette" 1000  keyword_fr.txt
