java -jar getLatinTag.jar it it "prato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vallefoglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cagliari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lecco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "subito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquatica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquaviva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquazero" 1000  keyword_it.txt
