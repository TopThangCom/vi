java -jar getLatinTag.jar kr ko "信" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "天" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "團" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "購" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "電" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "器" 1000  keyword_ko.txt
