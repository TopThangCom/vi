java -jar getLatinTag.jar fr  fr "chercheurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "taxe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "salaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "transactions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Christian" 1000  keyword_fr.txt
