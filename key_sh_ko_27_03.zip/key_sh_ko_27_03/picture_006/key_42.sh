java -jar getLatinTag.jar kr ko "嗜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "묵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "죄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "얏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "佑" 1000  keyword_ko.txt
