java -jar getLatinTag.jar kr ko "厘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "존" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "脳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "往" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "點" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "聘" 1000  keyword_ko.txt
