java -jar getLatinTag.jar kr ko "탐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "누" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "궤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "홍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "錠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "屬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滲" 1000  keyword_ko.txt
