java -jar getLatinTag.jar fr  fr "lancée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "résoudre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "garanti" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "modification" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "revue" 1000  keyword_fr.txt
