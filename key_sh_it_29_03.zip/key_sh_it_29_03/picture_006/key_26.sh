java -jar getLatinTag.jar it it "britomartis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "briton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gioco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "notte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cochem" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "operator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brmonitor" 1000  keyword_it.txt
