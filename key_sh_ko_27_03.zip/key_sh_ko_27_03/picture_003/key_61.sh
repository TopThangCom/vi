java -jar getLatinTag.jar kr ko "買" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "握" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "款" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "灣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "填" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "震" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "毎" 1000  keyword_ko.txt
