java -jar getLatinTag.jar kr ko "図" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "復" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "活" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "順" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "票" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "放" 1000  keyword_ko.txt
