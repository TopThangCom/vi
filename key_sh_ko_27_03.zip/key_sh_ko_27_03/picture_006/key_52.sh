java -jar getLatinTag.jar kr ko "뭄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鶯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뚜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "껑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "癱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "註" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裘" 1000  keyword_ko.txt
