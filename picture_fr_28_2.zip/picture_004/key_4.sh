java -jar getLatinTag.jar kr kr "経歴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "目の色" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "目" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "幸村誠" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "게임" 1000  keyword_kr.txt
