java -jar getLatinTag.jar fr  fr "secrétaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "capitalisation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "langage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "positive" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "circulation" 1000  keyword_fr.txt
