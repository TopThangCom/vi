java -jar getLatinTag.jar fr  fr "réaction" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fleurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'effet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "record" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tribunal" 1000  keyword_fr.txt
