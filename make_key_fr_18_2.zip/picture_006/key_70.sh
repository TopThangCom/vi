java -jar getLatinTag.jar fr  fr "l'attention" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'administration" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "due" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faut-il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réussite" 1000  keyword_fr.txt
