java -jar getLatinTag.jar kr kr "인상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "상무" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사내변호사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "임원" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "과장" 1000  keyword_kr.txt
