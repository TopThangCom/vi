java -jar getLatinTag.jar kr ko "삢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "즬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쀻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "븥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "븻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짃" 1000  keyword_ko.txt
