java -jar getLatinTag.jar fr  fr "meilleure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'argent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "perspectives" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "développer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "celui-ci" 1000  keyword_fr.txt
