java -jar getLatinTag.jar kr kr "플랫폼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "최강자전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스페인어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "한자" 1000  keyword_kr.txt
