java -jar getLatinTag.jar kr kr "착륙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "날짜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "고백" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "깨방정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "유언" 1000  keyword_kr.txt
