java -jar getLatinTag.jar kr kr "香港文憑試招生錄取(學生端)" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "議事録" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "話者識別" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하이브리드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "애프터블로우" 1000  keyword_kr.txt
