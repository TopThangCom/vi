java -jar getLatinTag.jar kr ko "謀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "髓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "峭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "튠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煉" 1000  keyword_ko.txt
