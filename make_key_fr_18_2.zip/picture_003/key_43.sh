java -jar getLatinTag.jar fr  fr "d'or" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "veulent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Charleroi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "consommateurs" 1000  keyword_fr.txt
