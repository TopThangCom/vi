java -jar getLatinTag.jar kr kr "딜레이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가속" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "애드블록" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pc버전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구독자" 1000  keyword_kr.txt
