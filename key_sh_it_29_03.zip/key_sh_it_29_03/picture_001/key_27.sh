java -jar getLatinTag.jar it it "abrata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancestral" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "itu" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "metalica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clip" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lorenzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monteclaro" 1000  keyword_it.txt
