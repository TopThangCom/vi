java -jar getLatinTag.jar fr  fr "épouse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Canada" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entrer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "postes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "précision" 1000  keyword_fr.txt
