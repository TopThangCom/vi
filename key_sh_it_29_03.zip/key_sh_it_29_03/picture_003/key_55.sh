java -jar getLatinTag.jar it it "amminoacidi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "essenziali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "limitante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "struttura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ammonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ammortamenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sospensione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anticipati" 1000  keyword_it.txt
