java -jar getLatinTag.jar kr ko "寧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "若" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "荒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "董" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蓉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蔚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貝" 1000  keyword_ko.txt
