java -jar getLatinTag.jar fr  fr "corps" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "divers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Parmi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "numéro" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réduire" 1000  keyword_fr.txt
