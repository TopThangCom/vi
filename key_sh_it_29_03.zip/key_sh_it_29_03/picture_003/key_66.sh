java -jar getLatinTag.jar it it "sentimento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoressalud" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ramones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoretti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amorfinos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cristalinos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amorian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amorino" 1000  keyword_it.txt
