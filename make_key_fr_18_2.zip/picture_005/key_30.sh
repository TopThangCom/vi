java -jar getLatinTag.jar fr  fr "automatiquement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "plat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "boursier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sol" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "c'était" 1000  keyword_fr.txt
