java -jar getLatinTag.jar kr kr "경영" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아카데미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "lg전자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카이스트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대학원" 1000  keyword_kr.txt
