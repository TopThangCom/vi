java -jar getLatinTag.jar fr  fr "Alors" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "international" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "yeux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "PME" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'a" 1000  keyword_fr.txt
