java -jar getLatinTag.jar it it "atento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "osciloscopio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "castelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tentativamente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "naegleria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "picon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coletivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vivacqua" 1000  keyword_it.txt
