java -jar getLatinTag.jar it it "principiantes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "volcanic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "muffin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apetitoso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apicil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apidone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "identifier" 1000  keyword_it.txt
