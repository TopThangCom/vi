java -jar getLatinTag.jar it it "carcassonne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalouge" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquazenoto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquazoo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquazorbing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arezzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "livenza" 1000  keyword_it.txt
