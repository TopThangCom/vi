java -jar getLatinTag.jar kr kr "합치기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "편집" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무료폰트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pdf" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "표" 1000  keyword_kr.txt
