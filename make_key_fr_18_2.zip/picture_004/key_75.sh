java -jar getLatinTag.jar fr  fr "compagnies" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "documents" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pertes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sortie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "m'a" 1000  keyword_fr.txt
