java -jar getLatinTag.jar kr ko "센" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "심" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "객" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "새" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "끊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뎀" 1000  keyword_ko.txt
