java -jar getLatinTag.jar fr  fr "ainsi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "toujours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "société" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "depuis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tous" 1000  keyword_fr.txt
