java -jar getLatinTag.jar kr ko "虎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "牌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "多" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "烤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "템" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "벅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "적" 1000  keyword_ko.txt
