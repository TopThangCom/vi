java -jar getLatinTag.jar fr  fr "médias" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "victimes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "écran" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nécessairement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "découverte" 1000  keyword_fr.txt
