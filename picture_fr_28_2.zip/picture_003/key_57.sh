java -jar getLatinTag.jar kr kr "古事記" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "薬剤師" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田薬品" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "従業員数" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "推移" 1000  keyword_kr.txt
