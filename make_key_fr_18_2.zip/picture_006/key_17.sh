java -jar getLatinTag.jar fr  fr "vendeur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "événements" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "autrement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "experts" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fortes" 1000  keyword_fr.txt
