java -jar getLatinTag.jar it it "admittance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "american" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancestor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "color" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "concrete" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "android" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admonestation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "paternelle" 1000  keyword_it.txt
