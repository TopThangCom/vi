java -jar getLatinTag.jar it it "fiscal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "radiators" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sicilia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "viaggi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "potter" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oregon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copy" 1000  keyword_it.txt
