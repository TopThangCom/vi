java -jar getLatinTag.jar kr kr "크롤링" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "rss" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "세계" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영어사전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "숨은그림찾기" 1000  keyword_kr.txt
