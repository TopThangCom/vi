java -jar getLatinTag.jar fr  fr "crise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "importante" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "atteint" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "revenus" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "montant" 1000  keyword_fr.txt
