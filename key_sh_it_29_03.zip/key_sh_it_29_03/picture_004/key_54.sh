java -jar getLatinTag.jar it it "poolcontrol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atlantic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rolla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lamellen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "installation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquadella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "roompot" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquadipolo" 1000  keyword_it.txt
