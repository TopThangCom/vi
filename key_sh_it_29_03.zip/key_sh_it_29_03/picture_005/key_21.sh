java -jar getLatinTag.jar it it "laffita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcantara" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "protocols" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspegic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spittal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "modell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aspidella" 1000  keyword_it.txt
