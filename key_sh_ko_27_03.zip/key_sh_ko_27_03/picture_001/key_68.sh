java -jar getLatinTag.jar kr ko "르" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "카" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "시" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "진" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "글" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "자" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "혜" 1000  keyword_ko.txt
