java -jar getLatinTag.jar fr  fr "Outre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "porter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "écrit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cesse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "locaux" 1000  keyword_fr.txt
