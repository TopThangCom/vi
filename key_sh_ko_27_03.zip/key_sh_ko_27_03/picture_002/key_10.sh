java -jar getLatinTag.jar kr ko "診" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "額" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "溫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "槍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "療" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "関" 1000  keyword_ko.txt
