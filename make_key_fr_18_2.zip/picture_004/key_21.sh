java -jar getLatinTag.jar fr  fr "impossible" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "m" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "John" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "enfant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fournisseurs" 1000  keyword_fr.txt
