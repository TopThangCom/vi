java -jar getLatinTag.jar kr kr "寺岡製作所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "환율" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "환율계산" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "달러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "호주" 1000  keyword_kr.txt
