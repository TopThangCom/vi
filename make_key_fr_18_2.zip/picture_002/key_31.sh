java -jar getLatinTag.jar fr  fr "présente" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "passe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "PC" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lorsque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "choses" 1000  keyword_fr.txt
