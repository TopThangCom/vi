java -jar getLatinTag.jar kr kr "산자부" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가이드라인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "보도자료" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제일제당" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "esg" 1000  keyword_kr.txt
