java -jar getLatinTag.jar kr kr "条件付き書式" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "最小値" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pc市场占有率" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "全球pc市场份额" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "添付文書" 1000  keyword_kr.txt
