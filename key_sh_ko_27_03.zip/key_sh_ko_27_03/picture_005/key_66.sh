java -jar getLatinTag.jar kr ko "弧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鞠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "猴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "呂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "枠" 1000  keyword_ko.txt
