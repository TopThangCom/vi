java -jar getLatinTag.jar kr kr "무료" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "귀여운" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "할로윈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "g" 1000  keyword_kr.txt
