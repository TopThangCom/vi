java -jar getLatinTag.jar it it "addomesticato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addomesticatore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "superiore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trattabile" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "esercizi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "laterali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scolpiti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "crosspilot" 1000  keyword_it.txt
