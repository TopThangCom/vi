java -jar getLatinTag.jar it it "campsis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grandiflora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campsites" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stanica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rivoceranib" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camroll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camscanner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camsol" 1000  keyword_it.txt
