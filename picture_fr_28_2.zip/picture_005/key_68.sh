java -jar getLatinTag.jar kr kr "使用" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "方法" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "痙攣" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "痙攣英語" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "医療" 1000  keyword_kr.txt
