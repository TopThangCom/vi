java -jar getLatinTag.jar fr  fr "source" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "facteurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "milliers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "soleil" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tirer" 1000  keyword_fr.txt
