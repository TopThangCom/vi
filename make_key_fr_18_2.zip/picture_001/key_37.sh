java -jar getLatinTag.jar fr  fr "droit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'elle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "heures" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cependant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "service" 1000  keyword_fr.txt
