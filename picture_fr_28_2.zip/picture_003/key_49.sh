java -jar getLatinTag.jar kr kr "api" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "환율계산기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "베트남" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버웹툰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쿠키" 1000  keyword_kr.txt
