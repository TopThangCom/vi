java -jar getLatinTag.jar fr  fr "PS" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "art" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Italie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "amélioration" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "auteurs" 1000  keyword_fr.txt
