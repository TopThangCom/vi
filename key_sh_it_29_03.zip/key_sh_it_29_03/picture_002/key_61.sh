java -jar getLatinTag.jar it it "impertinentes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admoniciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "francisco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admonitoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admonitorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "immigration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "admonzon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cc" 1000  keyword_it.txt
