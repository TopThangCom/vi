java -jar getLatinTag.jar fr  fr "quelqu'un" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "disposer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "global" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "écoles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Quel" 1000  keyword_fr.txt
