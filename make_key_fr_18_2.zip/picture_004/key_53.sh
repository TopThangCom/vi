java -jar getLatinTag.jar fr  fr "vise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "types" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "détail" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mauvaise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "professeur" 1000  keyword_fr.txt
