java -jar getLatinTag.jar fr  fr "gestion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "font" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quand" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "capital" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gouvernement" 1000  keyword_fr.txt
