java -jar getLatinTag.jar it it "dermatologue" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "augurandogli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giornata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sociale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "auscoma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "auspicio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "franciscana" 1000  keyword_it.txt
