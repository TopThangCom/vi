java -jar getLatinTag.jar kr ko "面" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "江" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "州" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "工" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "溶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "接" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "技" 1000  keyword_ko.txt
