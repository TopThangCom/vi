java -jar getLatinTag.jar fr  fr "estimé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quinze" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Russie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "demain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "précédent" 1000  keyword_fr.txt
