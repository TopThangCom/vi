java -jar getLatinTag.jar it it "fatima" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montpellier" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "raffaele" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rifatti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amfconfig" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "filtration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amicalola" 1000  keyword_it.txt
