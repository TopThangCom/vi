java -jar getLatinTag.jar it it "picchu" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "definitivamente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "provisoriamente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "policial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "implicito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "indireto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conversa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "goticas" 1000  keyword_it.txt
