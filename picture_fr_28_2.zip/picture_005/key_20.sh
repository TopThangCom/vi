java -jar getLatinTag.jar kr kr "재생" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "os" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "플렉스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "앱으로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "홈" 1000  keyword_kr.txt
