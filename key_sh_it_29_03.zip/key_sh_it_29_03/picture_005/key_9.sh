java -jar getLatinTag.jar it it "assignedaccessmanager" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sefaz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "digitalmente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assirat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assistance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "filantropia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cartilla" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "icatu" 1000  keyword_it.txt
