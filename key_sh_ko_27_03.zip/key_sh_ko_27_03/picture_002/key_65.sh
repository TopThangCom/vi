java -jar getLatinTag.jar kr ko "淨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "立" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "源" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "池" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "袋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "층" 1000  keyword_ko.txt
