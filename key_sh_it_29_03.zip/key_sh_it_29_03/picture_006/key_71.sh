java -jar getLatinTag.jar it it "brocone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brocott" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montebello" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromadiolone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dopamine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mccomb" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromatometria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bromatometri" 1000  keyword_it.txt
