java -jar getLatinTag.jar fr  fr "sera" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entreprises" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "F" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "francs" 1000  keyword_fr.txt
