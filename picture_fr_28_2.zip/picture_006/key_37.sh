java -jar getLatinTag.jar kr kr "안돼서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼서요" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "돼서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "맞춤법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안되서" 1000  keyword_kr.txt
