java -jar getLatinTag.jar fr  fr "processus" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "placement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "classique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dividende" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rester" 1000  keyword_fr.txt
