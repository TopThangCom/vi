java -jar getLatinTag.jar kr ko "處" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "즌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "육" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "켄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "려" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "와" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "為" 1000  keyword_ko.txt
