java -jar getLatinTag.jar kr kr "ffmpeg" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "팔로우" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "부검" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "목록" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "hp" 1000  keyword_kr.txt
