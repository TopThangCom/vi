java -jar getLatinTag.jar it it "alcool" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cialis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "accrete" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "convite" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "continente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interacciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atitudinal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acessorios" 1000  keyword_it.txt
