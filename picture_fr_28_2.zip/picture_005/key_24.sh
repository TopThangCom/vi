java -jar getLatinTag.jar kr kr "해제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불가능한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전환하는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "npdf" 1000  keyword_kr.txt
