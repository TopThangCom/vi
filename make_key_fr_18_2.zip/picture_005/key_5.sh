java -jar getLatinTag.jar fr  fr "l'absence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mark" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pointe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "solide" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Voici" 1000  keyword_fr.txt
