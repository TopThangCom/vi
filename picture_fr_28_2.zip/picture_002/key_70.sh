java -jar getLatinTag.jar kr kr "危険" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ご利益" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "意味" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染意思" 1000  keyword_kr.txt
