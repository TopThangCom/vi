java -jar getLatinTag.jar it it "clarinet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "estagio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brimonidine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recall" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "timolol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gincana" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brincolin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brindologia" 1000  keyword_it.txt
