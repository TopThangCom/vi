java -jar getLatinTag.jar kr kr "이미징유닛" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리셋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "삼성" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "프린터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무선연결" 1000  keyword_kr.txt
