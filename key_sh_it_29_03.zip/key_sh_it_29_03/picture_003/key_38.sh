java -jar getLatinTag.jar it it "oligostemone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "polistemone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardiologue" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alternativa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiuso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sportzone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pumpcontrol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "androide" 1000  keyword_it.txt
