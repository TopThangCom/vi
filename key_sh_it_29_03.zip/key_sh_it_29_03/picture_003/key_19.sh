java -jar getLatinTag.jar it it "ameliorated" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ameliorating" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amelioration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ameliorative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "deloitte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amemosaltachira" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amenazante" 1000  keyword_it.txt
