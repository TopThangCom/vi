java -jar getLatinTag.jar fr  fr "appel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Autre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "travaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'occasion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "juste" 1000  keyword_fr.txt
