java -jar getLatinTag.jar kr kr "짜증난다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "진짜" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정말" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "dgn" 1000  keyword_kr.txt
