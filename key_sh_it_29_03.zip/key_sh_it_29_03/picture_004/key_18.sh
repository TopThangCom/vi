java -jar getLatinTag.jar it it "macquarie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "static" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquamateriel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "distributors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquamaton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquamecca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chiller" 1000  keyword_it.txt
