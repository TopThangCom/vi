java -jar getLatinTag.jar fr  fr "demeure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "garde" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "maisons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Solvay" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conséquences" 1000  keyword_fr.txt
