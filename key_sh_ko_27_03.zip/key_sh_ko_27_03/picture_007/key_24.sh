java -jar getLatinTag.jar kr ko "愉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "螻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "牢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吟" 1000  keyword_ko.txt
