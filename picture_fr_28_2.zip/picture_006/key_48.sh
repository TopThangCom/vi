java -jar getLatinTag.jar kr kr "위원회" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kb" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "자가진단" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "lx인터내셔널" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "esg위원회" 1000  keyword_kr.txt
