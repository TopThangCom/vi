java -jar getLatinTag.jar fr  fr "double" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sujet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "généralement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "restent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "celles" 1000  keyword_fr.txt
