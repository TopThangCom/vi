java -jar getLatinTag.jar fr  fr "pourront" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "poursuit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chemin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "emplois" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'environnement" 1000  keyword_fr.txt
