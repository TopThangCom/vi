java -jar getLatinTag.jar kr ko "셜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "조" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "필" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "물" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "학" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "크" 1000  keyword_ko.txt
