java -jar getLatinTag.jar kr kr "지마켓" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "지마켓판매자센터" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "글로벌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "글로벌셀러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해외배송" 1000  keyword_kr.txt
