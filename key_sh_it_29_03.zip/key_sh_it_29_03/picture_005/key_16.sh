java -jar getLatinTag.jar it it "edmonton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ferrandiz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "spontanea" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rotativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocarro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocarrozzeria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cascone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocascone" 1000  keyword_it.txt
