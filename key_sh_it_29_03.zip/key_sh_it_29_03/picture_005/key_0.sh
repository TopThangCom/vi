java -jar getLatinTag.jar it it "accion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personala" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "deccan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrologanna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "astrologie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solarian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "economist" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scope" 1000  keyword_it.txt
