java -jar getLatinTag.jar fr  fr "compagnie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "publique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "coeur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "revenu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mesures" 1000  keyword_fr.txt
