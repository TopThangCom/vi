java -jar getLatinTag.jar kr kr "파일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실행" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "열기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "툴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "점" 1000  keyword_kr.txt
