java -jar getLatinTag.jar fr  fr "cause" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'abord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conditions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "juin" 1000  keyword_fr.txt
