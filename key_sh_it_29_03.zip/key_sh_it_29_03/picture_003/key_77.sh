java -jar getLatinTag.jar it it "dates" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "americio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "americold" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "quoting" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "americord" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nccc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "seniors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "martial" 1000  keyword_it.txt
