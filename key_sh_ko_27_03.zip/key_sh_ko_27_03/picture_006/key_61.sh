java -jar getLatinTag.jar kr ko "繼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "砥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "又" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앵" 1000  keyword_ko.txt
