java -jar getLatinTag.jar kr ko "胚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蒿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "翠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "栽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "샴" 1000  keyword_ko.txt
