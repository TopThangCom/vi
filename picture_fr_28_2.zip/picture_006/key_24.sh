java -jar getLatinTag.jar kr kr "쭈꾸미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인형" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "덱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "난투" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "금쪽이" 1000  keyword_kr.txt
