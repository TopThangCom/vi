java -jar getLatinTag.jar kr ko "造" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "養" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "規" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "維" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "製" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "品" 1000  keyword_ko.txt
