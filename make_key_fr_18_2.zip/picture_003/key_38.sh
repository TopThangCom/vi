java -jar getLatinTag.jar fr  fr "voix" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Grande-Bretagne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "disque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "affaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "minutes" 1000  keyword_fr.txt
