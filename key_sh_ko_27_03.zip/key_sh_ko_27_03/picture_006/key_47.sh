java -jar getLatinTag.jar kr ko "亦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "琊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "曆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蓮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "剽" 1000  keyword_ko.txt
