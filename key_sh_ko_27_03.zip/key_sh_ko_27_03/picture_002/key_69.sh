java -jar getLatinTag.jar kr ko "탑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "슐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "근" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "좌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뽐" 1000  keyword_ko.txt
