java -jar getLatinTag.jar it it "nutrition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "america" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adventon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adventori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capitalist" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calendario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "campers" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonic" 1000  keyword_it.txt
