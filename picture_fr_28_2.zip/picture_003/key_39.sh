java -jar getLatinTag.jar kr kr "現在" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "西武" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "復帰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田病院" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "六地蔵" 1000  keyword_kr.txt
