java -jar getLatinTag.jar fr  fr "monde" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "alors" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "actions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "autres" 1000  keyword_fr.txt
