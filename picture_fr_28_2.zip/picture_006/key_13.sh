java -jar getLatinTag.jar kr kr "서브" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스무살" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "세키로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "루트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "세이브" 1000  keyword_kr.txt
