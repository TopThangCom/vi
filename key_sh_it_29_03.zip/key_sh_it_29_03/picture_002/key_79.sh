java -jar getLatinTag.jar it it "principe" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abierto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "signo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "respeto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secreta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secreto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "casino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "letoltese" 1000  keyword_it.txt
