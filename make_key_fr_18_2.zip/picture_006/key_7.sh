java -jar getLatinTag.jar fr  fr "respecter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "stade" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "statistiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "certificats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'attend" 1000  keyword_fr.txt
