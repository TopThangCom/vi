java -jar getLatinTag.jar fr  fr "multimédia" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partiellement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "seules" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Gérard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Oui" 1000  keyword_fr.txt
