java -jar getLatinTag.jar kr kr "맛집" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "입장료" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파빌리온" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "빌딩이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무너" 1000  keyword_kr.txt
