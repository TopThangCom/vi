java -jar getLatinTag.jar kr kr "浅田彰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "構造と力" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "解説" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "逃走論" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "身長" 1000  keyword_kr.txt
