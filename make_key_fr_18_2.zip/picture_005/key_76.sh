java -jar getLatinTag.jar fr  fr "poser" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Asie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'utilisation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "usage" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "PIB" 1000  keyword_fr.txt
