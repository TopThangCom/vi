java -jar getLatinTag.jar it it "logistic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "parco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "quality" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abbigliamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "interiors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sefarditas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asquenazi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asquenazim" 1000  keyword_it.txt
