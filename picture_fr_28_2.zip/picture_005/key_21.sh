java -jar getLatinTag.jar kr kr "表列處所" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "보드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "증상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불량" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "天気" 1000  keyword_kr.txt
