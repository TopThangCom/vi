java -jar getLatinTag.jar fr  fr "avons" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'un" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "elles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moment" 1000  keyword_fr.txt
