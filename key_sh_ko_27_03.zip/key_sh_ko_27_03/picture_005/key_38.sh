java -jar getLatinTag.jar kr ko "既" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "厝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "覇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鼠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "允" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "硝" 1000  keyword_ko.txt
