java -jar getLatinTag.jar kr kr "카메라" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검색기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검색기록" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "타임" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "명령어" 1000  keyword_kr.txt
