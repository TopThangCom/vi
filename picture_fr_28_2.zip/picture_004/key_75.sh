java -jar getLatinTag.jar kr kr "허기워기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "앱스토어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "어린이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "온라인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "카드" 1000  keyword_kr.txt
