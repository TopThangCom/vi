java -jar getLatinTag.jar kr kr "自己診断結果" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "分析レポート" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "tvk" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "高校野球" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "理科自由研究" 1000  keyword_kr.txt
