java -jar getLatinTag.jar fr  fr "pourquoi" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "estime" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réalisé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "création" 1000  keyword_fr.txt
