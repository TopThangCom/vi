java -jar getLatinTag.jar fr  fr "réalisées" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "beurre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "opérateurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "achat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "province" 1000  keyword_fr.txt
