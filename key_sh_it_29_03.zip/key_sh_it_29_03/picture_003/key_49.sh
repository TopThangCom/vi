java -jar getLatinTag.jar it it "martine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amossola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "solicitors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "passivo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intencional" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "divorce" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "palomera" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discografia" 1000  keyword_it.txt
