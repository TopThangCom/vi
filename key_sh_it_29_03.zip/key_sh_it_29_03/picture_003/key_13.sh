java -jar getLatinTag.jar it it "perfusion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dolomiti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "normale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antelope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antenatal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "period" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antepono" 1000  keyword_it.txt
