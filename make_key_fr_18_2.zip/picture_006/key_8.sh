java -jar getLatinTag.jar fr  fr "économie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "discours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "distributeur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "domaines" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'introduction" 1000  keyword_fr.txt
