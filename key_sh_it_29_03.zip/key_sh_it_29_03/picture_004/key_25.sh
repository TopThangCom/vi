java -jar getLatinTag.jar it it "arantico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ginfes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clinical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "itto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aratta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arbidel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ribadesella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arbiter" 1000  keyword_it.txt
