java -jar getLatinTag.jar it it "vatican" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mesopotamia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "editores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "etimologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "critico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "subcritico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "viscoso" 1000  keyword_it.txt
