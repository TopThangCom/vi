java -jar getLatinTag.jar it it "inicio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "virtuales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tellme" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "union" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magneticos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agnostic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agoraquizz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "belluno" 1000  keyword_it.txt
