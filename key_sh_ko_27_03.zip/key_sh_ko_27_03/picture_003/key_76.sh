java -jar getLatinTag.jar kr ko "창" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쉐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "候" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "以" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "預" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "城" 1000  keyword_ko.txt
