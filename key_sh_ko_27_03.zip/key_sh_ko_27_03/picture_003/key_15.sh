java -jar getLatinTag.jar kr ko "緩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "壁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "燃" 1000  keyword_ko.txt
