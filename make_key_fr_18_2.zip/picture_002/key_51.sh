java -jar getLatinTag.jar fr  fr "majorité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "potentiel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moindre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "récemment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "secteurs" 1000  keyword_fr.txt
