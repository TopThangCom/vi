java -jar getLatinTag.jar kr ko "拒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "絕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "낙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "엔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "손" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "흥" 1000  keyword_ko.txt
