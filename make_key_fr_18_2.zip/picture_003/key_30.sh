java -jar getLatinTag.jar fr  fr "élevés" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Robert" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contrats" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "oublier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "performance" 1000  keyword_fr.txt
