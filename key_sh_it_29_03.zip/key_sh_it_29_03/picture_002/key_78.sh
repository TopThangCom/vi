java -jar getLatinTag.jar it it "designated" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aexcellent" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "traffic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "patrimoine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "afanosamente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "estaticos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "princesa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alicate" 1000  keyword_it.txt
