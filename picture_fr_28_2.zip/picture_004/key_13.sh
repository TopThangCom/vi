java -jar getLatinTag.jar kr kr "혜인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다니엘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하니" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해린" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "소속사" 1000  keyword_kr.txt
