java -jar getLatinTag.jar it it "adison" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monoi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artisticos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riace" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ripollet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "broncita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cirugia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colturale" 1000  keyword_it.txt
