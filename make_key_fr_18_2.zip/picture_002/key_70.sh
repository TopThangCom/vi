java -jar getLatinTag.jar fr  fr "chose" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "portefeuille" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "obligations" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "afin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "différents" 1000  keyword_fr.txt
