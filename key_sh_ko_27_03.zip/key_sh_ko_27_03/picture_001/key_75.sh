java -jar getLatinTag.jar kr ko "對" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "級" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "南" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "非" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "相" 1000  keyword_ko.txt
