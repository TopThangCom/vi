java -jar getLatinTag.jar it it "universitarias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mondial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intermedica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autorizandole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allosomes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recessiva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recesiva" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recesivo" 1000  keyword_it.txt
