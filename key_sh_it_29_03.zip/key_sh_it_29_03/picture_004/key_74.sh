java -jar getLatinTag.jar it it "chlorinator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "telescopic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coimbatore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquatalia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquaterra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquatic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquatubin" 1000  keyword_it.txt
