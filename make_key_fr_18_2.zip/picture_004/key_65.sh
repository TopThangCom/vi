java -jar getLatinTag.jar fr  fr "conjoncture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gauche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'origine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'utilisateur" 1000  keyword_fr.txt
