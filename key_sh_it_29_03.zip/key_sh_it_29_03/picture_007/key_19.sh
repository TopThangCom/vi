java -jar getLatinTag.jar it it "camerino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cameroid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "edilizia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fabrizio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giovanna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camescope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camfic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camfil" 1000  keyword_it.txt
