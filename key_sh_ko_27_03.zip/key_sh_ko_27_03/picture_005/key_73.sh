java -jar getLatinTag.jar kr ko "陵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "祉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "欠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "偵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "琵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誤" 1000  keyword_ko.txt
