java -jar getLatinTag.jar kr kr "pc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "문자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "키워드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서명" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이미지" 1000  keyword_kr.txt
