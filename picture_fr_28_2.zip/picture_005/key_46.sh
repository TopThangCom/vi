java -jar getLatinTag.jar kr kr "세트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "형광등" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전구색" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "볼전구" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전등" 1000  keyword_kr.txt
