java -jar getLatinTag.jar fr  fr "cours" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qu'il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "moins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sans" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "C'est" 1000  keyword_fr.txt
