java -jar getLatinTag.jar fr  fr "confort" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "familles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "investir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "reprend" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sert" 1000  keyword_fr.txt
