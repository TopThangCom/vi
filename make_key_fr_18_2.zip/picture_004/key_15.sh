java -jar getLatinTag.jar fr  fr "chance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faillite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "km" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "équipe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "musée" 1000  keyword_fr.txt
