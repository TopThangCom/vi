java -jar getLatinTag.jar it it "riscossioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atopica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adermatoglifia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampolletas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scottsdale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scandinavia" 1000  keyword_it.txt
