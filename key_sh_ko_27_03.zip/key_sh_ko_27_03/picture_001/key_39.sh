java -jar getLatinTag.jar kr ko "腦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "葉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "거" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "일" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "러" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "스" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "트" 1000  keyword_ko.txt
