java -jar getLatinTag.jar it it "processo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "detran" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "processual" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "protocolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ctt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catala" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "genetico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nutricional" 1000  keyword_it.txt
