java -jar getLatinTag.jar fr  fr "investissements" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dispose" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "financier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'achat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "membres" 1000  keyword_fr.txt
