java -jar getLatinTag.jar kr ko "喀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "噗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "班" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "朝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "佛" 1000  keyword_ko.txt
