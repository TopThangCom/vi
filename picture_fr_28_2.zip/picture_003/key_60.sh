java -jar getLatinTag.jar kr kr "기호를" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사용하여" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "산화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "형성을" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나타내시오" 1000  keyword_kr.txt
