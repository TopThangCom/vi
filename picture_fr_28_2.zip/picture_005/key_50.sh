java -jar getLatinTag.jar kr kr "사파리" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "브라우저" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "동기화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "비밀번호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "북마크" 1000  keyword_kr.txt
