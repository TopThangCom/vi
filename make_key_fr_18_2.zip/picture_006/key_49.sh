java -jar getLatinTag.jar fr  fr "immobiliers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Fax" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "anciennes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chevaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "médicaments" 1000  keyword_fr.txt
