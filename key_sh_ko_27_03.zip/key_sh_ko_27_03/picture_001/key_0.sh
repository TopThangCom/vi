java -jar getLatinTag.jar kr ko "部" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "神" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "川" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "県" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "三" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "井" 1000  keyword_ko.txt
