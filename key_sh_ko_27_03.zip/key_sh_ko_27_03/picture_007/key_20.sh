java -jar getLatinTag.jar kr ko "廿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鎢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "湍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "仗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "낀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "넨" 1000  keyword_ko.txt
