java -jar getLatinTag.jar fr  fr "bénéficiaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "couleurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mondial" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Cet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "maintenant" 1000  keyword_fr.txt
