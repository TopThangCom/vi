java -jar getLatinTag.jar it it "avantor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tecnologias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chega" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "leggieri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "specialization" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "iatra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avcomparatives" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "successor" 1000  keyword_it.txt
