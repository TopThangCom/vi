java -jar getLatinTag.jar it it "iona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avellino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "button" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "posologie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fanfic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancelotti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "careggi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "federico" 1000  keyword_it.txt
