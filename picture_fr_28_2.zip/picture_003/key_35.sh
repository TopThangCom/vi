java -jar getLatinTag.jar kr kr "宇都宮" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "店舗" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "fkd宇都宮店" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "宇都宮店" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "×" 1000  keyword_kr.txt
