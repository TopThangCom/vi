java -jar getLatinTag.jar it it "spice" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "compensation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "genealogia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascael" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ignace" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giganticus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascandi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascandic" 1000  keyword_it.txt
