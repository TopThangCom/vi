java -jar getLatinTag.jar kr kr "마릿수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사이트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개편" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개선" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나무위키" 1000  keyword_kr.txt
