java -jar getLatinTag.jar fr  fr "utilisé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "étude" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Leur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sensible" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Bref" 1000  keyword_fr.txt
