java -jar getLatinTag.jar kr kr "なぜ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "今後の見通し" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田薬品今後の見通し" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "adr" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "quola@adapter" 1000  keyword_kr.txt
