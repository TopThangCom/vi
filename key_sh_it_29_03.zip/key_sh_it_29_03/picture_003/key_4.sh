java -jar getLatinTag.jar it it "ambitersi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amborella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pollination" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amborellales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chalela" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scent" 1000  keyword_it.txt
