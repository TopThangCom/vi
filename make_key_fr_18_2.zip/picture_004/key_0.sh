java -jar getLatinTag.jar fr  fr "DE" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "S'il" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'administration" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Guy" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "est-il" 1000  keyword_fr.txt
