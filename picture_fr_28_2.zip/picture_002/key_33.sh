java -jar getLatinTag.jar kr kr "특성상" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "업데이트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "크롬에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "설치" 1000  keyword_kr.txt
