java -jar getLatinTag.jar kr kr "成仏" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "解呪" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "星の動き" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "空気と水" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "小学生" 1000  keyword_kr.txt
