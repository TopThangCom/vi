java -jar getLatinTag.jar kr ko "余" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "朵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "囲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沸" 1000  keyword_ko.txt
