java -jar getLatinTag.jar kr kr "掲示板" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "予想" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田薬品工業株価" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "急落" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pts" 1000  keyword_kr.txt
