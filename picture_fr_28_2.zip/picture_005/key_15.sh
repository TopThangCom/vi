java -jar getLatinTag.jar kr kr "굿노트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "띄어쓰기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수정하기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "문서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "금지" 1000  keyword_kr.txt
