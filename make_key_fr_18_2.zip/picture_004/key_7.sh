java -jar getLatinTag.jar fr  fr "appareils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "villes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "au-dessus" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "diminution" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prochaines" 1000  keyword_fr.txt
