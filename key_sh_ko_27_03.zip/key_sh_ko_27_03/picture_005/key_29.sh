java -jar getLatinTag.jar kr ko "庇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "멧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "矩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "받" 1000  keyword_ko.txt
