java -jar getLatinTag.jar kr ko "팩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "출" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "잔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "저" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "맞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "고" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "풀" 1000  keyword_ko.txt
