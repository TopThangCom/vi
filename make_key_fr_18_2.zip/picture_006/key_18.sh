java -jar getLatinTag.jar fr  fr "l'écran" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réserves" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sauce" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "venu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Charles" 1000  keyword_fr.txt
