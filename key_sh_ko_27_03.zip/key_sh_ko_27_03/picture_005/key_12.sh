java -jar getLatinTag.jar kr ko "弈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "큡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "閑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "郊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캅" 1000  keyword_ko.txt
