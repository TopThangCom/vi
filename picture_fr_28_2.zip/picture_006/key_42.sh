java -jar getLatinTag.jar kr kr "KPAY" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kg이니시스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버페이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "결제내역" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "결제오류" 1000  keyword_kr.txt
