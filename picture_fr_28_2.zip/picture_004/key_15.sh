java -jar getLatinTag.jar kr kr "스팀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아이패드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "맥북" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "fps" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "닌텐도" 1000  keyword_kr.txt
