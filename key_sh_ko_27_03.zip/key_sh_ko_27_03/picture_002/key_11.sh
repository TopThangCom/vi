java -jar getLatinTag.jar kr ko "썬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "델" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "즘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "념" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "階" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "命" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "前" 1000  keyword_ko.txt
