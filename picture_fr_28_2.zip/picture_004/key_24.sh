java -jar getLatinTag.jar kr kr "인턴" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채용계약학과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채용설명회" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "채용검진" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "탈락" 1000  keyword_kr.txt
