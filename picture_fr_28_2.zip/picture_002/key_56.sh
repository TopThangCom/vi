java -jar getLatinTag.jar kr kr "비공개" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "릴레이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이유" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배치파일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우분투" 1000  keyword_kr.txt
