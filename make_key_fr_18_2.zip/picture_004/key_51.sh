java -jar getLatinTag.jar fr  fr "supérieure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Certes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "faisant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ordinateur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "partenaire" 1000  keyword_fr.txt
