java -jar getLatinTag.jar fr  fr "analyse" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "films" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "surface" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "warrants" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "GBP" 1000  keyword_fr.txt
