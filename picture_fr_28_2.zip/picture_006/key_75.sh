java -jar getLatinTag.jar kr kr "기업가치" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "평가요소와" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기업가치의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "관계에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "연구" 1000  keyword_kr.txt
