java -jar getLatinTag.jar kr kr "法事" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "进行意思" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "仅限" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "今昔" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "압축하기" 1000  keyword_kr.txt
