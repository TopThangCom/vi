java -jar getLatinTag.jar kr kr "피파로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "추천인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "대낙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "포인트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "얻는법" 1000  keyword_kr.txt
