java -jar getLatinTag.jar kr ko "歪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嚥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "濠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肯" 1000  keyword_ko.txt
