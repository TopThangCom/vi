java -jar getLatinTag.jar kr ko "詞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "件" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蒲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "土" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "羽" 1000  keyword_ko.txt
