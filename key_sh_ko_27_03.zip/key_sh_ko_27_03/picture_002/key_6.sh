java -jar getLatinTag.jar kr ko "봉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "웹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "볼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "럽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "캐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "항" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빅" 1000  keyword_ko.txt
