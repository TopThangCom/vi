java -jar getLatinTag.jar fr  fr "cinéma" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "histoire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "zone" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sauf" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avantages" 1000  keyword_fr.txt
