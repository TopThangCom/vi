java -jar getLatinTag.jar it it "occlusive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcification" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aortomitrale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collateral" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collaterals" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addominale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcifica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "incision" 1000  keyword_it.txt
