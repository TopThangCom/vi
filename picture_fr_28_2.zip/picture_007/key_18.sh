java -jar getLatinTag.jar kr kr "fx" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "価格変動" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "価格帯別出来高" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "価格分布" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "tpc" 1000  keyword_kr.txt
