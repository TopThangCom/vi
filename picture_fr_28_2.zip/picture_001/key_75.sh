java -jar getLatinTag.jar kr kr "분자량" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "right" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "함수로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전달된" 1000  keyword_kr.txt
