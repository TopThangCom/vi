java -jar getLatinTag.jar it it "aqtivate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aqtivator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquabella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquabionic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conditioner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquabiotope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquabitzz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "champcevinel" 1000  keyword_it.txt
