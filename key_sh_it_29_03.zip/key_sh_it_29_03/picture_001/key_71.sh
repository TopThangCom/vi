java -jar getLatinTag.jar it it "magnetica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adeconna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uned" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gironde" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "posologia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "polivitaminico" 1000  keyword_it.txt
