java -jar getLatinTag.jar fr  fr "courrier" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "disposent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "développe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "présentation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "barre" 1000  keyword_fr.txt
