java -jar getLatinTag.jar kr kr "(멀티팩)" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "라이젠" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "출시일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "(세잔)" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "(멀티팩(정품))" 1000  keyword_kr.txt
