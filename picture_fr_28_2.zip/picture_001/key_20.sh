java -jar getLatinTag.jar kr kr "bcp" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "病院" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "厚生労働省" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "看護部" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "神奈川県" 1000  keyword_kr.txt
