java -jar getLatinTag.jar it it "cadireta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cadivannes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chloride" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "omicidio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cadorette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "supermercati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gontier" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costantinopoli" 1000  keyword_it.txt
