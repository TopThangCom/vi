java -jar getLatinTag.jar fr  fr "sociaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "supplémentaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "café" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "message" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "physique" 1000  keyword_fr.txt
