java -jar getLatinTag.jar kr ko "尬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "둘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "觀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "彌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "겹" 1000  keyword_ko.txt
