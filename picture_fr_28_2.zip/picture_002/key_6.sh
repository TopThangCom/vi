java -jar getLatinTag.jar kr kr "移行" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "部屋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "計算" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "畳" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "坪" 1000  keyword_kr.txt
