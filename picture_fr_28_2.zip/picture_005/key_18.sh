java -jar getLatinTag.jar kr kr "수수료" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "팀컬러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피파모바일" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사전등록" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "진화" 1000  keyword_kr.txt
