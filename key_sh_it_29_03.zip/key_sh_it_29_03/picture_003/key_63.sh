java -jar getLatinTag.jar it it "automotive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coding" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amcit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amcli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "migliori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amconfraria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amconmag" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amecc" 1000  keyword_it.txt
