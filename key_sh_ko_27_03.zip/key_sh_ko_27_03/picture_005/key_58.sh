java -jar getLatinTag.jar kr ko "펫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "텀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "몇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "득" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "희" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "놓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刮" 1000  keyword_ko.txt
