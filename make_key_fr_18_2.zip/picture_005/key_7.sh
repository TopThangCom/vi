java -jar getLatinTag.jar fr  fr "l'assuré" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "club" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "environnement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "noter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "crée" 1000  keyword_fr.txt
