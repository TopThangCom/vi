java -jar getLatinTag.jar fr  fr "véritable" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ligne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "longtemps" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "propres" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "devant" 1000  keyword_fr.txt
