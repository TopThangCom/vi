java -jar getLatinTag.jar fr  fr "fisc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "obtenu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "repris" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "occupe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sérieux" 1000  keyword_fr.txt
