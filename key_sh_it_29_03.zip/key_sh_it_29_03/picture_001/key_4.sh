java -jar getLatinTag.jar it it "process" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vesicle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fertilization" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "economicas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "preescolar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalog" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catalogue" 1000  keyword_it.txt
