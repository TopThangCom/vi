java -jar getLatinTag.jar kr ko "컹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뿡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "챙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "刈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瑯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坍" 1000  keyword_ko.txt
