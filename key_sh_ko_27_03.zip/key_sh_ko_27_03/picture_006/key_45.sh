java -jar getLatinTag.jar kr ko "팰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "큐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "磷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "녁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "禽" 1000  keyword_ko.txt
