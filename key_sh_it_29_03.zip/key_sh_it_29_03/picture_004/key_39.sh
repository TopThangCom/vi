java -jar getLatinTag.jar it it "niteroi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "goiztiarra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arriaga" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arriasse" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "col" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoniacal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "senton" 1000  keyword_it.txt
