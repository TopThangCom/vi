java -jar getLatinTag.jar it it "valcanale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cappadocia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiastrone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camporovere" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lessinia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "trentino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camposol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "semanticos" 1000  keyword_it.txt
