java -jar getLatinTag.jar kr kr "dx業界" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "転職" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "dx" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "業界別" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "進捗" 1000  keyword_kr.txt
