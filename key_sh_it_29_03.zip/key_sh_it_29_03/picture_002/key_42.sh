java -jar getLatinTag.jar it it "sicurezza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "oposiciones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "personal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aerator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "componentes" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "principio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aeromagnetic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aeromedical" 1000  keyword_it.txt
