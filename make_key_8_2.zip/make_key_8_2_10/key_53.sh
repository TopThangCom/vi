java -jar getLatinTag.jar vn vi "yêng" 1000  keyword_vi.txt
java -jar getLatinTag.jar vn vi "Kiêu" 1000  keyword_vi.txt
java -jar getLatinTag.jar vn vi "Yêu" 1000  keyword_vi.txt
java -jar getLatinTag.jar vn vi "yểu" 1000  keyword_vi.txt
