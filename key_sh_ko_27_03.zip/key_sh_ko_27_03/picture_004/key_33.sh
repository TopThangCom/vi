java -jar getLatinTag.jar kr ko "租" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "琴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "號" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "乙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "醇" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "矛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盾" 1000  keyword_ko.txt
