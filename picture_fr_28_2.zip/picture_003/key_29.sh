java -jar getLatinTag.jar kr kr "국어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일본어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "중국어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메인" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "블로그" 1000  keyword_kr.txt
