java -jar getLatinTag.jar kr ko "枝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "젓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뻥" 1000  keyword_ko.txt
