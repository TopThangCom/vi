java -jar getLatinTag.jar it it "modellismo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tremezzo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquafert" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "comune" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cosenza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "italie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquafredda" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquafun" 1000  keyword_it.txt
