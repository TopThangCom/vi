java -jar getLatinTag.jar it it "azcona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "boscamping" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disparition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disparus" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "boscolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recliner" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scaler" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "altitudine" 1000  keyword_it.txt
