java -jar getLatinTag.jar it it "principales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intimate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clt" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "correta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mamografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dipirona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "absorvente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "silicone" 1000  keyword_it.txt
