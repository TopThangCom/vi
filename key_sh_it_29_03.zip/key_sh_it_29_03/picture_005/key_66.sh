java -jar getLatinTag.jar it it "bantoid" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copag" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bardonecchia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "baritato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "barmontcat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cattery" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aneroide" 1000  keyword_it.txt
