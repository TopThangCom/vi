java -jar getLatinTag.jar kr kr "有名" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "曲紹介" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "曲名" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英語曲" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "和訳" 1000  keyword_kr.txt
