java -jar getLatinTag.jar it it "dial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alimentarias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sonion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "goccia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scava" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piezometrica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "danza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caligrafia" 1000  keyword_it.txt
