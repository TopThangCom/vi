java -jar getLatinTag.jar it it "ampelita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fibreglass" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampelografia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aconitifolia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cordata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grossedentata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cellars" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampere" 1000  keyword_it.txt
