java -jar getLatinTag.jar fr  fr "difficiles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'entrée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mettent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pierre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "proches" 1000  keyword_fr.txt
