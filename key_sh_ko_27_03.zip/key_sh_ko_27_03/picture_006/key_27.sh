java -jar getLatinTag.jar kr ko "凡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퀵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "甄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "雕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嵌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "邊" 1000  keyword_ko.txt
