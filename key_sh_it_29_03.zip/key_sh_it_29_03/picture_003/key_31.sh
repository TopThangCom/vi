java -jar getLatinTag.jar it it "appliances" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "biblioteca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "codogno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scuola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ambrotipia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "franco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lunel" 1000  keyword_it.txt
