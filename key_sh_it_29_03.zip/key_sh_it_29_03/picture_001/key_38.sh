java -jar getLatinTag.jar it it "acquazzurra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discount" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquistandola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquistandoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquistandolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acquolina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acrasia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acrasiales" 1000  keyword_it.txt
