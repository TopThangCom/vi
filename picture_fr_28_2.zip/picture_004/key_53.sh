java -jar getLatinTag.jar kr kr "매수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "매도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "바꾸기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "편집기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "찾아" 1000  keyword_kr.txt
