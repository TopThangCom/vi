java -jar getLatinTag.jar kr kr "이용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가능합니다" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "처벌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "해부도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마우스" 1000  keyword_kr.txt
