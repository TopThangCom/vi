java -jar getLatinTag.jar it it "intranet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scam" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addmvccore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addcontrollers" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "addrazorpages" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anatomia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gonfio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "straniante" 1000  keyword_it.txt
