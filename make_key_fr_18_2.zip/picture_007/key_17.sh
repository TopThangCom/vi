java -jar getLatinTag.jar fr  fr "oui" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "éditions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Daniel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "utilisée" 1000  keyword_fr.txt
