java -jar getLatinTag.jar it it "scan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "xilitol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "psicologico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atopic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dermatitis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "allo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "specchio" 1000  keyword_it.txt
