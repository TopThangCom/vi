java -jar getLatinTag.jar kr kr "虎牌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "swot" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "예시" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개인" 1000  keyword_kr.txt
