java -jar getLatinTag.jar kr ko "더" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "틴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "통" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "계" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "비" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "속" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "말" 1000  keyword_ko.txt
