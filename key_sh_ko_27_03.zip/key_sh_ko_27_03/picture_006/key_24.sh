java -jar getLatinTag.jar kr ko "笨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "飾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "樊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "攀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渥" 1000  keyword_ko.txt
