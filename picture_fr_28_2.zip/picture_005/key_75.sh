java -jar getLatinTag.jar kr kr "確認方法" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "etc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뜻과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "肌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "英語表現" 1000  keyword_kr.txt
