java -jar getLatinTag.jar kr ko "丹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "簪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "屯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "碎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "咨" 1000  keyword_ko.txt
