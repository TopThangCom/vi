java -jar getLatinTag.jar fr  fr "parents" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'une" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fond" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "capacité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vitesse" 1000  keyword_fr.txt
