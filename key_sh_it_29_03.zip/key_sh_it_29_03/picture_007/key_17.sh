java -jar getLatinTag.jar it it "cameponato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camepp" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cameranordic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "competition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "letto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "financiari" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camerette" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camerich" 1000  keyword_it.txt
