java -jar getLatinTag.jar kr kr "bcp訓練" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "種類" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "爱情" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "保卫" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "战" 1000  keyword_kr.txt
