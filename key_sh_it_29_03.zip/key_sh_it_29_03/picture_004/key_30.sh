java -jar getLatinTag.jar it it "capi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "signos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calcolo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discendenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "definizione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "privilegiati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legittimi" 1000  keyword_it.txt
