java -jar getLatinTag.jar fr  fr "resté" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sinon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "agence" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fini" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "modifications" 1000  keyword_fr.txt
