java -jar getLatinTag.jar kr ko "蔓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "扁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "泵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "콥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "눔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坦" 1000  keyword_ko.txt
