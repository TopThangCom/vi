java -jar getLatinTag.jar it it "rosato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gatti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampelio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abdita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cristata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tenuicornis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chinito" 1000  keyword_it.txt
