java -jar getLatinTag.jar it it "apascovi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conalep" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ecuatoriano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conflitos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apcomin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apcosil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alcossebre" 1000  keyword_it.txt
