java -jar getLatinTag.jar kr ko "甬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "肆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "榜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "麴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "裂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "桂" 1000  keyword_ko.txt
