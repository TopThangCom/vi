java -jar getLatinTag.jar fr  fr "santé" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "New" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pense" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bénéfices" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "but" 1000  keyword_fr.txt
