java -jar getLatinTag.jar it it "monteriggioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "livescore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "citron" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "composition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calenzano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scutellaria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "baicalina" 1000  keyword_it.txt
