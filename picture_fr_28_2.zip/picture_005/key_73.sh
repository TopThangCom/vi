java -jar getLatinTag.jar kr kr "喜名" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "沖縄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "地名" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "沖縄県" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "読谷村" 1000  keyword_kr.txt
