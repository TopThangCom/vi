java -jar getLatinTag.jar fr  fr "clair" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "biens" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "euro" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "York" 1000  keyword_fr.txt
