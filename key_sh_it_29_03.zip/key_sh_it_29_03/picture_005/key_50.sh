java -jar getLatinTag.jar it it "gli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorbate" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorbic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "potassio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sodium" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascorbosilane" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascore" 1000  keyword_it.txt
