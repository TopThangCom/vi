java -jar getLatinTag.jar kr kr "閉鎖病棟" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "宇治" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "皮膚科" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "予約" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pcr" 1000  keyword_kr.txt
