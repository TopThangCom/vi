java -jar getLatinTag.jar it it "cittadella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nervi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassanese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ionio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contenitore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassapoint" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cassapo" 1000  keyword_it.txt
