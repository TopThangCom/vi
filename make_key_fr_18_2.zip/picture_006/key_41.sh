java -jar getLatinTag.jar fr  fr "lit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "volatilité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "étape" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "assurance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jusqu'en" 1000  keyword_fr.txt
