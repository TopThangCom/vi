java -jar getLatinTag.jar fr  fr "cadre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sens" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "étaient" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sécurité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "recherche" 1000  keyword_fr.txt
