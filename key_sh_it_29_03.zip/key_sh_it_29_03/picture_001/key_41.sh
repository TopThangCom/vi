java -jar getLatinTag.jar it it "laceration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrasivato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrasiveness" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alpe" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alicante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conversiones" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agricole" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "simon" 1000  keyword_it.txt
