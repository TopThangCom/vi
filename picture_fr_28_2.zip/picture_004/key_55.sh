java -jar getLatinTag.jar kr kr "설치ᆞ운용기준" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "케이블" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "이중화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "콘센트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "一覧" 1000  keyword_kr.txt
