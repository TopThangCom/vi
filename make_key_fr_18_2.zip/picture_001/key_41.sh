java -jar getLatinTag.jar fr  fr "client" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "activités" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "eu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "environ" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ministre" 1000  keyword_fr.txt
