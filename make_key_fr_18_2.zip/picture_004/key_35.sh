java -jar getLatinTag.jar fr  fr "faits" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "retard" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "certes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'air" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lundi" 1000  keyword_fr.txt
