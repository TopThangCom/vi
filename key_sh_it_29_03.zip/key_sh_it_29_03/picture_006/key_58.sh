java -jar getLatinTag.jar it it "cibil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fabio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caiomete" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caipira" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "proloco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "silent" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caivan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caivano" 1000  keyword_it.txt
