java -jar getLatinTag.jar kr ko "톡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "原" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "之" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "夜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "唱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "郎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伴" 1000  keyword_ko.txt
