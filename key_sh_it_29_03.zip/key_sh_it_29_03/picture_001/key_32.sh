java -jar getLatinTag.jar it it "sparta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sovieticos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scba" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guitarra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "certo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "municipality" 1000  keyword_it.txt
