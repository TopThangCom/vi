java -jar getLatinTag.jar kr kr "라즈키즈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "코리아" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "라즈키즈플러스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "라즈키즈az" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무료체험" 1000  keyword_kr.txt
