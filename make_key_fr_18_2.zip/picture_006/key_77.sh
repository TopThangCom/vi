java -jar getLatinTag.jar fr  fr "plastique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rarement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Royal" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "affiché" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lutte" 1000  keyword_fr.txt
