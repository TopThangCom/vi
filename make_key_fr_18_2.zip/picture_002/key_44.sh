java -jar getLatinTag.jar fr  fr "presque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Michel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "manque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réaliser" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "financiers" 1000  keyword_fr.txt
