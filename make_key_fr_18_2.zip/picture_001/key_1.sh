java -jar getLatinTag.jar fr  fr "seront" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "économique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "raison" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "car" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "situation" 1000  keyword_fr.txt
