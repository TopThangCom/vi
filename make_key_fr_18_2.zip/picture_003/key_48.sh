java -jar getLatinTag.jar fr  fr "contact" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "époque" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rythme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "principaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vendu" 1000  keyword_fr.txt
