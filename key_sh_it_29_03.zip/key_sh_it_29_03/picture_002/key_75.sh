java -jar getLatinTag.jar it it "vicente" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cannonier" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petropolis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "reato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adescatore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adescatori" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colegio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "itabirito" 1000  keyword_it.txt
