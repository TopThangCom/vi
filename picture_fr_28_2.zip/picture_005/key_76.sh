java -jar getLatinTag.jar kr kr "見分け方" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "電気代" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "明るさ" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "消費電力" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "発光原理" 1000  keyword_kr.txt
