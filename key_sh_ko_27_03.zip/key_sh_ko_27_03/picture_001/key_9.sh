java -jar getLatinTag.jar kr ko "機" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "車" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "固" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "定" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "式" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "交" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "流" 1000  keyword_ko.txt
