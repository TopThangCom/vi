java -jar getLatinTag.jar kr ko "앱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "알" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "옴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "문" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "깨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "양" 1000  keyword_ko.txt
