java -jar getLatinTag.jar kr kr "yzf" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "docs" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "취소선" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "분할" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "小杨生煎" 1000  keyword_kr.txt
