java -jar getLatinTag.jar kr ko "某" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "俄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "束" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "茨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嗎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "譜" 1000  keyword_ko.txt
