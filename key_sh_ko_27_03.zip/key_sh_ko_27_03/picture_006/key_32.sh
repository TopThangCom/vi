java -jar getLatinTag.jar kr ko "慢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鞍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "垂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "銃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "柬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "寨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "炬" 1000  keyword_ko.txt
