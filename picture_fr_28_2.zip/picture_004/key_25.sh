java -jar getLatinTag.jar kr kr "편향" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "알고리즘의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "개념과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "특징" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "문제점" 1000  keyword_kr.txt
