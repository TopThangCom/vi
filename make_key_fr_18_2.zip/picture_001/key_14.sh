java -jar getLatinTag.jar fr  fr "direction" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Sur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "simple" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "période" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "enfants" 1000  keyword_fr.txt
