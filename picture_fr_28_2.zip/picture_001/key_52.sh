java -jar getLatinTag.jar kr kr "티어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "추천" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인구수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "직업군" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "직업추천" 1000  keyword_kr.txt
