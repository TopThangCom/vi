java -jar getLatinTag.jar fr  fr "celui" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "qualité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "France" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ils" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ces" 1000  keyword_fr.txt
