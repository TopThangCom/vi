java -jar getLatinTag.jar it it "certification" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abcidiag" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abcomm" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "communication" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "support" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abcosc" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abcosting" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "citations" 1000  keyword_it.txt
