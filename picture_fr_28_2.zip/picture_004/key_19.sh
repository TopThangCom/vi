java -jar getLatinTag.jar kr kr "구로역" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "근황" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실시간" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "폭락" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "소프트" 1000  keyword_kr.txt
