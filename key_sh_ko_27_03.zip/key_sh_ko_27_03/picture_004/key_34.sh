java -jar getLatinTag.jar kr ko "놘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퉥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "픯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "굼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뇸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "풰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퇄" 1000  keyword_ko.txt
