java -jar getLatinTag.jar fr  fr "défense" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'ancienne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "magazine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "D'un" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Y" 1000  keyword_fr.txt
