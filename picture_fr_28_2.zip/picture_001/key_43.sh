java -jar getLatinTag.jar kr kr "프로그램" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "결혼" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발송취소" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "상대방" 1000  keyword_kr.txt
