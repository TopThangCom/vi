java -jar getLatinTag.jar kr ko "聞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "回" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "就" 1000  keyword_ko.txt
