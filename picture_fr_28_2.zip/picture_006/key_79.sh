java -jar getLatinTag.jar kr kr "싫어요" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "하지마세요" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "돼요" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안돼요안돼" 1000  keyword_kr.txt
