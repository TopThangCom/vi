java -jar getLatinTag.jar kr kr "이모티콘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "방문자" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "로고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수익" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "복사" 1000  keyword_kr.txt
