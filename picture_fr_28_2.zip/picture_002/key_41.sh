java -jar getLatinTag.jar kr kr "山下" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "山下良美" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "葵屋" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "赤外線送信" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "阿里小号(阿里小号)" 1000  keyword_kr.txt
