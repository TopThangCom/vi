java -jar getLatinTag.jar it it "rossell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fotolia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caliginoso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "finas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "callhim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calligraphie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "isola" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "calmanordica" 1000  keyword_it.txt
