java -jar getLatinTag.jar fr  fr "vendre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "juillet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mai" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "région" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "sociale" 1000  keyword_fr.txt
