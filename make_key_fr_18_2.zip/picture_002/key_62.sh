java -jar getLatinTag.jar fr  fr "difficile" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "autour" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "européen" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pratique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "centre" 1000  keyword_fr.txt
