java -jar getLatinTag.jar fr  fr "dollars" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "personnel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "assez" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "programme" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "général" 1000  keyword_fr.txt
