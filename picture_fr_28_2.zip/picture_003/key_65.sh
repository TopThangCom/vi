java -jar getLatinTag.jar kr kr "별" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발음기호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "네이버스포츠" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "야구" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "농구" 1000  keyword_kr.txt
