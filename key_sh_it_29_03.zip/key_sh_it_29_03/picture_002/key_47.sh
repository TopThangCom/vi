java -jar getLatinTag.jar it it "maggioli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sororitas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arbites" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "consideration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adequation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "additive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "relativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "glass" 1000  keyword_it.txt
