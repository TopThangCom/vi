java -jar getLatinTag.jar kr ko "妃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "痘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鉛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "앗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挑" 1000  keyword_ko.txt
