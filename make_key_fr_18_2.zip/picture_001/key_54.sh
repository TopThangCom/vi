java -jar getLatinTag.jar fr  fr "deux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "A" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ans" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "encore" 1000  keyword_fr.txt
