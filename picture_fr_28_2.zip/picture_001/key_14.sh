java -jar getLatinTag.jar kr kr "방향" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "발전가능성" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "amd" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "성능" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메인보드" 1000  keyword_kr.txt
