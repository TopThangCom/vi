java -jar getLatinTag.jar kr ko "潼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "땡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "듄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "菁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "玲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挪" 1000  keyword_ko.txt
