java -jar getLatinTag.jar kr ko "秤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "財" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "憶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "孔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "斷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "腫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "幻" 1000  keyword_ko.txt
