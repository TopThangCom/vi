java -jar getLatinTag.jar kr ko "専" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "門" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "叱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "李" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "縫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "娘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "託" 1000  keyword_ko.txt
