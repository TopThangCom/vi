java -jar getLatinTag.jar it it "rezzato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricomarche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricomatkelly" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capparuccia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grottazzolina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "capbreton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "briconeo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "briconet" 1000  keyword_it.txt
