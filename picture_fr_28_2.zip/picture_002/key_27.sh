java -jar getLatinTag.jar kr kr "새벽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "끊김" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모뎀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "브로드밴드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "갑자기" 1000  keyword_kr.txt
