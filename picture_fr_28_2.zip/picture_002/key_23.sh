java -jar getLatinTag.jar kr kr "추적" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제한" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "추적하는" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주소로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "서버" 1000  keyword_kr.txt
