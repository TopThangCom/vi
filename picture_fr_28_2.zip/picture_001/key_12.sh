java -jar getLatinTag.jar kr kr "길티기어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "콤보" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스트라이브" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나이" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "모으기" 1000  keyword_kr.txt
