java -jar getLatinTag.jar kr kr "내장그래픽" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "쿨러" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인텔" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "(버미어)" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "(정품)" 1000  keyword_kr.txt
