java -jar getLatinTag.jar kr ko "歩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "義" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "朱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "篇" 1000  keyword_ko.txt
