java -jar getLatinTag.jar it it "torricelli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dinamica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "statica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "paralel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "speciale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "maionese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tapioca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "retiro" 1000  keyword_it.txt
