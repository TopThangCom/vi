java -jar getLatinTag.jar kr kr "取扱説明書" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kl" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "n" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "prime" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "牛排館" 1000  keyword_kr.txt
