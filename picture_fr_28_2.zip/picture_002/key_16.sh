java -jar getLatinTag.jar kr kr "外中全家" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "外" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "中" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "成語" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "검색" 1000  keyword_kr.txt
