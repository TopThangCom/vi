java -jar getLatinTag.jar kr kr "걸기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "간판" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제작" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "조명" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "LED" 1000  keyword_kr.txt
