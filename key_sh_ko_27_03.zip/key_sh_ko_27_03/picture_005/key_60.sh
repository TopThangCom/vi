java -jar getLatinTag.jar kr ko "臟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "會" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "甘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "儀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "臉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쉘" 1000  keyword_ko.txt
