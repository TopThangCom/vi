java -jar getLatinTag.jar kr kr "小学校" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "学校図書" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "台風" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "飛利浦美體除毛刀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "木兰之巾帼英豪" 1000  keyword_kr.txt
