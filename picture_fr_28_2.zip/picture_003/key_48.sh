java -jar getLatinTag.jar kr kr "空即是色" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "下一句" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kk音标表下载" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kk音标表母音" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kk音标发音位置" 1000  keyword_kr.txt
