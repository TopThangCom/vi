java -jar getLatinTag.jar it it "amecon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cioccolato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "modigliani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "desiccants" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amelcorn" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cantora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ameliorate" 1000  keyword_it.txt
