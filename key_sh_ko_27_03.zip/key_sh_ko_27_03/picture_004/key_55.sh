java -jar getLatinTag.jar kr ko "犀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "耀" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "捷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掌" 1000  keyword_ko.txt
