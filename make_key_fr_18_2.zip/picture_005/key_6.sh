java -jar getLatinTag.jar fr  fr "diminuer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chercher" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bonheur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dizaines" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "LE" 1000  keyword_fr.txt
