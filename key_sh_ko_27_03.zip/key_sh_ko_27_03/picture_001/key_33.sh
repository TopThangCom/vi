java -jar getLatinTag.jar kr ko "及" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "直" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "導" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "供" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "系" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "統" 1000  keyword_ko.txt
