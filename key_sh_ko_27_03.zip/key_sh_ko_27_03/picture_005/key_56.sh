java -jar getLatinTag.jar kr ko "臂" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "悉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "挿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "逐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "杆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隙" 1000  keyword_ko.txt
