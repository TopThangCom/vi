java -jar getLatinTag.jar it it "togliani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "dallas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "condition" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotrim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mosconi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pellacani" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scipioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stromaggregate" 1000  keyword_it.txt
