java -jar getLatinTag.jar fr  fr "Néanmoins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "conduit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mille" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rénovation" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "égard" 1000  keyword_fr.txt
