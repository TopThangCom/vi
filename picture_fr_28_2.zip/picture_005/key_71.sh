java -jar getLatinTag.jar kr kr "프리웨어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "jpg" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인쇄" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "엑셀" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파워포인트" 1000  keyword_kr.txt
