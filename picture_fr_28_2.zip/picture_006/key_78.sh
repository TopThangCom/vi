java -jar getLatinTag.jar kr kr "mvp" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "KBO" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "MVP" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가족" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "결제" 1000  keyword_kr.txt
