java -jar getLatinTag.jar kr kr "在水里写字" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "while문" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "탈출" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "倒三輪電動代步車" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "日立" 1000  keyword_kr.txt
