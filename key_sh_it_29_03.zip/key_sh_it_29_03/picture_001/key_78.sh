java -jar getLatinTag.jar it it "icon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "glutarica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "metilmalonica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "propionica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "respiratoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acidissiminin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "noticias" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "frutales" 1000  keyword_it.txt
