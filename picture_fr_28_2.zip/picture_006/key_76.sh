java -jar getLatinTag.jar kr kr "정지" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pc화면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다크모드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사이트로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "보는법" 1000  keyword_kr.txt
