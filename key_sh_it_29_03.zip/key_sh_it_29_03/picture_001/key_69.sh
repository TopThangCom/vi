java -jar getLatinTag.jar it it "ne" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "diamond" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abimael" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corona" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abismante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abissal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "origin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "origine" 1000  keyword_it.txt
