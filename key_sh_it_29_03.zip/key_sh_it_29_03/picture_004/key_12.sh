java -jar getLatinTag.jar it it "riassunto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fascismo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "napoleone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascese" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascesso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carpetas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "catolicos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asceticism" 1000  keyword_it.txt
