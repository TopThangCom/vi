java -jar getLatinTag.jar fr  fr "budgétaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "croit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mises" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "souci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "contient" 1000  keyword_fr.txt
