java -jar getLatinTag.jar kr ko "陳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鮮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "潮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瀑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "汗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "坑" 1000  keyword_ko.txt
