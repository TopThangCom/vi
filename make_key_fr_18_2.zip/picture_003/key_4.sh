java -jar getLatinTag.jar fr  fr "Tous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "texte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tenu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "budget" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'étranger" 1000  keyword_fr.txt
