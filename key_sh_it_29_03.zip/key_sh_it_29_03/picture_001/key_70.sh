java -jar getLatinTag.jar it it "login" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lincler" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "argentina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fisioterapia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrafito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abrafoton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "lincoln" 1000  keyword_it.txt
