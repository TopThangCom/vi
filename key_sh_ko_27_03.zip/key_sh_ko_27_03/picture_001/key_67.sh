java -jar getLatinTag.jar kr ko "最" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "新" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "딧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "불" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "묘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "막" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "빙" 1000  keyword_ko.txt
