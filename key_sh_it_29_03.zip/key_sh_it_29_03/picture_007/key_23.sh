java -jar getLatinTag.jar it it "canvassing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giron" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "caodainet" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cancelleria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "villorba" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "impianti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mppr" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guattari" 1000  keyword_it.txt
