java -jar getLatinTag.jar fr  fr "Reste" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "return" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jardin" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'espace" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "flamand" 1000  keyword_fr.txt
