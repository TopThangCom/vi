java -jar getLatinTag.jar fr  fr "Pays-Bas" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cher" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "chacun" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "techniques" 1000  keyword_fr.txt
