java -jar getLatinTag.jar kr kr "교사계정" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "레벨테스트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "日本分光" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "kggb" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사우디" 1000  keyword_kr.txt
