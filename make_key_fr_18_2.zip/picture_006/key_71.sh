java -jar getLatinTag.jar fr  fr "comparaison" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "déterminer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "firmes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fournisseur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "informatiques" 1000  keyword_fr.txt
