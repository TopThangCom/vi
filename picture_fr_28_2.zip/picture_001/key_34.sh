java -jar getLatinTag.jar kr kr "脑叶公司" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "로보토미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "腦葉公司" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "거미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "일러스트" 1000  keyword_kr.txt
