java -jar getLatinTag.jar it it "cuantitativo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "clarinete" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricoma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "terminale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "termoli" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montepulciano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "molfetta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sirolo" 1000  keyword_it.txt
