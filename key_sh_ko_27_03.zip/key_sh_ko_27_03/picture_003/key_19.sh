java -jar getLatinTag.jar kr ko "將" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "需" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "層" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "由" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "而" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "菅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "暉" 1000  keyword_ko.txt
