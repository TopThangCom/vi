java -jar getLatinTag.jar kr ko "忽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鴉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "滷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "贏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "陷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "驚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "盎" 1000  keyword_ko.txt
