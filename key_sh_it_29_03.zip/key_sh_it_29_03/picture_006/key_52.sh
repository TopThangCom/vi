java -jar getLatinTag.jar it it "tratament" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carmichael" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sicilian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brontolone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brontoscorpio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fulton" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "parafina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "statue" 1000  keyword_it.txt
