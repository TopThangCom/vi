java -jar getLatinTag.jar fr  fr "management" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "proche" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "collection" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fiscale" 1000  keyword_fr.txt
