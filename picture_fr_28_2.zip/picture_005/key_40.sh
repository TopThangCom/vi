java -jar getLatinTag.jar kr kr "-" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "온라인에서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "무료로" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "피디에프" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "압축" 1000  keyword_kr.txt
