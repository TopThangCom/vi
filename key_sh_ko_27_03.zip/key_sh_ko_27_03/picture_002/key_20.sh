java -jar getLatinTag.jar kr ko "秦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "乾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "골" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "탬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "홈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "튼" 1000  keyword_ko.txt
