java -jar getLatinTag.jar fr  fr "s'en" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mon" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "premiers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bas" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "marque" 1000  keyword_fr.txt
