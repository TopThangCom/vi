java -jar getLatinTag.jar fr  fr "émis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Quelques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "comportement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "limité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vingt" 1000  keyword_fr.txt
