java -jar getLatinTag.jar kr ko "廖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "楞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "묶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蝴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "撲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沛" 1000  keyword_ko.txt
