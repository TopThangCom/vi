java -jar getLatinTag.jar fr  fr "l'importance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "proposer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "x" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "augmenter" 1000  keyword_fr.txt
