java -jar getLatinTag.jar kr ko "咳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "划" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "泥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "兩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鬍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "拿" 1000  keyword_ko.txt
