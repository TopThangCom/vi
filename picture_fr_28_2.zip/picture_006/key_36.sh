java -jar getLatinTag.jar kr kr "생각없어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "gif" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안바꿔줘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "드립" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판사님" 1000  keyword_kr.txt
