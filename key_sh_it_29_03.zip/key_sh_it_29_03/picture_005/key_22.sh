java -jar getLatinTag.jar it it "petrolina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assemprel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assendorperzotten" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "individual" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "incra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assercar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legislativo" 1000  keyword_it.txt
