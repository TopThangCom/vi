java -jar getLatinTag.jar kr kr "水球" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田邦彦" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "公式" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "硬化時間" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "無視" 1000  keyword_kr.txt
