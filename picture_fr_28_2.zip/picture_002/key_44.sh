java -jar getLatinTag.jar kr kr "正確" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "仕組み" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "住所特定" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "犯罪" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "情報開示" 1000  keyword_kr.txt
