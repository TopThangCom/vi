java -jar getLatinTag.jar it it "ccir" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carioca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cavo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "altavoces" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tropez" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocamper" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "autocamping" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "collision" 1000  keyword_it.txt
