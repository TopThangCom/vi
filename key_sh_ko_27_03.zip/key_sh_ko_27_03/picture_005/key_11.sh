java -jar getLatinTag.jar kr ko "私" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "募" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "倉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "踩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "煞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "奔" 1000  keyword_ko.txt
