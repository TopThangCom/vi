java -jar getLatinTag.jar kr kr "草原之夜原唱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "草原之夜简谱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "草原之夜原唱者" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "草原之夜歌谱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "刀郎" 1000  keyword_kr.txt
