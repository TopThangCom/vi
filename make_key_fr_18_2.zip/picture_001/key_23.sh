java -jar getLatinTag.jar fr  fr "je" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "n'a" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Nous" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Cette" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dernier" 1000  keyword_fr.txt
