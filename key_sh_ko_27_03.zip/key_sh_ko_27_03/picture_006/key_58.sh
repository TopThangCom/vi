java -jar getLatinTag.jar kr ko "慰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "琅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "渣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "亨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "傑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "豐" 1000  keyword_ko.txt
