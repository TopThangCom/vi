java -jar getLatinTag.jar kr ko "죠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "旨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뎁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "짚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "迄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "乞" 1000  keyword_ko.txt
