java -jar getLatinTag.jar it it "tarifas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquavall" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquavallon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "petrol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "estrella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vallarta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquaviario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "reservatorios" 1000  keyword_it.txt
