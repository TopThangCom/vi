java -jar getLatinTag.jar it it "anteriores" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "signore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sattrac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adichie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "legion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "poll" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mattress" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disabilities" 1000  keyword_it.txt
