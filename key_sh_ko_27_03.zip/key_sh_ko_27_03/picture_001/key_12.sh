java -jar getLatinTag.jar kr ko "港" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "文" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "憑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "試" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "招" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "生" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "錄" 1000  keyword_ko.txt
