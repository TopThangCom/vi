java -jar getLatinTag.jar fr  fr "productivité" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Résultat" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "améliorer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'obtenir" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "joué" 1000  keyword_fr.txt
