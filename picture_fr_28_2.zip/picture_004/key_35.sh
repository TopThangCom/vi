java -jar getLatinTag.jar kr kr "시각화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "딥러닝이란" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "멀티모달" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "알고리즘" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "예제" 1000  keyword_kr.txt
