java -jar getLatinTag.jar it it "dipivoxil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contrato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contrattuali" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "affitti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pensioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assegno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mantenimento" 1000  keyword_it.txt
