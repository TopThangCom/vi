java -jar getLatinTag.jar fr  fr "réels" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "échange" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "florins" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'accord" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "terrains" 1000  keyword_fr.txt
