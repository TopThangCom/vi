java -jar getLatinTag.jar fr  fr "matériaux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ordinateurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tradition" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "V" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "progressivement" 1000  keyword_fr.txt
