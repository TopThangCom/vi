java -jar getLatinTag.jar fr  fr "montrer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mérite" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "places" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Soit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "judiciaire" 1000  keyword_fr.txt
