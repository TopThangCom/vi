java -jar getLatinTag.jar it it "amenoseseragi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amentesveglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amenti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amentoflavone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mentor" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amentoria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amentotech" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costpoint" 1000  keyword_it.txt
