java -jar getLatinTag.jar it it "bittrex" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "buontempone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "buontemponi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "riposo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "parrocchia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "corsica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rig" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "musicale" 1000  keyword_it.txt
