java -jar getLatinTag.jar kr ko "測" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "後" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "視" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鏡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "觸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "控" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "紀" 1000  keyword_ko.txt
