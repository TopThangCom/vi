java -jar getLatinTag.jar fr  fr "Américains" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "exercice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'étude" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "s'impose" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avance" 1000  keyword_fr.txt
