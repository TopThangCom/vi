java -jar getLatinTag.jar fr  fr "indique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "information" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lourd" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "signal" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ed" 1000  keyword_fr.txt
