java -jar getLatinTag.jar kr ko "게" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "침" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "殼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "炭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "濾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "綿" 1000  keyword_ko.txt
