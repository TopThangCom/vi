java -jar getLatinTag.jar it it "amministratore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mario" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "significato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ristorante" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vicenza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cornell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sardegna" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abbraccio" 1000  keyword_it.txt
