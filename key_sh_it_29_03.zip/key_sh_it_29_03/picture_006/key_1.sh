java -jar getLatinTag.jar it it "bitopro" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitosen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitossi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ceramiche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "constantine" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitportis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bituach" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alella" 1000  keyword_it.txt
