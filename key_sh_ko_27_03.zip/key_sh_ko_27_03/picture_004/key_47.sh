java -jar getLatinTag.jar kr ko "옱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "줸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "밨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뙥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "沒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "這" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "些" 1000  keyword_ko.txt
