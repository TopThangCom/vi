java -jar getLatinTag.jar kr kr "접속" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주소를" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가져올" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "수" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "iptime" 1000  keyword_kr.txt
