java -jar getLatinTag.jar kr ko "연" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "결" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "公" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "司" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "로" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "보" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "토" 1000  keyword_ko.txt
