java -jar getLatinTag.jar it it "association" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assocompliance" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assocompol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assocompositi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assocomunicazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "avvocati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regionale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "truffa" 1000  keyword_it.txt
