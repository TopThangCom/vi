java -jar getLatinTag.jar kr kr "트위치티비갤" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "트위치티비비" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주르르" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다운로드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "랄로" 1000  keyword_kr.txt
