java -jar getLatinTag.jar it it "sociologist" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rivelles" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampcit" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampcoloy" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampcontrol" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ampelcontrolling" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ribbon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bianco" 1000  keyword_it.txt
