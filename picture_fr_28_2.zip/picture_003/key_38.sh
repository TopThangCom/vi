java -jar getLatinTag.jar kr kr "里咲" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "semi" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미리캔버스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ppt" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불러오기" 1000  keyword_kr.txt
