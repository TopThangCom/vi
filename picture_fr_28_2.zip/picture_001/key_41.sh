java -jar getLatinTag.jar kr kr "lck" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뚫기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "기간" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사라짐" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "복구" 1000  keyword_kr.txt
