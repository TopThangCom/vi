java -jar getLatinTag.jar kr kr "규제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "동향과" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "시사점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정책동향" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "정책" 1000  keyword_kr.txt
