java -jar getLatinTag.jar fr  fr "actionnaire" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prennent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "résistance" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Dow" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "II" 1000  keyword_fr.txt
