java -jar getLatinTag.jar it it "parto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assorbenza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "atomico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intestinale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "costi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "assorbitore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "insetto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "silenzio" 1000  keyword_it.txt
