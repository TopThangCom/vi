java -jar getLatinTag.jar it it "anodontia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "magnesio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anodot" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "claessen" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "congenitas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "utileria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "geneticas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anomalocaris" 1000  keyword_it.txt
