java -jar getLatinTag.jar kr ko "係" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "彩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "校" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "塾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "不" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "祥" 1000  keyword_ko.txt
