java -jar getLatinTag.jar it it "adressat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adressaten" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adresserat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "adretone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cat" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "colmar" 1000  keyword_it.txt
