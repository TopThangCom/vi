java -jar getLatinTag.jar kr kr "胡锡进微博" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "疫苗" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "想要有直升机" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "平成" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "年" 1000  keyword_kr.txt
