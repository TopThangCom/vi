java -jar getLatinTag.jar it it "bricotodogestion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cotentin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bridallive" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bridion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gonzalez" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brignacca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scottdale" 1000  keyword_it.txt
