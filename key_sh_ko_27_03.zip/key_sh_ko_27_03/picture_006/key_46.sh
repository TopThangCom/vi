java -jar getLatinTag.jar kr ko "빼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "샥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "俗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쿤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蹈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쌤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "謡" 1000  keyword_ko.txt
