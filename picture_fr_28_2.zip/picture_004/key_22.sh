java -jar getLatinTag.jar kr kr "전형" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "진행중" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인터넷전화" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "전화기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스마트폰" 1000  keyword_kr.txt
