java -jar getLatinTag.jar kr ko "先" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "二" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "象" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瓶" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "洗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "庁" 1000  keyword_ko.txt
