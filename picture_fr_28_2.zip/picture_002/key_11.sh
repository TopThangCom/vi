java -jar getLatinTag.jar kr kr "시간표" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "질병코드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "버스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "skt" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사전예약" 1000  keyword_kr.txt
