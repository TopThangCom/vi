java -jar getLatinTag.jar it it "amocon" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "congress" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amodeivisual" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amodeopatricia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amodil" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amodimethicone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amodio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amodip" 1000  keyword_it.txt
