java -jar getLatinTag.jar it it "aquadipper" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discovery" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coral" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ricarica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chemical" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cinderella" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aquadropper" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "recensioni" 1000  keyword_it.txt
