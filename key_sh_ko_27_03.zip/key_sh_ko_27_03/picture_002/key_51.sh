java -jar getLatinTag.jar kr ko "꾸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "啟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "區" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "綱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "圖" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "燕" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "星" 1000  keyword_ko.txt
