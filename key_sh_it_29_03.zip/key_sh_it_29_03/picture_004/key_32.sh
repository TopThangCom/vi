java -jar getLatinTag.jar it it "arteriors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arteriosclerosis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arteriovenosas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "arteriovenoso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artesanato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cooperativa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bosco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "artesegno" 1000  keyword_it.txt
