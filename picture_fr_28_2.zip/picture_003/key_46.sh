java -jar getLatinTag.jar kr kr "덫" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "실험" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "치즈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뭐야" 1000  keyword_kr.txt
