java -jar getLatinTag.jar kr kr "주식" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주식용" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "배당" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사는법" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ey" 1000  keyword_kr.txt
