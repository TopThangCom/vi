java -jar getLatinTag.jar kr ko "抹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "楷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "暈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "弛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戾" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喚" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "꼴" 1000  keyword_ko.txt
