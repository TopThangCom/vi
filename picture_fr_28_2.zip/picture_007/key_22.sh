java -jar getLatinTag.jar kr kr "stay" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "안면" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "마비" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "baby" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "KS" 1000  keyword_kr.txt
