java -jar getLatinTag.jar kr kr "٦×٦=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "٦×٦+٦÷٦-١=" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "eea.gd.gov.cn" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "報名報考" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "香港文憑試招生" 1000  keyword_kr.txt
