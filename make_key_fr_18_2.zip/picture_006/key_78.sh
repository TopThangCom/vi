java -jar getLatinTag.jar fr  fr "l'ont" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "définitivement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "humain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "optique" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "remarque" 1000  keyword_fr.txt
