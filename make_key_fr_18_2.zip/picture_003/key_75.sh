java -jar getLatinTag.jar fr  fr "travailleurs" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "joue" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "objectif" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "salle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parle" 1000  keyword_fr.txt
