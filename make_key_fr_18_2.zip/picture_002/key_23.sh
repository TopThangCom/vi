java -jar getLatinTag.jar fr  fr "belle" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lequel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tél" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "seconde" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "version" 1000  keyword_fr.txt
