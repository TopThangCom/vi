java -jar getLatinTag.jar kr ko "·" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "隔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "巧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "扣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "促" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鞋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "童" 1000  keyword_ko.txt
