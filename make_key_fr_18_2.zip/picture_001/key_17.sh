java -jar getLatinTag.jar fr  fr "seule" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "rendement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nombreux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fonction" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "offre" 1000  keyword_fr.txt
