java -jar getLatinTag.jar fr  fr "l'assureur" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tourne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ajoute" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bancaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ajouter" 1000  keyword_fr.txt
