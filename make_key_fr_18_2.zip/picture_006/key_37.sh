java -jar getLatinTag.jar fr  fr "remise" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "structures" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tenter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "accords" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cotisations" 1000  keyword_fr.txt
