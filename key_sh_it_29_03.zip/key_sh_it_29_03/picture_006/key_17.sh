java -jar getLatinTag.jar it it "cancerogeno" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioxcell" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioxcellence" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bioxcellerator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "regime" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "stanz" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "conic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pcc" 1000  keyword_it.txt
