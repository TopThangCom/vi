java -jar getLatinTag.jar fr  fr "banques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "eux" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "semaine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "président" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "personne" 1000  keyword_fr.txt
