java -jar getLatinTag.jar fr  fr "Cockerill" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lendemain" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cent" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gagné" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "japonais" 1000  keyword_fr.txt
