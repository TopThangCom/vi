java -jar getLatinTag.jar it it "fusca" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carcasses" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "carcoma" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardaillac" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardalis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cogent" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardassian" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cardassianer" 1000  keyword_it.txt
