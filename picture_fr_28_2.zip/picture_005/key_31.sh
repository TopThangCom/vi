java -jar getLatinTag.jar kr kr "아두이노" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "번역" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "파파고" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "클리앙" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "구글" 1000  keyword_kr.txt
