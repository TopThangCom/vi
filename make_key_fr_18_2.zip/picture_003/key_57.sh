java -jar getLatinTag.jar fr  fr "poids" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "celle-ci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commercial" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entendu" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "l'investisseur" 1000  keyword_fr.txt
