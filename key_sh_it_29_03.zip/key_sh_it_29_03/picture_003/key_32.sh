java -jar getLatinTag.jar it it "trator" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "baltimore" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoraeville" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amorale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoralia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoralistic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amoralle" 1000  keyword_it.txt
