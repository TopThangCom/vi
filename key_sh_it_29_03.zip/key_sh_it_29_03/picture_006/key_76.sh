java -jar getLatinTag.jar it it "stato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "giletti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "innamorato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pentito" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scandiano" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "boicottaggio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "boicottare" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inferiores" 1000  keyword_it.txt
