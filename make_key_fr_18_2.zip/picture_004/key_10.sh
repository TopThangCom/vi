java -jar getLatinTag.jar fr  fr "warrant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fabrication" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "redressement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suffisamment" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "délégué" 1000  keyword_fr.txt
