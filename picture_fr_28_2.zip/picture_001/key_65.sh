java -jar getLatinTag.jar kr kr "결말" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "깊은" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영혼의" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "여명" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이드복" 1000  keyword_kr.txt
