java -jar getLatinTag.jar it it "brinzolamide" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brioche" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brioni" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "brion" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tuscan" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "briscope" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "patrizio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "britannica" 1000  keyword_it.txt
