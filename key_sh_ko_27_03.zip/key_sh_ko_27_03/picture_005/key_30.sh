java -jar getLatinTag.jar kr ko "邵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "暦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "宙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "疲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "轉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "徑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鷺" 1000  keyword_ko.txt
