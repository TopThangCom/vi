java -jar getLatinTag.jar kr ko "芋" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "芳" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "跨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "軟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "辛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "殿" 1000  keyword_ko.txt
