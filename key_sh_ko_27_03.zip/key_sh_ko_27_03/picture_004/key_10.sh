java -jar getLatinTag.jar kr ko "靈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "総" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "答" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "栗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "浜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "釣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "遊" 1000  keyword_ko.txt
