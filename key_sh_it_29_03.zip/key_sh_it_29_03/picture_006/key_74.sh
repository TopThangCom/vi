java -jar getLatinTag.jar it it "briconorte" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricoportale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricoporto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "montargis" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricosergio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bitonto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricostock" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bricostore" 1000  keyword_it.txt
