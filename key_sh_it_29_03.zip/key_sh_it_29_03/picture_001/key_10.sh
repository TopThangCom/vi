java -jar getLatinTag.jar it it "addentrato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "competitors" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "pricing" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "commerciale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "financial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "itri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ri" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "piacenza" 1000  keyword_it.txt
