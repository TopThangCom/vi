java -jar getLatinTag.jar fr  fr "Allemagne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "parler" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "propos" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "quant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "signifie" 1000  keyword_fr.txt
