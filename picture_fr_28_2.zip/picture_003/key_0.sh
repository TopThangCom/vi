java -jar getLatinTag.jar kr kr "단어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "영어이름" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "표기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다리에" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "mvoip" 1000  keyword_kr.txt
