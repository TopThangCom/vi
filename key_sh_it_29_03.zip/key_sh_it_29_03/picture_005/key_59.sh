java -jar getLatinTag.jar it it "aspone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cistifellea" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "tiroide" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "migliorie" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asportato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asportazione" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vescica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rifiuti" 1000  keyword_it.txt
