java -jar getLatinTag.jar kr kr "후이즈" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "디시" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "내" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "주소" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "cmd" 1000  keyword_kr.txt
