java -jar getLatinTag.jar fr  fr "interne" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pleine" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "passant" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "vision" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "GSM" 1000  keyword_fr.txt
