java -jar getLatinTag.jar fr  fr "industriel" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "précompte" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'Europe" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "immédiatement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avantage" 1000  keyword_fr.txt
