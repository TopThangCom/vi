java -jar getLatinTag.jar kr kr "jis" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "l" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "繊維製品の物理試験方法通則" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "赤外線通信" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "電話帳" 1000  keyword_kr.txt
