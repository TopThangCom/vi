java -jar getLatinTag.jar it it "patrimonial" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aseguranza" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aromantico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "asessuato" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scrapers" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inspiration" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "glideride" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "scacchi" 1000  keyword_it.txt
