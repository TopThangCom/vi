java -jar getLatinTag.jar it it "bancomatico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "intesa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "monteria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "matogrosso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "burigotto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "acessivel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "apoiam" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nationale" 1000  keyword_it.txt
