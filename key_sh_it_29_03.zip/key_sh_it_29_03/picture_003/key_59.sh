java -jar getLatinTag.jar it it "notificacao" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antirabic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vaccin" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ressono" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "uccle" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antirosolia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "rosolia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "bicicleta" 1000  keyword_it.txt
