java -jar getLatinTag.jar kr ko "牒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쌓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "蕨" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "竿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "堤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "씬" 1000  keyword_ko.txt
