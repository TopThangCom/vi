java -jar getLatinTag.jar it it "anconatoday" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancora" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ancorassieme" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "camioneta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "grammaticale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "andessimo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "guitars" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "andescol" 1000  keyword_it.txt
