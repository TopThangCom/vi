java -jar getLatinTag.jar fr  fr "statut" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "USA" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "ceci" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "destiné" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "défaut" 1000  keyword_fr.txt
