java -jar getLatinTag.jar fr  fr "chambre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "portée" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "réflexion" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "AG" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "C'était" 1000  keyword_fr.txt
