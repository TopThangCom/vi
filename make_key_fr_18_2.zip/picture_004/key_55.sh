java -jar getLatinTag.jar fr  fr "belles" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "cabinet" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "fonctionnement" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "FF" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "gérer" 1000  keyword_fr.txt
