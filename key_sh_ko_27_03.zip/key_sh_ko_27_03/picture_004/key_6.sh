java -jar getLatinTag.jar kr ko "華" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "롯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "칼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "갓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "粉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "칭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "쏘" 1000  keyword_ko.txt
