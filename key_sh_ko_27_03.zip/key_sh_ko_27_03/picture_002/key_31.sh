java -jar getLatinTag.jar kr ko "請" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "検" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "敗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "成" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "語" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "임" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "령" 1000  keyword_ko.txt
