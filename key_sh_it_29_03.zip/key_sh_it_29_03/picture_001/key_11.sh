java -jar getLatinTag.jar it it "regina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "vodafone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "class" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abordonati" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aboriginal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "incompleto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "abortante" 1000  keyword_it.txt
