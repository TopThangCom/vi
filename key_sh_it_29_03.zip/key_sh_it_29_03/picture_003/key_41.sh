java -jar getLatinTag.jar it it "delta" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "metalicas" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amascene" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "mascoteria" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "frosinone" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amaterra" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "alicia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "amatriciana" 1000  keyword_it.txt
