java -jar getLatinTag.jar kr ko "꽃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "抬" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "卜" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "獅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "獄" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嬉" 1000  keyword_ko.txt
