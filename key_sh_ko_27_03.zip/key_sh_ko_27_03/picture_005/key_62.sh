java -jar getLatinTag.jar kr ko "劣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "펙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "烈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "錢" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "냅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "긱" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "願" 1000  keyword_ko.txt
