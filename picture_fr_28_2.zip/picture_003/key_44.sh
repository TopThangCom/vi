java -jar getLatinTag.jar kr kr "景色宜人造句" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "夏天" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "冬天" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "景色造句" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "블루투스" 1000  keyword_kr.txt
