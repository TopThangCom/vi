java -jar getLatinTag.jar kr ko "碘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "姑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "漠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鼎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "窓" 1000  keyword_ko.txt
