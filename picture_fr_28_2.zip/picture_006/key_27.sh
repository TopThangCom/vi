java -jar getLatinTag.jar kr kr "瓜苗" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "种植" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "体温計" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "제레미" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "코비" 1000  keyword_kr.txt
