java -jar getLatinTag.jar it it "administratoraccount" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "appdata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "all" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "territoriale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "passord" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "license" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "commercium" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "signum" 1000  keyword_it.txt
