java -jar getLatinTag.jar kr kr "因為目標電腦拒絕連線。" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ls" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "산전" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "plc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "통신" 1000  keyword_kr.txt
