java -jar getLatinTag.jar fr  fr "voie" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "jouer" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prévoit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "blanc" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "noir" 1000  keyword_fr.txt
