java -jar getLatinTag.jar kr ko "福" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "岡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "口" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "長" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "師" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "歯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "衛" 1000  keyword_ko.txt
