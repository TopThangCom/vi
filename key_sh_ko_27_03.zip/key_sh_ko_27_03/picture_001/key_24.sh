java -jar getLatinTag.jar kr ko "識" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "別" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "년" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "형" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "블" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "東" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "京" 1000  keyword_ko.txt
