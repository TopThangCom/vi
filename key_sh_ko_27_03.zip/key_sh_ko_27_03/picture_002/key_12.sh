java -jar getLatinTag.jar kr ko "観" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "覧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "倍" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "発" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "表" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "準" 1000  keyword_ko.txt
