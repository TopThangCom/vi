java -jar getLatinTag.jar kr kr "레벨" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "순위" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이플빵" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "스티커" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "가격표" 1000  keyword_kr.txt
