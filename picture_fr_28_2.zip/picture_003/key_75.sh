java -jar getLatinTag.jar kr kr "健康診断" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "pcr検査" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "사용설명서" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "医療関係者" 1000  keyword_kr.txt
