java -jar getLatinTag.jar kr ko "焦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "牟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "借" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "催" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "梗" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "尺" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "羊" 1000  keyword_ko.txt
