java -jar getLatinTag.jar kr ko "쿵" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "憎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뺑" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "枉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "繆" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "闊" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "舊" 1000  keyword_ko.txt
