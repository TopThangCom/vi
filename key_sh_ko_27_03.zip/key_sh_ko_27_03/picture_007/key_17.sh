java -jar getLatinTag.jar kr ko "嘔" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "搏" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "穫" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "輿" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稟" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "賦" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "霄" 1000  keyword_ko.txt
