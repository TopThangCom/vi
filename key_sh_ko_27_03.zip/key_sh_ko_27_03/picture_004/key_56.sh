java -jar getLatinTag.jar kr ko "僧" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "稅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "未" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "阻" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瘡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "샬" 1000  keyword_ko.txt
