java -jar getLatinTag.jar it it "alcira" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "otorrino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "argumental" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "argumentation" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "argumentative" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "analogico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aborto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gegonota" 1000  keyword_it.txt
