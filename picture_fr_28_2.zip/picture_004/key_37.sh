java -jar getLatinTag.jar kr kr "하드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "백화점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "강서점" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "층별안내" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "불광" 1000  keyword_kr.txt
