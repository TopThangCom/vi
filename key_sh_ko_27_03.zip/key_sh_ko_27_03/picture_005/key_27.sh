java -jar getLatinTag.jar kr ko "옥" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "誰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "瓷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "견" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "뒷" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "믹" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "貴" 1000  keyword_ko.txt
