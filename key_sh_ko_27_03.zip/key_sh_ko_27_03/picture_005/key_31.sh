java -jar getLatinTag.jar kr ko "咪" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "菓" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "怒" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "昭" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氮" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "罐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "戴" 1000  keyword_ko.txt
