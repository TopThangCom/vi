java -jar getLatinTag.jar kr kr "光工場" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "配当" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "優待" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "武田薬品工業" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "株価" 1000  keyword_kr.txt
