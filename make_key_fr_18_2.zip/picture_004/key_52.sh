java -jar getLatinTag.jar fr  fr "cm" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "mouvements" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pratiques" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "régions" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "dossiers" 1000  keyword_fr.txt
