java -jar getLatinTag.jar fr  fr "oeuvre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "structure" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "suivre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "tiers" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "prise" 1000  keyword_fr.txt
