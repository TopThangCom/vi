java -jar getLatinTag.jar kr ko "탁" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "퀴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "듈" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "泡" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "顯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "셰" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "닥" 1000  keyword_ko.txt
