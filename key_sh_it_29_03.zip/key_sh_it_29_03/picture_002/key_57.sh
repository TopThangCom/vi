java -jar getLatinTag.jar it it "medici" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "netti" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "sfoglia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aldolino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "discogs" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chetosi" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "chetoso" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "reduttasi" 1000  keyword_it.txt
