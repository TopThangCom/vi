java -jar getLatinTag.jar kr ko "餃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "삽" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "춘" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "伙" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "氛" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鯉" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嘎" 1000  keyword_ko.txt
