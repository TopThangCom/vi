java -jar getLatinTag.jar fr  fr "soumis" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "d'exercice" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lecture" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "monter" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Grand" 1000  keyword_fr.txt
