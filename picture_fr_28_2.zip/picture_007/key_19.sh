java -jar getLatinTag.jar kr kr "가제" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주읍사무소" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주cc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주cc글램핑" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "승주cc날씨" 1000  keyword_kr.txt
