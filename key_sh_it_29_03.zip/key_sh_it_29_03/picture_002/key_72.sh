java -jar getLatinTag.jar it it "fino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gratuita" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "economicos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agregamento" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cavalo" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "fiorino" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "itinerancia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "contra" 1000  keyword_it.txt
