java -jar getLatinTag.jar kr ko "練" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "種" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "類" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "情" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "保" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "北" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "方" 1000  keyword_ko.txt
