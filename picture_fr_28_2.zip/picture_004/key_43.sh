java -jar getLatinTag.jar kr kr "준불연" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "두께" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "藍" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "美代子" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "藍美代子" 1000  keyword_kr.txt
