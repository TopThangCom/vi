java -jar getLatinTag.jar it it "anome" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anomia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "institucionales" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anomic" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nerviosa" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anormale" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "anormalement" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "epiteliales" 1000  keyword_it.txt
