java -jar getLatinTag.jar fr  fr "devait" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "profit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "méthode" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "pose" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "commence" 1000  keyword_fr.txt
