java -jar getLatinTag.jar it it "cpim" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "princess" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "aleatorio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascomata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascomatica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascomedia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascometal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ascomiceti" 1000  keyword_it.txt
