java -jar getLatinTag.jar kr ko "拐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "辣" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "困" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "吞" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "嵯" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "勃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鵝" 1000  keyword_ko.txt
