java -jar getLatinTag.jar kr ko "推" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "待" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "株" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "価" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "掲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "板" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "今" 1000  keyword_ko.txt
