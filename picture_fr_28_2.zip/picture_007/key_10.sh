java -jar getLatinTag.jar kr kr "발사" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "궤도" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "아르테미스" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "다누리호" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "성공" 1000  keyword_kr.txt
