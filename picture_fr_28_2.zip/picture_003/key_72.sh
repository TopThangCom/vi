java -jar getLatinTag.jar kr kr "用法" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "形容" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "观赏" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "景观" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "景色宜人英文" 1000  keyword_kr.txt
