java -jar getLatinTag.jar kr kr "幸村精市三年后" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "小说" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "生病" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "歌" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "名言" 1000  keyword_kr.txt
