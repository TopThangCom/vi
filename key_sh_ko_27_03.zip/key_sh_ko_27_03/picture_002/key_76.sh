java -jar getLatinTag.jar kr ko "븐" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "칠" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "얼" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "싸" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "움" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "응" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "감" 1000  keyword_ko.txt
