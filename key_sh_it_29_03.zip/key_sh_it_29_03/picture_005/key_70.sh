java -jar getLatinTag.jar it it "basilicata" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "basilico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "secco" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "antibiotico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gibraltar" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "torrinomedica" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "nettiradio" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "inglorios" 1000  keyword_it.txt
