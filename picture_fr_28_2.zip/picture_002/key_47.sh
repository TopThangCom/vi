java -jar getLatinTag.jar kr kr "봄버" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "리뷰" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "최저가" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "후드집업" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "맨투맨" 1000  keyword_kr.txt
