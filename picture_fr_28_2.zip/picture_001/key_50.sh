java -jar getLatinTag.jar kr kr "커맨드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "공략" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "메이크스틱" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "나가노" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "인성" 1000  keyword_kr.txt
