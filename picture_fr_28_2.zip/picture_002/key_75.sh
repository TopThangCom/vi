java -jar getLatinTag.jar kr kr "愛染刹那" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染橋醫院" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "藍染" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "宝玉" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "愛染国俊" 1000  keyword_kr.txt
