java -jar getLatinTag.jar fr  fr "disposition" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "formes" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "bénéficiaires" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "lesquels" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "maintenir" 1000  keyword_fr.txt
