java -jar getLatinTag.jar kr ko "孝" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "冲" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "云" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "炎" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "症" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "第" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "喉" 1000  keyword_ko.txt
