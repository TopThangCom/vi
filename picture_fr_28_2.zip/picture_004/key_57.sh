java -jar getLatinTag.jar kr kr "캐드" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "뷰어" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "포토샵" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "미리보기" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "판넬" 1000  keyword_kr.txt
