java -jar getLatinTag.jar kr ko "들" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "기" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "그" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "아" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "웃" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "룩" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "동" 1000  keyword_ko.txt
