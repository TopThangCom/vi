java -jar getLatinTag.jar it it "conciliaweb" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "copertura" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agemonia" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "cl" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "confiavel" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agenciahabitatge" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "coletivos" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "agenciauto" 1000  keyword_it.txt
