java -jar getLatinTag.jar kr kr "폰트" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "ucc" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "커피" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "방사능" 1000  keyword_kr.txt
java -jar getLatinTag.jar kr kr "우에시마" 1000  keyword_kr.txt
