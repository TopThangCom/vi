java -jar getLatinTag.jar kr ko "뮤" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "케" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "鶴" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "見" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "所" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "子" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "平" 1000  keyword_ko.txt
