java -jar getLatinTag.jar fr  fr "notre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "doit" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "nouveau" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "milliards" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "avant" 1000  keyword_fr.txt
