java -jar getLatinTag.jar kr ko "세" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "팅" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "평" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "특" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "돌" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "함" 1000  keyword_ko.txt
java -jar getLatinTag.jar kr ko "열" 1000  keyword_ko.txt
