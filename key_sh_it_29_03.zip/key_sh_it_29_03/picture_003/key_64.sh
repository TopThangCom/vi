java -jar getLatinTag.jar it it "perota" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "gualberto" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "divina" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "ftalico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "perclorico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "etanoico" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "medicinal" 1000  keyword_it.txt
java -jar getLatinTag.jar it it "disfraz" 1000  keyword_it.txt
