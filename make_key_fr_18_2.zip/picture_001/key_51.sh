java -jar getLatinTag.jar fr  fr "Et" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "si" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "entre" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Un" 1000  keyword_fr.txt
java -jar getLatinTag.jar fr  fr "Ce" 1000  keyword_fr.txt
